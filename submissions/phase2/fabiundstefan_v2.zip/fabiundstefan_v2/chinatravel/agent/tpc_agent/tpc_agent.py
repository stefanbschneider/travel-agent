import sys
import os
import time
import math
import json
from difflib import SequenceMatcher
from copy import deepcopy

from agent.base import BaseAgent
from chinatravel.symbol_verification.hard_constraint import evaluate_constraints_py
import random
import hashlib
import parse_constraints
from agent.tpc_agent.parsed_verifier import evaluate_parsed_constraints
from agent.tpc_agent.solver_constraints import solver_constraint_variants
import contextlib
import io
from chinatravel.evaluation.schema_constraint import evaluate_schema_constraints
from chinatravel.evaluation.commonsense_constraint import evaluate_commonsense_constraints
from chinatravel.symbol_verification.concept_func import normalize_poi_name

sys.path.append("./../../../")
project_root_path = os.path.dirname(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
)

if project_root_path not in sys.path:
    sys.path.insert(0, project_root_path)


def restart_seed(uid, seed_salt):
    """Deterministic RNG seed for the multi-start search, from the query id and the salt.

    Uses a stable digest rather than the built-in ``hash()``. ``hash()`` over strings is salted
    per interpreter unless ``PYTHONHASHSEED`` is pinned, which nothing here does -- so the search
    drew a *different* restart sequence in every process, making runs irreproducible and giving
    same-config runs a score spread of up to ``1.04`` overall (see
    ``docs/tpc_phase2_roadmap.md``, "Landed and promoted"). ``PYTHONHASHSEED`` cannot be set after
    interpreter start, so pinning it would mean re-exec'ing the entry point; a stable digest is
    local and free.

    Returns a 32-bit seed, matching the range the previous implementation produced. The width is
    arbitrary -- ``random.Random`` takes an int of any size -- so it comes from the digest directly
    rather than from masking a wider one.
    """
    digest = hashlib.blake2b(f"{uid}\x00{seed_salt}".encode("utf-8"), digest_size=4).digest()
    return int.from_bytes(digest, "big")


def add_minutes(time_str, minutes):
    """Add minutes to a HH:MM time string, clamping at 23:59."""
    h, m = map(int, time_str.split(":"))
    total = h * 60 + m + minutes
    total = min(total, 23 * 60 + 59)
    return f"{total // 60:02d}:{total % 60:02d}"


def minutes_to_time(total_minutes):
    """Convert total minutes to a HH:MM time string, clamping at 23:59."""
    total_minutes = max(0, min(int(total_minutes), 23 * 60 + 59))
    return f"{total_minutes // 60:02d}:{total_minutes % 60:02d}"


def time_to_minutes(t):
    """Convert HH:MM string to total minutes."""
    h, m = map(int, t.split(":"))
    return h * 60 + m


def time_before(t1, t2):
    """Return True if t1 <= t2 (both HH:MM strings)."""
    return time_to_minutes(t1) <= time_to_minutes(t2)


def is_open_during(attr, start_time, end_time):
    """Check if attraction is open for the entire visit period [start_time, end_time]."""
    opentime = str(attr["opentime"])
    endtime = str(attr["endtime"])
    ot_min = time_to_minutes(opentime)
    et_min = time_to_minutes(endtime)
    # Handle wrap-around
    if et_min <= ot_min:
        et_min += 24 * 60
    st_min = time_to_minutes(start_time)
    ed_min = time_to_minutes(end_time)
    return ot_min <= st_min and ed_min <= et_min


class _AcceptedEarlyStop(BaseException):
    """Unwinds every nested loop in ``_solve`` as soon as an accepted plan is found when
    ``TPC_SOLVE_STOP_AT_ACCEPT`` is enabled for evaluation tooling. Subclass ``BaseException``
    so it passes through the ``except Exception`` handlers guarding each ``consider()`` call."""


class TPCAgent(BaseAgent):
    def __init__(self, **kwargs):
        super().__init__(name="TPC", **kwargs)
        # Accept plans against the in-data oracle hard_logic_py; set "0" to parse constraints live from NL (Phase-2 reuse).
        self.use_oracle = os.environ.get("TPC_USE_ORACLE", "1") != "0"
        # Maximum plan rebuilds attempted per query during the multi-start search.
        self.max_restarts = int(os.environ.get("TPC_MAX_RESTARTS", "400"))
        # Wall-clock budget (seconds) the per-query search self-limits to.
        self.solve_budget_sec = float(os.environ.get("TPC_SOLVE_BUDGET_SEC", "120"))
        # Consecutive non-improving random restarts (after an accepted plan already exists) after
        # which the multi-start loop stops early instead of spending the rest of the budget/restart
        # cap on a plateaued search. 0 (default) disables this -- restarts always run to
        # max_restarts/budget, the pre-existing behavior. Distinct from TPC_SOLVE_STOP_AT_ACCEPT,
        # which stops at the *first* accept regardless of preference score.
        self.solve_converge_patience = int(os.environ.get("TPC_SOLVE_CONVERGE_PATIENCE", "0"))
        # Salt mixed into the per-query RNG seed so distinct search rounds explore different params.
        self.seed_salt = os.environ.get("TPC_SEED_SALT", "0")
        self._transport_constraints = {}
        self._schema = None
        # Optional harness-supplied constraint variants. When set to a non-empty list (e.g. by the
        # Phase 2 orchestrator via make_tpcagent_solve_fn), the agent uses these directly instead of
        # re-parsing the query, so the harness stays the single owner of parsing (incl. no-oracle
        # disjunctive branch expansion). None/empty preserves the internal parse path.
        self._injected_variants = None
        # Best-so-far plan snapshot exported to the Phase 2 harness when external timeouts fire.
        self._timeout_recovery_plan = None
        # Constraints dict behind the best-so-far candidate's checker (mirrors
        # _timeout_recovery_plan's "best so far" semantics). Exported via ground_and_check so the
        # Phase 2 orchestrator's Stage 3 LLM refine can re-check a trialled edit with the exact
        # same checker _solve used, without re-deriving constraints or spending solve budget.
        self._last_solve_constraints = None
        # Search telemetry from the most recent _solve call (roadmap W4 step 0): restarts_used,
        # stop_reason ("budget" | "max_restarts" | "converged" | "accepted_stop"),
        # candidates_evaluated, best_found_at_restart. Pure observation, no behavior change; empty
        # until the first _solve call completes.
        self.last_search_telemetry = {}

    def reset_timeout_recovery_plan(self):
        self._timeout_recovery_plan = None

    def _set_timeout_recovery_plan(self, plan):
        if not isinstance(plan, dict):
            return
        try:
            self._timeout_recovery_plan = deepcopy(plan)
        except Exception:
            # Fall back to direct assignment when deepcopy fails on custom objects.
            self._timeout_recovery_plan = plan

    def get_timeout_recovery_plan(self):
        if not isinstance(self._timeout_recovery_plan, dict):
            return None
        try:
            return deepcopy(self._timeout_recovery_plan)
        except Exception:
            return self._timeout_recovery_plan

    def _make_checker(self, query, constraints):
        """Return check(plan) -> (passed, total).

        The base score is the oracle hard_logic_py pass (identical to eval_tpc's logic pass) or,
        in no-oracle mode, the parsed-constraint pass. Once the base is fully satisfied the plan
        is additionally gated on schema + commonsense validity, because FPR == schema ∩
        commonsense ∩ logic; the +2 makes acceptance require all three.
        """
        hard_logic_py = query.get("hard_logic_py", []) or []
        target_city = query.get("target_city", "")

        def base_check(plan):
            if self.use_oracle:
                if not hard_logic_py:
                    return 0, 0
                try:
                    res = evaluate_constraints_py(hard_logic_py, plan, verbose=False)
                except Exception:
                    return 0, len(hard_logic_py)
                return sum(1 for r in res if bool(r)), len(res)

            try:
                res = evaluate_parsed_constraints(constraints, plan, target_city)
            except Exception:
                return 0, 0
            return sum(1 for r in res if r), len(res)

        def check(plan):
            passed, total = base_check(plan)
            extra = 0
            if passed == total:
                # Env validity only matters once every hard constraint is met.
                if self._schema_ok(query, plan):
                    extra += 1
                if self._commonsense_ok(query, plan):
                    extra += 1
            return passed + extra, total + 2
        return check

    def _get_schema(self):
        if self._schema is None:
            try:
                with open(os.path.join(project_root_path, "evaluation", "output_schema.json"), "r", encoding="utf-8") as f:
                    self._schema = json.load(f)
            except Exception:
                self._schema = {}
        return self._schema

    def _schema_ok(self, query, plan):
        uid = str(query.get("uid", ""))
        try:
            with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                _, _, pass_id = evaluate_schema_constraints([uid], {uid: plan}, self._get_schema())
            return uid in pass_id
        except Exception:
            return False

    def _commonsense_ok(self, query, plan):
        uid = str(query.get("uid", ""))
        try:
            with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                _, _, _, pass_id = evaluate_commonsense_constraints(
                    [uid], {uid: query}, {uid: plan}, verbose=False, lang=self.lang)
            return uid in pass_id
        except Exception:
            return False

    def _accepted(self, passed, total):
        """A plan is accepted when it has no checkable constraints or passes all of them."""
        return total == 0 or passed == total

    def _is_intercity_activity(self, activity):
        return isinstance(activity, dict) and activity.get("type") in ("airplane", "train")

    def _sanitize_plan_for_grounding(self, plan, query):
        """Drop accidental mid-itinerary intercity placeholders.

        Hardened evaluator grounding allows train/airplane only as the global first/last
        activity. If a candidate contains middle intercity markers, remove them and, when
        possible, reconnect the following POI via a legal inner-city transport edge.
        """
        if not isinstance(plan, dict):
            return plan
        itinerary = plan.get("itinerary", []) or []
        if not isinstance(itinerary, list) or len(itinerary) == 0:
            return plan

        def flatten_refs(p):
            refs = []
            for day_idx, day in enumerate(p.get("itinerary", []) or []):
                activities = (day or {}).get("activities", [])
                if not isinstance(activities, list):
                    continue
                for act_idx, activity in enumerate(activities):
                    refs.append((day_idx, act_idx, activity))
            return refs

        refs = flatten_refs(plan)
        if len(refs) <= 2:
            return plan
        if not any(
            self._is_intercity_activity(activity) and global_idx not in (0, len(refs) - 1)
            for global_idx, (_, _, activity) in enumerate(refs)
        ):
            return plan

        cleaned = deepcopy(plan)
        city = str(query.get("target_city", ""))
        people = int(query.get("people_number", 1) or 1)

        # Remove one illegal marker at a time so indices stay valid.
        while True:
            refs = flatten_refs(cleaned)
            illegal_idx = None
            for global_idx, (_day_idx, _act_idx, activity) in enumerate(refs):
                if self._is_intercity_activity(activity) and global_idx not in (0, len(refs) - 1):
                    illegal_idx = global_idx
                    break
            if illegal_idx is None:
                break

            day_idx, act_idx, _activity = refs[illegal_idx]
            prev_ref = refs[illegal_idx - 1] if illegal_idx > 0 else None
            next_ref = refs[illegal_idx + 1] if illegal_idx + 1 < len(refs) else None

            day_activities = cleaned["itinerary"][day_idx].get("activities", [])
            if not isinstance(day_activities, list) or act_idx >= len(day_activities):
                break
            del day_activities[act_idx]

            if prev_ref is None or next_ref is None:
                continue
            prev_day, prev_idx, _ = prev_ref
            next_day, next_idx, _ = next_ref
            if next_day == day_idx and next_idx > act_idx:
                next_idx -= 1
            try:
                prev_act = cleaned["itinerary"][prev_day]["activities"][prev_idx]
                next_act = cleaned["itinerary"][next_day]["activities"][next_idx]
            except Exception:
                continue
            if not isinstance(next_act, dict) or self._is_intercity_activity(next_act):
                continue

            from_pos = self._activity_end_position(prev_act)
            to_pos = self._activity_start_position(next_act)
            depart_time = str(prev_act.get("end_time", ""))
            if not (city and from_pos and to_pos and depart_time):
                continue
            try:
                transports, arrival = self._get_transport(
                    self.env, city, from_pos, to_pos, depart_time, people
                )
            except Exception:
                transports, arrival = None, None
            if not transports:
                # Keep schema-compliant empty transports rather than stale, now-invalid
                # edge details inherited from removed placeholder activities.
                next_act["transports"] = []
                continue
            next_start = str(next_act.get("start_time", ""))
            if next_start and (not arrival or not time_before(arrival, next_start)):
                next_act["transports"] = []
                continue
            next_act["transports"] = transports

        return cleaned

    def _norm_text(self, value):
        if value is None:
            return ""
        try:
            value = normalize_poi_name(str(value))
        except Exception:
            pass
        return str(value).strip().lower()

    def _match_constraint_text(self, candidate, constraint):
        c = self._norm_text(candidate)
        q = self._norm_text(constraint)
        if not c or not q:
            return False
        return c == q or q in c or c in q

    def _match_type(self, attr_type, req_type):
        """Match attraction type using segment-based exact matching.

        Splits attr_type by '/' and checks if req_type exactly matches any segment
        (case-insensitive). Avoids false positives from substring matching, e.g.,
        'park' should not match 'Amusement Park/Sports Entertainment'.
        """
        if not attr_type or not req_type:
            return False
        req_norm = self._norm_text(req_type)
        attr_norm = self._norm_text(attr_type)
        if req_norm == attr_norm:
            return True
        segments = [s.strip() for s in attr_norm.split("/")]
        return req_norm in segments

    def _constraint_variants(self, query):
        # Prefer harness-supplied variants (single parsing owner) when present and non-empty.
        injected = self._injected_variants
        if isinstance(injected, list) and len(injected) > 0:
            return injected
        raw = parse_constraints.parse_query(query) if self.use_oracle else parse_constraints.parse_query_no_oracle(query)
        if not isinstance(raw, dict):
            return [{}]
        return solver_constraint_variants(query, raw, use_oracle=self.use_oracle)

    def _collect_constraints(self, query):
        variants = self._constraint_variants(query)
        if len(variants) == 0:
            return {}
        return variants[0]


    def _resolve_required_names(self, raw_required, candidate_names):
        if not isinstance(raw_required, list) or len(raw_required) == 0:
            return []
        candidates = [str(n) for n in candidate_names if str(n).strip()]
        if not candidates:
            return []
        resolved = []
        for req in raw_required:
            req_text = str(req).strip()
            if not req_text:
                continue
            direct = [
                c for c in candidates
                if self._match_constraint_text(c, req_text) or self._match_constraint_text(req_text, c)
            ]
            if direct:
                chosen = direct[0]
            else:
                req_norm = self._norm_text(req_text)
                scored = sorted(
                    (
                        (SequenceMatcher(None, req_norm, self._norm_text(c)).ratio(), c)
                        for c in candidates
                    ),
                    reverse=True,
                )
                chosen = scored[0][1] if scored and scored[0][0] >= 0.72 else None
            if chosen and not any(self._match_constraint_text(chosen, existing) for existing in resolved):
                resolved.append(chosen)
        return resolved

    def _plan_total_cost(self, plan):
        total = 0.0
        for day in plan.get("itinerary", []) or []:
            for activity in day.get("activities", []) or []:
                total += self._safe_float(activity.get("cost", 0.0), 0.0)
                total += self._transport_cost_total(activity.get("transports", []))
        return total

    def _slot_visit_len(self, params, constraints):
        """Conservative slot length used before the specific attraction is chosen: the
        longest dwell any constraint demands (clamped to 240), at least 60 minutes."""
        longest = 0
        for d in constraints.get("stay_duration", []) or []:
            if isinstance(d, dict):
                try:
                    longest = max(longest, int(d.get("min_minutes", 0)))
                except (TypeError, ValueError):
                    pass
        return min(240, max(int(params.get("visit_minutes", 90)), longest, 60))

    def _visit_len(self, attr, params, constraints):
        """Actual visit length for a chosen attraction: visit_minutes, raised to this POI's
        own min dwell when a stay_duration constraint names it (clamped to 240)."""
        name = str(attr["name"])
        need = 0
        for d in constraints.get("stay_duration", []) or []:
            if isinstance(d, dict) and self._match_constraint_text(name, d.get("location", "")):
                try:
                    need = max(need, int(d.get("min_minutes", 0)))
                except (TypeError, ValueError):
                    pass
        return min(240, max(int(params.get("visit_minutes", 90)), need))

    def _visit_minutes_candidates(self, constraints):
        """Return dwell baselines explored by search (small values improve packing density).

        Candidates remain bounded by named minimum-dwell constraints so required visits are
        never shortened below what the query asks for.
        """
        longest = 0
        for d in (constraints or {}).get("stay_duration", []) or []:
            if isinstance(d, dict):
                try:
                    longest = max(longest, int(d.get("min_minutes", 0)))
                except (TypeError, ValueError):
                    pass
        base = [60, 75, 90, 105]
        floor = min(240, max(60, longest))
        values = sorted(set(min(240, max(v, floor)) for v in base))
        return values if values else [90]

    def _rotate_tail(self, items, is_pinned, offset):
        """Rotate only the non-pinned tail of `items` by `offset` (pinned entries stay at front)."""
        pinned = [x for x in items if is_pinned(x)]
        tail = [x for x in items if not is_pinned(x)]
        if tail and offset:
            off = offset % len(tail)
            tail = tail[off:] + tail[:off]
        return pinned + tail

    def _pin_windows_enabled(self):
        """Opt-in flag for the experimental timed-visit-at-named-POI pinning path (roadmap G8).

        Default OFF, so the deterministic floor is byte-identical to before: no extra pool
        projection and no retiming move. Enable with ``TPC_PIN_TIMED_WINDOWS=1`` to measure the
        familiar-100 solver-only effect through the pinned gate before any promotion."""
        return os.environ.get("TPC_PIN_TIMED_WINDOWS", "0") not in ("", "0", "false", "False")

    def _commonsense_first_enabled(self):
        """Opt-in umbrella flag for the commonsense-first finalization policy (final-evening brief).

        ``eval_tpc`` scores C-LPR as the *conditional* logical micro
        (``evaluate_hard_constraints_py_v2(..., env_pass_id=commonsense_pass_id)``): a query's
        per-clause logical credit counts only if that query also passes the commonsense checker,
        while the denominator stays the whole batch's clause count. EPR-macro is all-or-nothing per
        query too. So emitting a commonsense-invalid plan discards its logical partial credit
        (weight ``0.25``) *and* its EPR-macro point (weight ``0.10``) even when most of its clauses
        pass -- measured on the promoted row as C-LPR ``66.02`` against an unconditional
        ``logical_micro`` of ``89.47`` (see ``scripts/phase2_commonsense_headroom.py``).

        Default OFF, so the deterministic floor stays byte-identical. When on it enables:

        - the relaxed repair commit rule for *unaccepted* plans (``_repair_commit_allowed``),
        - the commonsense-valid finalization preference in ``_solve`` (the ``best_cs`` bucket),
        - ``_repair_transport_gaps`` and ``_repair_intercity_endpoints``, whose own flags remain
          honored as explicit operator overrides (setting either to ``0`` still disables it).
        """
        return os.environ.get("TPC_COMMONSENSE_FIRST", "0") not in ("", "0", "false", "False")

    def _flag_enabled_with_umbrella(self, name):
        """True when ``name`` is set truthy, or when the commonsense-first umbrella implies it.

        An explicit ``name=0`` always wins, so an operator can screen the umbrella minus one pass.
        """
        raw = os.environ.get(name)
        if raw is not None:
            return str(raw) not in ("", "0", "false", "False")
        return self._commonsense_first_enabled()

    def _repair_transport_gaps_enabled(self):
        """Opt-in flag for the commonsense-transport repair pass (roadmap step 4).

        Default OFF, so the deterministic floor is byte-identical to before: no leg
        recomputation and no plan mutation. Enable with ``TPC_REPAIR_TRANSPORT_GAPS=1`` (or
        implicitly via ``TPC_COMMONSENSE_FIRST=1``) to measure the "Invalid Transport information
        across positions" effect -- the largest commonsense residual family, 13 of the 21 failing
        end-to-end plans on the promoted row."""
        return self._flag_enabled_with_umbrella("TPC_REPAIR_TRANSPORT_GAPS")

    def _cascade_timed_windows_enabled(self):
        """Opt-in cascading forward-shift fallback for the post-pin ``timed_visit_named_poi``
        residual -- still the dominant solver-only failure family *after* ``TPC_PIN_TIMED_WINDOWS``
        (see the roadmap's "Cascading timed-window shift" section for the measured attribution).

        Default OFF, so the deterministic floor -- and the existing pin flow when this is unset --
        stays byte-identical: the fallback branch in ``_pin_timed_windows`` is skipped entirely.
        Enable with ``TPC_CASCADE_TIMED_WINDOWS=1``. Only meaningful together with
        ``TPC_PIN_TIMED_WINDOWS``, since it runs as a fallback inside ``_pin_timed_windows``."""
        return os.environ.get("TPC_CASCADE_TIMED_WINDOWS", "0") not in ("", "0", "false", "False")

    def _window_anchor_enabled(self):
        """Opt-in window-anchored day relayout for the post-pin ``timed_visit_named_poi`` residual
        (roadmap P1).

        Default OFF, so the deterministic floor is byte-identical: ``_pack_plan`` skips
        ``_anchor_timed_windows`` entirely and ``_relayout_movable_block`` keeps its previous
        window-resolution and fixed-tail behaviour for every existing caller.

        What it adds over the landed moves, both derived from a measured classification of the
        residual by *shape* (``scripts/phase2_timed_window_shapes.py``, familiar-100 val,
        solver-only, harness defaults: 65 failing clauses over 51 queries -- forward-shift 24,
        shorten 16, absent-POI 15, backward-shift 10):

        1. **Type-aware, intersected windows.** 11 of 80 val queries carry two timed windows on the
           *same* POI name that differ only in activity type (a hotel's breakfast window and its
           overnight-stay window). ``_window_for_position`` returns whichever clause came first, so
           the day's breakfast gets clamped to the 20:10-24:00 stay window and the relayout dies.
        2. **A re-timable overnight-accommodation tail.** The landed relayout rejects any layout
           whose ripple makes the day's fixed tail unreachable at its recorded ``start_time``. That
           is right for a train or a flight and wrong for the overnight stay, whose start time is
           just "when you got back to the hotel": 25 of 29 tail rejections in the residual are that
           accommodation stay.

        Enable with ``TPC_WINDOW_ANCHOR=1``. Only meaningful together with
        ``TPC_PIN_TIMED_WINDOWS``, which is what puts the named POI in the plan at all.

        **Promoted 2026-08-05**: gate-cleared on R8 (whole-run row ``20260805T123142Z``, ``overall
        63.58`` / ``FPR 43.0`` against the zero-variance R7 baseline's ``57.75`` / ``32.0``), so
        ``solve_phase2.apply_deterministic_solver_defaults()`` now sets this to ``1`` for the shipped
        harness path. The **library** default stays OFF so the byte-identical floor tests keep
        holding, and an explicit ``TPC_WINDOW_ANCHOR=0`` still wins everywhere."""
        return os.environ.get("TPC_WINDOW_ANCHOR", "0") not in ("", "0", "false", "False")

    def _window_push_enabled(self):
        """Opt-in bounded suffix push for the residual forward/shorten window cases (P8)."""
        return os.environ.get("TPC_WINDOW_PUSH", "0") not in ("", "0", "false", "False")

    def _window_insert_enabled(self):
        """Opt-in named-POI insertion for absent timed visits (P9)."""
        return os.environ.get("TPC_WINDOW_INSERT", "0") not in ("", "0", "false", "False")

    def _window_relocate_day_enabled(self):
        """Opt-in cross-day relocation for a timed visit whose window cannot be met on the day it
        is currently scheduled (roadmap P25).

        The three landed window moves (anchor P1, push P8, insert P9) all operate *within* one
        day. The residual this targets is different in kind: a POI that is already present in the
        plan for its required activity type, but on a day where no in-day reshuffle can land it in
        its window -- the window has effectively already "passed" for that day's own structure
        (fixed predecessor/successor times, or the day's own open span). Default OFF, so the
        deterministic floor is unchanged: ``_pack_plan`` skips
        ``_relocate_timed_windows_across_days`` entirely. Enable with
        ``TPC_WINDOW_RELOCATE_DAY=1``. Only meaningful together with ``TPC_PIN_TIMED_WINDOWS``,
        which is what puts the named POI in the plan at all."""
        return os.environ.get("TPC_WINDOW_RELOCATE_DAY", "0") not in ("", "0", "false", "False")

    def _repair_intercity_enabled(self):
        """Opt-in flag for intercity endpoint grounding repair.

        Default OFF, so the deterministic floor is byte-identical to before: no endpoint
        re-grounding and no plan mutation. Enable with ``TPC_REPAIR_INTERCITY=1`` (or implicitly via
        ``TPC_COMMONSENSE_FIRST=1``) to measure the endpoint commonsense residual -- 3 of the 21
        failing end-to-end plans on the promoted row fail all four intercity columns at once.
        """
        return self._flag_enabled_with_umbrella("TPC_REPAIR_INTERCITY")

    def _repair_drop_trailing_stay_enabled(self):
        """Opt-in flag: drop a trailing overnight accommodation on a single-day trip before the
        return-endpoint repair computes its departure floor.

        Default OFF, so the deterministic floor is byte-identical. Enable with
        ``TPC_REPAIR_DROP_TRAILING_STAY=1`` (or implicitly via ``TPC_COMMONSENSE_FIRST=1``, same
        umbrella wiring as ``TPC_REPAIR_INTERCITY``). Targets the shape ``_repair_intercity_endpoints``
        cannot reach on its own: a 1-day itinerary whose last activity is an overnight accommodation
        running to ``24:00``. The floor for the return leg is derived from that activity's
        ``end_time``, so no train/flight can depart after it and the endpoint repair silently
        declines. An overnight stay in a single-day itinerary is wrong on its own terms -- dropping it
        before the floor is computed lets the existing return-row search find a real departure.
        """
        return self._flag_enabled_with_umbrella("TPC_REPAIR_DROP_TRAILING_STAY")

    def _pack_dav_enabled(self):
        """Opt-in attraction top-up pass for accepted plans.

        Default OFF, so the library floor is byte-identical: accepted plans keep their current
        preference score unless an operator explicitly screens/promotes this pass. This flag also
        owns the ATT-protection rule from the task brief: any inserted attraction re-routes its
        affected inner-city hops to the shortest-time valid mode before the full checker decides
        whether to keep it.
        """
        return os.environ.get("TPC_PACK_DAV", "0") not in ("", "0", "false", "False")

    def _pack_ddr_enabled(self):
        """Opt-in breakfast/lunch/dinner top-up pass for accepted plans.

        Default OFF. Adds missing breakfast/lunch/dinner activities at grounded restaurants only
        when the resulting accepted plan does not regress the accepted-plan preference key. The
        breakfast slot uses ``_insert_restaurant_breakfast`` (a real, priced restaurant inside the
        evaluator's ``06:00 -- 09:00`` band), never a free hotel breakfast -- that variant stays
        behind its own ``TPC_PACK_HOTEL_BREAKFAST`` flag.
        """
        return os.environ.get("TPC_PACK_DDR", "0") not in ("", "0", "false", "False")

    def _pack_att_enabled(self):
        """Opt-in ATT (average inner-city hop time) optimizer for accepted plans.

        Default OFF. Runs only count-preserving moves -- faster-mode hop rebuilds and nearer-POI
        swaps -- so DAV/DDR cannot fall and only the transport component can move. Every edit is
        gated by the full checker plus the accepted-plan preference key, same as the top-up passes.
        """
        return os.environ.get("TPC_PACK_ATT", "0") not in ("", "0", "false", "False")

    def _pack_hotel_breakfast_enabled(self):
        """Opt-in free hotel-breakfast top-up for accepted plans.

        Default OFF and intentionally separate from every umbrella/default because it exploits the
        official DDR scorer's hotel-breakfast leniency. The implementation is kept available for
        measurement, but shipping it remains an explicit operator decision.
        """
        return os.environ.get("TPC_PACK_HOTEL_BREAKFAST", "0") not in ("", "0", "false", "False")

    def _packing_enabled(self):
        return (
            self._pack_dav_enabled()
            or self._pack_ddr_enabled()
            or self._pack_hotel_breakfast_enabled()
            or self._pack_att_enabled()
        )

    def _fast_commonsense_prefilter(self, plan):
        """Microsecond structural screen for the two dominant commonsense failure families.

        The official evaluator costs roughly ``300 ms`` per call (it rebuilds DataFrames and
        re-grounds every activity), and inside a wall-clock-bounded solve every such call is paid for
        with a restart that does not happen. This screen rejects the candidates that cannot possibly
        pass, in pure Python and without touching ``WorldEnv``:

        - **transport chain** (``Invalid Transport information across positions``, 13 of the 21
          failing end-to-end plans on the promoted row): a position change must carry an inbound leg
          chain that actually connects the previous position to this one. A transport-less plan --
          the exact shape the search leader takes on that family -- dies here.
        - **chronology** (``Does not follow Chronological Order``, 7 of the 21): each activity must
          end no earlier than it starts, must not start before the previous activity of the same day
          ends, and must start no earlier than its own inbound leg arrives.

        Returns ``True`` for "worth a real evaluator call", never a guarantee. It is deliberately no
        stricter than the official checks it mirrors, so a plan the official evaluator would accept
        is not screened out here (back-to-back activities are allowed; only real overlap is not).
        """
        if not isinstance(plan, dict):
            return False
        itinerary = plan.get("itinerary")
        if not isinstance(itinerary, list) or not itinerary:
            return False

        prev_pos = None
        for day in itinerary:
            activities = (day or {}).get("activities")
            if not isinstance(activities, list) or not activities:
                return False
            day_prev_end = None
            for activity in activities:
                if not isinstance(activity, dict):
                    return False
                start_min = self._safe_time_minutes(activity.get("start_time"))
                end_min = self._safe_time_minutes(activity.get("end_time"))
                if start_min is None or end_min is None or end_min < start_min:
                    return False
                if day_prev_end is not None and start_min < day_prev_end:
                    return False
                legs = activity.get("transports") or []
                is_intercity = self._is_intercity_activity(activity)
                cur_pos = self._activity_start_position(activity)
                if (
                    prev_pos is not None
                    and not is_intercity
                    and cur_pos
                    and normalize_poi_name(cur_pos) != normalize_poi_name(prev_pos)
                ):
                    if not legs:
                        return False
                    if normalize_poi_name(str(legs[0].get("start", ""))) != normalize_poi_name(prev_pos):
                        return False
                    if normalize_poi_name(str(legs[-1].get("end", ""))) != normalize_poi_name(cur_pos):
                        return False
                if legs:
                    leg_end = self._safe_time_minutes(legs[-1].get("end_time"))
                    if leg_end is not None and leg_end > start_min:
                        return False
                prev_pos = self._activity_end_position(activity)
                day_prev_end = end_min
        return True

    def _repair_commit_allowed(self, plan, trial, query, check, was_accepted):
        """Commit rule shared by the deterministic repair passes.

        Two regimes, because the value of a repair depends on what the input plan was worth:

        - **Accepted input**: unchanged legacy rule. The trial must still be accepted and must not
          regress the preference key -- never trade a valid plan for a repaired-but-worse one.
        - **Unaccepted input** (only when ``TPC_COMMONSENSE_FIRST`` is on): commit when the trial is
          schema-valid, turns a commonsense-*invalid* plan commonsense-*valid*, and does not lower
          the parsed-constraint pass count. This is the case the old rule could never reach: an
          unaccepted plan fails ``_accepted`` by definition, so a repair that fixed its transport or
          intercity grounding was always discarded -- on exactly the plans whose commonsense failure
          zeroes their C-LPR and EPR-macro credit. Preference is deliberately not guarded here: the
          repaired plan costs more money/time than the broken one by construction, and the invariant
          forbids trading a *valid* plan for score, not spending cost to make an invalid plan valid.

        Comparing raw ``passed`` counts from ``check`` is safe across the two plans: the ``+2``
        schema/commonsense bonus only applies once the parsed base is fully satisfied, which is
        false for both sides in the unaccepted regime.
        """
        if was_accepted:
            if not self._accepted(*check(trial)):
                return False
            return self._accepted_eval_key(trial) >= self._accepted_eval_key(plan)

        if self._accepted(*check(trial)):
            # A repair that reaches full acceptance is always a win, regardless of the umbrella.
            return True
        if not self._commonsense_first_enabled():
            return False

        trial_passed, _ = check(trial)
        plan_passed, _ = check(plan)
        if trial_passed < plan_passed:
            return False
        # Only worth committing when it actually flips the gate that costs us the score. Both
        # helpers already degrade to False when the evaluator raises.
        if self._commonsense_ok(query, plan):
            return False
        return self._schema_ok(query, trial) and self._commonsense_ok(query, trial)

    def _apply_search_constraints(self, constraints, params):
        """Project per-POI dwell/time-window POIs into the required pools (so the base build
        includes them) and a window's latest-start onto an arrive_no_later timing constraint
        (so the existing slot machinery refuses placing the POI too late)."""
        merged = dict(constraints) if isinstance(constraints, dict) else {}
        windows = merged.get("activity_time_windows", []) or []
        durations = merged.get("stay_duration", []) or []

        positioned = []
        for w in windows:
            if isinstance(w, dict) and w.get("location"):
                positioned.append(str(w["location"]))
        for d in durations:
            if isinstance(d, dict) and d.get("location"):
                positioned.append(str(d["location"]))
        if positioned:
            # The resolver filters per-DB, so a name only survives in the pool it actually matches.
            # required_hotels (opt-in) is included so a "meal at <named accommodation>" window pins
            # hotel selection to that accommodation (its hotel breakfast satisfies the clause); it is
            # gated because it changes hotel selection on the deterministic floor.
            pool_keys = ["required_attractions", "required_restaurants"]
            if self._pin_windows_enabled():
                pool_keys.append("required_hotels")
            for key in pool_keys:
                existing = list(merged.get(key, []) or [])
                for loc in positioned:
                    if not any(self._match_constraint_text(loc, e) for e in existing):
                        existing.append(loc)
                merged[key] = existing

        extra_timing = []
        for w in windows:
            if isinstance(w, dict) and w.get("location") and w.get("latest"):
                extra_timing.append({"type": "arrive_no_later", "location": str(w["location"]), "time": str(w["latest"])})
        if extra_timing:
            tc = list(merged.get("timing_constraints", []) or [])
            for e in extra_timing:
                if not any(isinstance(t, dict) and t.get("type") == e["type"]
                           and self._match_constraint_text(t.get("location", ""), e["location"]) for t in tc):
                    tc.append(e)
            merged["timing_constraints"] = tc
        return merged

    def _activity_counts(self, plan):
        attrs = meals = 0
        for day in plan.get("itinerary", []) or []:
            for a in day.get("activities", []) or []:
                t = a.get("type")
                if t == "attraction":
                    attrs += 1
                elif t in ("breakfast", "lunch", "dinner"):
                    meals += 1
        return attrs, meals

    def _default_preference_components(self, plan):
        attrs, meals = self._activity_counts(plan)
        days = max(1, len(plan.get("itinerary", []) or []))
        dav = min(1.0, attrs / (4.0 * days))
        ddr = min(1.0, meals / (3.0 * days))
        transit_total = 0
        transit_count = 0
        for day in plan.get("itinerary", []) or []:
            for activity in day.get("activities", []) or []:
                transports = activity.get("transports", []) or []
                if transports:
                    transit_total += self._inner_activity_minutes(activity)
                    transit_count += 1
        # Mirror eval_tpc's DEFAULT_TRANS_PR exactly: since upstream PR #30 a plan with no
        # innercity transport scores 0 on ATT, not the old clamped 8/7 (== 1.0).
        if transit_count > 0:
            average_transit = transit_total / transit_count
            att = max(0.0, min(1.0, (-1.0 / 105.0) * average_transit + 8.0 / 7.0))
        else:
            att = 0.0
        return dav, att, ddr

    def _eval_proxy(self, plan):
        dav, att, ddr = self._default_preference_components(plan)
        return 5.0 * dav + 5.0 * att + 5.0 * ddr

    def _accepted_eval_key(self, plan):
        """Rank fully valid plans by the default leaderboard preference components.

        Once a plan passes every hard/env check, prefer the strongest DAV/ATT/DDR combination
        instead of reusing the generic search key that still prioritizes raw passed-count.
        """
        dav, att, ddr = self._default_preference_components(plan)
        attrs, meals = self._activity_counts(plan)
        return (dav + att + ddr, dav + ddr, attrs + meals, -self._plan_total_cost(plan))

    def _repair_params(self, constraints):
        """Deterministic param priors derived from which constraints are present, tried before
        random restarts so single-signal queries converge fast."""
        candidates = []
        for vm in self._visit_minutes_candidates(constraints):
            candidates.append({"visit_minutes": vm})
        budgets = constraints.get("budgets", {}) or {}
        if budgets.get("inner_transport") is not None:
            candidates.append({"forced_inner_mode": "walk"})
            candidates.append({"forced_inner_mode": "metro"})
        excl = set(self._norm_text(m) for m in (constraints.get("excluded_inner_transport", []) or []))
        if excl or constraints.get("conditional_transport") or constraints.get("taxi_cars_equals") is not None:
            for m in ("metro", "walk", "taxi"):
                if m not in excl:
                    candidates.append({"forced_inner_mode": m})
        mode = constraints.get("intercity_mode")
        if isinstance(mode, str):
            candidates.append({"intercity_go_pref": mode, "intercity_back_pref": mode})
        if any(constraints.get(k) for k in (
            "hotel_nearby", "required_hotel_any_types", "required_hotel_all_types",
            "room_type", "hotel_type", "hotel_amenity", "required_hotels",
        )):
            for hi in range(0, 6):
                candidates.append({"hotel_index": hi})
        if any(constraints.get(k) for k in ("activity_time_windows", "timing_constraints", "stay_duration")):
            for off in range(1, 6):
                candidates.append({"attr_offset": off})
        for off in (1, 2, 3):
            candidates.append({"attr_offset": off})

        seen = set()
        unique = []
        for p in candidates:
            key = tuple(sorted(p.items()))
            if key not in seen:
                seen.add(key)
                unique.append(p)
        return unique

    def _random_params(self, rng, constraints):
        params = {
            "attr_offset": rng.randint(0, 12),
            "hotel_index": rng.randint(0, 4),
            "attr_per_day": rng.choice([2, 3, 4]),
            "visit_minutes": rng.choice(self._visit_minutes_candidates(constraints)),
        }
        forced = rng.choice([None, "metro", "walk", "taxi"])
        if forced is not None:
            params["forced_inner_mode"] = forced
        # A constraint-pinned intercity_mode (e.g. "must take the train") is a hard requirement in
        # oracle mode and effectively so in parsed no-oracle mode -- any candidate that deviates from
        # it fails acceptance outright, so randomizing that direction never helps and only burns a
        # restart. Only randomize a direction the constraints leave open.
        fixed_go_pref, fixed_back_pref = self._intercity_mode_preferences(constraints)
        if rng.random() < 0.35:
            if fixed_go_pref is None:
                params["intercity_go_pref"] = rng.choice(["airplane", "train"])
            if fixed_back_pref is None:
                params["intercity_back_pref"] = rng.choice(["airplane", "train"])
        if rng.random() < 0.35:
            params["rest_offset"] = rng.randint(0, 6)
        return params

    def _solve(self, query):
        """Per-query oracle-guided search: base build, guided repair, then random multi-start,
        keeping the best accepted plan found within budget; finally pack it.

        ``TPC_SOLVE_STOP_AT_ACCEPT`` is evaluation-tooling only and defaults off. When enabled, it
        returns as soon as any accepted plan is found instead of spending the remaining budget
        polishing preference score, producing a cheaper but preference-uncalibrated FPR signal, and
        it skips ``_pack_plan`` entirely -- so while this flag is enabled the ``_pack_plan`` repair
        passes (``_pin_timed_windows`` / ``_repair_transport_gaps``) never run, and it must not be
        used to measure them. When off (the default), this method's behavior is unchanged and
        ``_pack_plan`` runs as usual.

        ``TPC_SOLVE_STOP_AT_ACCEPT_PACKED`` is the finalization-preserving sibling of the above,
        also evaluation-tooling only and defaulting off. It stops the search at the first accept the
        same way, but *still* runs ``_pack_plan`` on the chosen plan, so the deterministic repair
        passes (window pinning, transport-gap repair) and the packing/densify pass all execute. It
        preserves the binary FPR signal -- a pre-pack accept stays accepted, and ``_pack_plan`` only
        commits changes that keep the checker accepting and do not regress the preference key -- so
        it is the mode to use for fast FPR-only measurement in a longer (e.g. 900 s) budget regime
        without skipping the repair passes under test. Like ``TPC_SOLVE_STOP_AT_ACCEPT``, its
        continuous/preference score is uncalibrated (the search stops before polishing).

        **The harness does set this one, for triage passes only** (2026-08-04,
        ``chinatravel/agent/phase2/sweeps.py``): under a shared whole-run envelope, an accepted
        plan for some *other* query is worth more than a better preference key for this one, and a
        query that accepts early hands its remaining slot back to the pass. Preference is recovered
        by the later polish pass, which can only improve on it. Repair and polish passes leave the
        flag off, so the full search still runs there. ``TPC_P2_FAST_TRIAGE=0`` disables it. If both flags are set, ``TPC_SOLVE_STOP_AT_ACCEPT``'s
        pack-skip wins; do not set both.

        ``TPC_SOLVE_CONVERGE_PATIENCE`` (``self.solve_converge_patience``) is a separate, opt-in
        early-convergence stop for the random-restart loop: once an accepted plan exists, if this
        many consecutive restarts fail to improve the best accepted preference key, the loop
        breaks early instead of exhausting ``max_restarts``/the wall-clock budget on a plateaued
        search. Default 0 disables it, so the restart loop's behavior is unchanged (byte-identical
        floor). Unlike ``TPC_SOLVE_STOP_AT_ACCEPT``, this does not stop at the first accept -- it
        keeps polishing preference score until it stalls.

        ``TPC_COMMONSENSE_FIRST`` (see ``_commonsense_first_enabled``) additionally tracks a third
        bucket, ``best_cs``: the best schema+commonsense-*valid* candidate seen, whatever its parsed
        pass count. When the search ends with nothing fully accepted and the search-key leader is
        commonsense-invalid, that bucket is emitted instead. This is a scoring-shape decision, not a
        relaxation of acceptance: ``eval_tpc`` credits a query's logical clauses only when it also
        passes commonsense (C-LPR is the conditional logical micro) and gives EPR-macro all-or-
        nothing per query, so a valid plan with fewer parsed passes scores strictly higher than an
        invalid leader. The probe is triple-bounded -- a free structural pre-filter
        (``_fast_commonsense_prefilter``), a confirmation count (``TPC_CS_CHECK_BUDGET``, default
        60), and a share of the solve budget spent on confirmations (``TPC_CS_CHECK_TIME_FRAC``,
        default 0.08) -- because each confirmation costs a restart that does not happen. Exhausting
        either bound degrades to the previous selection. Default off, so the deterministic floor is
        byte-identical.
        """
        self.reset_timeout_recovery_plan()
        self._last_solve_constraints = None
        # Reset (rather than leaving the previous query's values) so a timed-out solve -- which
        # never reaches the final assignment below -- reports "no data" instead of stale numbers.
        self.last_search_telemetry = {}
        stop_at_accept = os.environ.get("TPC_SOLVE_STOP_AT_ACCEPT", "0") not in ("", "0", "false", "False")
        stop_at_accept_packed = os.environ.get("TPC_SOLVE_STOP_AT_ACCEPT_PACKED", "0") not in ("", "0", "false", "False")
        variants = self._constraint_variants(query) or [None]
        rng = random.Random(restart_seed(query.get("uid", ""), self.seed_salt))
        init_key = (-1, float("-inf"), float("-inf"))
        accepted_init_key = (float("-inf"), float("-inf"), float("-inf"), float("-inf"))
        best = {"plan": None, "key": init_key, "constraints": None, "check": None, "params": None, "found_at": 0}
        best_accepted = {
            "plan": None,
            "key": accepted_init_key,
            "constraints": None,
            "check": None,
            "params": None,
            "found_at": 0,
        }
        # Best candidate that is schema- and commonsense-VALID, regardless of how many parsed
        # constraints it satisfies. Only populated under TPC_COMMONSENSE_FIRST. Rationale: when no
        # plan is fully accepted we still emit something, and eval_tpc credits that plan's logical
        # clauses only if it passes commonsense (C-LPR is the *conditional* logical micro), plus a
        # whole EPR-macro point. The old selection ranked unaccepted candidates by parsed-pass count
        # alone, so commonsense validity of the emitted plan was incidental -- 21 of 80 end-to-end
        # plans on the promoted row failed it while passing 8/9..11/13 of their logical clauses.
        best_cs = {
            "plan": None,
            "key": (float("-inf"), float("-inf"), float("-inf"), float("-inf"), float("-inf")),
            "constraints": None,
            "check": None,
            "params": None,
            "found_at": 0,
        }
        # Search telemetry (roadmap W4 step 0): pure observation, no behavior change. restarts is
        # assigned later in this method but read here by reference (both are locals of the same
        # function, so closures below see its live value regardless of source order).
        candidates_evaluated = 0
        commonsense_first = self._commonsense_first_enabled()
        # Each confirmed probe runs the full official commonsense evaluator (~300 ms), and inside a
        # wall-clock-bounded solve that time is paid for with a restart that does not happen. So the
        # probe is triple-bounded: a free structural pre-filter rejects hopeless candidates, a call
        # count caps the confirmations, and a share of the solve budget caps their total cost.
        try:
            cs_check_budget = int(os.environ.get("TPC_CS_CHECK_BUDGET", "60"))
        except ValueError:
            cs_check_budget = 60
        try:
            cs_time_frac = float(os.environ.get("TPC_CS_CHECK_TIME_FRAC", "0.08"))
        except ValueError:
            cs_time_frac = 0.08
        cs_time_cap = max(0.0, cs_time_frac) * max(float(self.solve_budget_sec), 0.0)
        cs_checks_left = [cs_check_budget if commonsense_first else 0]
        cs_time_spent = [0.0]
        # Memoized verdicts, keyed by object identity. The plan object is kept in the value so its
        # id cannot be recycled by the GC while the entry is live, and each distinct plan therefore
        # costs at most one full-evaluator call no matter how often it is consulted.
        cs_verdicts: dict[int, tuple] = {}

        def commonsense_valid(plan, *, prefilter=True):
            """Bounded, memoized schema+commonsense verdict. ``None`` means "not evaluated"."""
            if plan is None:
                return None
            cached = cs_verdicts.get(id(plan))
            if cached is not None:
                return cached[1]
            if prefilter and not self._fast_commonsense_prefilter(plan):
                # Free rejection: record it so the same plan is never re-screened.
                cs_verdicts[id(plan)] = (plan, False)
                return False
            if cs_checks_left[0] <= 0 or cs_time_spent[0] >= cs_time_cap:
                return None
            cs_checks_left[0] -= 1
            probe_start = time.time()
            try:
                verdict = bool(self._schema_ok(query, plan) and self._commonsense_ok(query, plan))
            except Exception:
                verdict = False
            cs_time_spent[0] += time.time() - probe_start
            cs_verdicts[id(plan)] = (plan, verdict)
            return verdict

        def probe_commonsense_valid(plan, constraints, check, params, passed, total):
            """Record ``plan`` in ``best_cs`` when it is schema+commonsense valid (bounded).

            The cheap ranking key is computed first and compared against the incumbent, so the
            expensive evaluator only runs for candidates that would actually improve the bucket. The
            gate deliberately is *not* "is this a new search-key leader": a commonsense-valid plan
            usually satisfies fewer parsed constraints than the leader (that is the whole reason the
            leader was chosen over it), so keying off the leader would never probe the plans this
            mechanism exists to find.
            """
            # Rank by how much logical credit the valid plan carries, then by preference.
            fraction = (passed / total) if total else 1.0
            cs_key = (fraction,) + tuple(self._accepted_eval_key(plan))
            if best_cs["plan"] is not None and cs_key <= best_cs["key"]:
                return
            if not commonsense_valid(plan):
                return
            best_cs.update(
                plan=plan, key=cs_key, constraints=constraints, check=check, params=params,
                found_at=restarts,
            )

        def commonsense_valid_export():
            """Bucket to export/emit when nothing is accepted: prefer a commonsense-valid plan.

            Returns ``None`` (keep the pre-change leader) when the umbrella is off, no valid
            candidate was found, the leader is itself that candidate, or the leader is known valid.
            An unevaluated leader (probe budget exhausted) also yields ``None``: without a verdict
            there is no evidence the swap helps, and the floor behavior is the safe default.
            """
            if not commonsense_first or best_cs["plan"] is None:
                return None
            if best["plan"] is None or best["plan"] is best_cs["plan"]:
                return None
            if commonsense_valid(best["plan"]) is not False:
                return None
            return best_cs

        def consider(plan, constraints, check, params):
            nonlocal candidates_evaluated
            candidates_evaluated += 1
            plan = self._sanitize_plan_for_grounding(plan, query)
            try:
                passed, total = check(plan)
            except Exception:
                passed, total = 0, 0
            search_key = (passed, self._eval_proxy(plan), -self._plan_total_cost(plan))
            updated = False
            if best["plan"] is None or search_key > best["key"]:
                best.update(plan=plan, key=search_key, constraints=constraints, check=check, params=params,
                            found_at=restarts)
                updated = True
            accepted = self._accepted(passed, total)
            if commonsense_first and not accepted:
                # An accepted plan is commonsense-valid by construction (the checker's +2 bonus) and
                # is handled by best_accepted, so only unaccepted candidates are probed here.
                probe_commonsense_valid(plan, constraints, check, params, passed, total)
                if best_cs["plan"] is plan:
                    updated = True
            if accepted:
                accepted_key = self._accepted_eval_key(plan)
                if best_accepted["plan"] is None or accepted_key > best_accepted["key"]:
                    best_accepted.update(
                        plan=plan,
                        key=accepted_key,
                        constraints=constraints,
                        check=check,
                        params=params,
                        found_at=restarts,
                    )
                    updated = True
            if updated:
                # Export whichever bucket actually produced best_now -- best_accepted may hold a
                # plan/constraints pair from an *earlier* call than this one (this call only
                # improved best["plan"], the unaccepted search-key leader). Using the current
                # candidate's constraints unconditionally here would mismatch a stale
                # best_accepted export, so pull constraints from the same bucket as best_now.
                # The recovery plan mirrors the final selection's preference order (accepted, then
                # commonsense-valid, then raw leader) so a timeout recovers the same quality of plan
                # the full solve would have emitted.
                cs_export = None
                if best_accepted["plan"] is not None:
                    best_now = best_accepted["plan"]
                    constraints_now = best_accepted["constraints"]
                else:
                    cs_export = commonsense_valid_export()
                    if cs_export is not None:
                        best_now = cs_export["plan"]
                        constraints_now = cs_export["constraints"]
                    else:
                        best_now = best["plan"]
                        constraints_now = best["constraints"]
                self._set_timeout_recovery_plan(best_now)
                self._last_solve_constraints = deepcopy(constraints_now)
                # Mirror the recovery-plan snapshot for search telemetry (roadmap W4 step 0
                # follow-up): a func_timeout kill lands mid-loop, before the authoritative
                # self.last_search_telemetry assignment below ever runs, which was silently
                # producing an empty {} for every timeout-recovered solve -- exactly the
                # budget-bound queries this telemetry exists to explain. stop_reason
                # "interrupted" marks this as a partial snapshot, not one of the four real
                # final stop reasons; a normal completion always overwrites it below.
                self.last_search_telemetry = {
                    "restarts_used": restarts,
                    "stop_reason": "interrupted",
                    "candidates_evaluated": candidates_evaluated,
                    "best_found_at_restart": restarts,
                }
            if accepted and (stop_at_accept or stop_at_accept_packed):
                raise _AcceptedEarlyStop()
            return accepted

        def out_of_budget():
            return time.time() - self.start_clock > self.solve_budget_sec

        restarts = 0
        stop_reason = None
        converged_stop = False
        try:
            for variant in variants:
                if out_of_budget():
                    break
                constraints = deepcopy(variant or {})
                check = self._make_checker(query, constraints)
                accepted_base = False
                try:
                    accepted_base = consider(self._build_plan(query, constraints=constraints), constraints, check, {})
                except Exception:
                    import traceback
                    traceback.print_exc()

                run_cp_after_pass = os.environ.get("TPC_CP_AFTER_PASS", "1") != "0"
                run_cp = (
                    os.environ.get("TPC_USE_CP_SOLVER", "1") != "0"
                    and not out_of_budget()
                    and (os.environ.get("TPC_CP_FORCE") == "1" or run_cp_after_pass or not accepted_base)
                )
                if run_cp:
                    try:
                        from agent.tpc_agent.cp_solver import solve_with_cp_sat

                        elapsed = time.time() - self.start_clock
                        remaining = max(1.0, self.solve_budget_sec - elapsed)
                        default_limit = min(30.0, remaining / 2.0)
                        cp_limit = float(os.environ.get("TPC_CP_TIME_LIMIT_SEC", str(default_limit)))
                        cp_limit = max(1.0, min(cp_limit, remaining))
                        cp_plan = solve_with_cp_sat(
                            self,
                            query,
                            constraints,
                            check,
                            cp_limit,
                            self._visit_minutes_candidates(constraints),
                        )
                        if cp_plan is not None:
                            consider(cp_plan, constraints, check, {"solver": "cp_sat"})
                    except Exception:
                        pass

                for params in self._repair_params(constraints):
                    if out_of_budget():
                        break
                    try:
                        consider(self._build_plan(query, constraints=constraints, params=params), constraints, check, params)
                    except Exception:
                        continue

                # Per-variant early-convergence tracking (roadmap step 5). Reset per variant since
                # a new constraint variant starts a fresh scoring landscape.
                stall_restarts = 0
                converged_stop = False
                while restarts < self.max_restarts and not out_of_budget():
                    restarts += 1
                    params = self._random_params(rng, constraints)
                    prev_accepted_key = best_accepted["key"]
                    try:
                        consider(self._build_plan(query, constraints=constraints, params=params), constraints, check, params)
                    except Exception:
                        continue
                    converge_patience = getattr(self, "solve_converge_patience", 0)
                    if converge_patience > 0 and best_accepted["plan"] is not None:
                        if best_accepted["key"] > prev_accepted_key:
                            stall_restarts = 0
                        else:
                            stall_restarts += 1
                            if stall_restarts >= converge_patience:
                                converged_stop = True
                                break
        except _AcceptedEarlyStop:
            stop_reason = "accepted_stop"
        else:
            # roadmap W4 step 0: pure observation of why the restart loop actually stopped, so a
            # later step can tell a budget-bound solve from one that plateaued or exhausted
            # max_restarts, none of which was previously recorded anywhere.
            if converged_stop:
                stop_reason = "converged"
            elif restarts >= self.max_restarts:
                stop_reason = "max_restarts"
            else:
                stop_reason = "budget"

        chosen = best_accepted if best_accepted["plan"] is not None else best
        if best_accepted["plan"] is None:
            # Nothing was fully accepted. Emitting a commonsense-invalid plan forfeits this query's
            # logical partial credit (C-LPR is scored conditionally on the commonsense pass) and its
            # EPR-macro point, so a commonsense-valid candidate with fewer parsed passes is worth
            # strictly more than an invalid leader. Off unless TPC_COMMONSENSE_FIRST is set.
            cs_export = commonsense_valid_export()
            if cs_export is not None:
                chosen = cs_export

        if chosen["plan"] is not None and chosen["check"] is not None and not stop_at_accept:
            packed = self._pack_plan(chosen["plan"], query, chosen["constraints"], chosen["check"], chosen["params"])
            if packed is not None:
                chosen["plan"] = packed

        self.last_search_telemetry = {
            "restarts_used": restarts,
            "stop_reason": stop_reason,
            "candidates_evaluated": candidates_evaluated,
            "best_found_at_restart": chosen.get("found_at", 0),
        }

        if chosen["plan"] is not None:
            resolved = self._sanitize_plan_for_grounding(chosen["plan"], query)
            self._set_timeout_recovery_plan(resolved)
            return resolved
        resolved = self._sanitize_plan_for_grounding(self._build_plan(query), query)
        self._set_timeout_recovery_plan(resolved)
        return resolved

    def _set_transport_context(self, constraints):
        """Set the per-solve attributes ``_get_transport`` reads, so retiming/insertion helpers can
        recompute inner-city legs consistently outside ``_build_plan``."""
        constraints = constraints or {}
        self._active_timing_constraints = constraints.get("timing_constraints", []) or []
        self._transport_constraints = {
            "excluded_inner_transport": constraints.get("excluded_inner_transport", []),
            "conditional_transport": constraints.get("conditional_transport", None),
            "taxi_cars_equals": constraints.get("taxi_cars_equals", None),
        }
        self._forced_inner_mode = None
        self._budget_limits = self._extract_budget_limits(constraints)

    def _pack_plan(self, plan, query, constraints, check, base_params):
        """Run the opt-in accepted-plan preference passes.

        The deterministic repair/pinning passes above may still run on the chosen candidate even
        when every packing flag is off. Actual preference packing is explicit and default-off:

        - ``TPC_PACK_DAV``: attraction top-up (plus ATT-protected hop rerouting via the insertion
          helpers' shortest-time transport lookup)
        - ``TPC_PACK_DDR``: breakfast/lunch/dinner top-up at grounded restaurants
        - ``TPC_PACK_HOTEL_BREAKFAST``: free hotel-breakfast stacking, intentionally separate
        - ``TPC_PACK_ATT``: count-preserving average-hop-time optimizer (faster modes, nearer POIs)

        Every committed edit must keep the full checker accepting and must not lower the accepted
        plan's preference key.
        """
        plan = self._sanitize_plan_for_grounding(plan, query)
        # Ground broken inner-city legs first (opt-in; roadmap step 4). A restart's forced/excluded
        # inner-transport exploration can leave an activity's inbound leg missing or mismatched
        # against the previous activity's position when no route existed under that forced mode --
        # the greedy build still appends the activity rather than abandoning the candidate (see
        # ``_get_transport`` callers in ``_build_plan``). This recomputes every such leg under the
        # full allowed mode set in one batched, all-or-nothing trial (many commonsense-transport
        # failures involve several broken legs in the same plan, so a per-leg trial that still
        # requires the *whole* plan to pass would never commit). Runs before the window pinning
        # below so that pass is not blocked by an unrelated grounding gap elsewhere in the plan. Off
        # by default, so the deterministic floor is unchanged.
        if self._repair_transport_gaps_enabled():
            self._set_transport_context(constraints or {})
            self._repair_transport_gaps(plan, query, constraints or {}, check)
        # Re-ground first/last intercity endpoint activities (opt-in). The commonsense
        # intercity checker requires day-1 activity[0] and last-day activity[-1] to be real
        # rows from intercity_transport.select(...), with matching IDs/times/prices.
        # TPC_REPAIR_DROP_TRAILING_STAY is its own independent flag (also umbrella-wired to
        # TPC_COMMONSENSE_FIRST) even though its logic lives inside _repair_intercity_endpoints,
        # so either flag alone must reach the function.
        if self._repair_intercity_enabled() or self._repair_drop_trailing_stay_enabled():
            self._set_transport_context(constraints or {})
            self._repair_intercity_endpoints(plan, query, constraints or {}, check)
        # Pin named timed-visit POIs into their clause windows first (opt-in; roadmap G8). This runs
        # *before* the acceptance gate below because a window-failing plan is by definition not yet
        # accepted, and each pin is individually gated (committed only if the full checker then
        # accepts and the preference key does not regress) -- so it can flip a sole-window-blocker to
        # accepted, which then lets the packing/densify passes lift its preference score too. Off by
        # default, so the deterministic floor is unchanged.
        if self._pin_windows_enabled():
            self._set_transport_context(constraints or {})
            self._pin_timed_windows(plan, query, constraints or {}, check)
        # Window-anchored day relayout for whatever the pin passes could not reach (opt-in; roadmap
        # P1). Same placement rationale as the pin above -- it runs before the acceptance gate
        # because a window-failing plan is by definition not yet accepted -- and the same
        # acceptance-gated, deepcopy-trialed commit discipline. Off by default, so the deterministic
        # floor is unchanged.
        if self._window_anchor_enabled():
            self._set_transport_context(constraints or {})
            self._anchor_timed_windows(plan, query, constraints or {}, check)
        if self._window_push_enabled():
            self._set_transport_context(constraints or {})
            self._push_timed_windows(plan, query, constraints or {}, check)
        if self._window_insert_enabled():
            self._set_transport_context(constraints or {})
            self._insert_absent_timed_window_pois(plan, query, constraints or {}, check)
        # Cross-day relocation runs last among the window moves (opt-in; roadmap P25): it is the
        # most drastic (it deletes and re-inserts a real activity, not just a re-time), so it
        # should only ever act on what anchor/push/insert already could not reach. Off by default,
        # so the deterministic floor is unchanged.
        if self._window_relocate_day_enabled():
            self._set_transport_context(constraints or {})
            self._relocate_timed_windows_across_days(plan, query, constraints or {}, check)
        if not self._accepted(*check(plan)):
            return plan
        if not self._packing_enabled():
            return plan
        best_plan = plan
        best_key = self._accepted_eval_key(plan)
        best_attrs, best_meals = self._activity_counts(plan)
        if self._pack_dav_enabled():
            for extra in (3, 4):
                if time.time() - self.start_clock > self.solve_budget_sec:
                    break
                params = dict(base_params or {})
                params["attr_per_day"] = extra
                try:
                    cand = self._build_plan(query, constraints=constraints, params=params)
                except Exception:
                    continue
                cand = self._sanitize_plan_for_grounding(cand, query)
                if not self._accepted(*check(cand)):
                    continue
                cand_key = self._accepted_eval_key(cand)
                c_attrs, c_meals = self._activity_counts(cand)
                if c_attrs > best_attrs and cand_key >= best_key:
                    best_plan = cand
                    best_key = cand_key
                    best_attrs, best_meals = c_attrs, c_meals
        dense = self._densify_plan(best_plan, query, constraints, check)
        return self._sanitize_plan_for_grounding(dense, query)

    def _activity_start_position(self, activity):
        if activity.get("type") in ("airplane", "train"):
            return str(activity.get("start", "") or activity.get("From", ""))
        return str(activity.get("position", "") or activity.get("start", ""))

    def _activity_end_position(self, activity):
        if activity.get("type") in ("airplane", "train"):
            return str(activity.get("end", "") or activity.get("To", ""))
        return str(activity.get("position", "") or activity.get("end", ""))

    def _poi_open_bounds(self, poi):
        open_min = poi.get("open_min", None)
        close_min = poi.get("close_min", None)
        if open_min is None:
            try:
                open_min = time_to_minutes(str(poi.get("opentime", "00:00")))
            except Exception:
                open_min = 0
        if close_min is None:
            close_raw = str(poi.get("endtime", "24:00"))
            try:
                close_min = 24 * 60 if close_raw == "24:00" else time_to_minutes(close_raw)
            except Exception:
                close_min = 24 * 60
        if close_min <= open_min:
            close_min += 24 * 60
        return int(open_min), int(close_min)

    def _lookup_poi_open_bounds(self, city, position, activity_type, tickets=None):
        """Real WorldEnv opening/closing bounds (minutes-of-day, see ``_poi_open_bounds``) for a
        named POI -- the feasibility fact the Stage 3 LLM refine prompt and edit grounding were
        missing (roadmap Next step 7, bucket 1: proposed edits fail to ground because nothing told
        the model, or the edit applier, what hours the POI is actually open). Returns ``None`` when
        the environment/position can't be resolved: a bare-agent unit test (``self.env is None``),
        an unrecognized name, or an accommodation-based meal (``tickets == 0``, e.g.
        ``_make_hotel_breakfast``'s free hotel breakfast) -- that meal's ``position`` is the hotel's
        name, not a restaurant, and has no tracked hours in this dataset; looking it up against the
        restaurant pool risks a spurious name match instead."""
        if self.env is None or not position:
            return None
        if activity_type in ("breakfast", "lunch", "dinner") and tickets == 0:
            return None
        if activity_type == "attraction":
            pools = [self.env.attractions]
        elif activity_type in ("breakfast", "lunch", "dinner"):
            pools = [self.env.restaurants]
        else:
            return None
        for pool in pools:
            # Pools expose ``.data[city]`` (a DataFrame) directly; prefer it over ``.select()``,
            # which would otherwise scan the column twice (once to build ``.select``'s bool mask,
            # once here to find the name match). Fall back to ``.select()`` for stand-ins (test
            # fakes) that only implement that method.
            data_by_city = getattr(pool, "data", None)
            if isinstance(data_by_city, dict) and city in data_by_city:
                df = data_by_city[city]
            else:
                try:
                    df = pool.select(city, "name", lambda x: True)
                except Exception:
                    continue
            for i in range(len(df)):
                try:
                    row = df.iloc[i]
                    if self._match_constraint_text(str(row.get("name", "")), position):
                        return self._poi_open_bounds(row)
                except Exception:
                    continue
        return None

    def _refine_feasible_windows(self, query, plan):
        """Per-activity feasibility context for the Stage 3 refine prompt: each meal/attraction
        activity's real WorldEnv opening/closing bounds, plus the time actually available given its
        neighbours (mirrors the arrival/next-start calc ``_try_pin_activity`` already uses to decide
        whether a retiming has slack). This is exactly what an LLM proposing a ``shift_activity_window``
        edit needs to avoid asking for a time the environment cannot ground -- roadmap Next step 7's
        biggest ``no_groundable_edits`` bucket. Never raises; a POI/leg that can't be resolved is
        simply omitted from that activity's entry, not fabricated."""
        city = str(query.get("target_city", ""))
        people = int(query.get("people_number", 1) or 1)
        out = []
        for day in plan.get("itinerary", []) or []:
            if not isinstance(day, dict):
                continue
            activities = day.get("activities", []) or []
            for idx, act in enumerate(activities):
                if not isinstance(act, dict) or act.get("type") not in self._WINDOW_ACTIVITY_TYPES:
                    continue
                position = str(act.get("position", ""))
                if not position:
                    continue
                entry = {"day": day.get("day"), "position": position}
                bounds = self._lookup_poi_open_bounds(city, position, act.get("type"), act.get("tickets"))
                if bounds is not None:
                    open_min, close_min = bounds
                    entry["open"] = minutes_to_time(open_min % (24 * 60))
                    entry["close"] = "24:00" if close_min >= 24 * 60 else minutes_to_time(close_min)
                if idx > 0 and activities[idx - 1].get("type") not in ("airplane", "train"):
                    prev = activities[idx - 1]
                    try:
                        _legs, arrival = self._get_transport(
                            self.env, city, self._activity_end_position(prev), position,
                            str(prev.get("end_time", "")), people)
                        if arrival is not None:
                            entry["earliest_reachable"] = arrival
                    except Exception:
                        pass
                if idx + 1 < len(activities) and activities[idx + 1].get("type") not in ("airplane", "train"):
                    next_start = str(activities[idx + 1].get("start_time", ""))
                    if next_start:
                        entry["must_end_before_next_starts_at"] = next_start
                out.append(entry)
        return out

    def _densify_dwell_minutes(self, poi, kind):
        if kind != "attraction":
            default_meal_dwell = "45" if self.use_oracle else "60"
            return int(os.environ.get("TPC_DENSIFY_MEAL_DWELL", default_meal_dwell))
        # Attraction visit length used when packing idle gaps. The verifier enforces no
        # minimum duration (only open-hours containment + positive duration), so a shorter
        # dwell lets more attractions fit tight gaps and lifts DAV; default is the
        # compute-node smoke/full-score winner.
        default_attr_dwell = "50" if self.use_oracle else "60"
        return int(os.environ.get("TPC_DENSIFY_ATTR_DWELL", default_attr_dwell))

    def _inner_activity_minutes(self, activity):
        total = 0
        for leg in activity.get("transports", []) or []:
            try:
                total += time_to_minutes(str(leg["end_time"])) - time_to_minutes(str(leg["start_time"]))
            except Exception:
                continue
        return total

    def _haversine_km(self, a, b):
        try:
            lat1 = math.radians(float(a["lat"]))
            lon1 = math.radians(float(a["lon"]))
            lat2 = math.radians(float(b["lat"]))
            lon2 = math.radians(float(b["lon"]))
        except Exception:
            return float("inf")
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        s = math.sin(dlat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
        return 6371.0 * 2.0 * math.atan2(math.sqrt(s), math.sqrt(max(0.0, 1.0 - s)))

    def _day_gaps(self, activities, win_open, win_close, min_minutes):
        gaps = []
        for idx in range(len(activities) - 1):
            try:
                prev_end = time_to_minutes(str(activities[idx].get("end_time", "")))
                next_start = time_to_minutes(str(activities[idx + 1].get("start_time", "")))
            except Exception:
                continue
            gap_start = max(prev_end, win_open)
            gap_end = min(next_start, win_close)
            if gap_end - gap_start >= min_minutes:
                gaps.append((idx, gap_start, gap_end))
        return gaps

    def _env_time_minutes(self, name, default):
        raw = str(os.environ.get(name, default))
        try:
            if ":" in raw:
                return time_to_minutes(raw)
            value = float(raw)
            if 0 <= value <= 24:
                return int(value * 60)
            return int(value)
        except Exception:
            return time_to_minutes(default)

    def _compress_activity_windows(self, plan, check):
        if os.environ.get("TPC_DENSIFY_COMPRESS_BEFORE", "0") != "1":
            return
        try:
            attr_dwell = max(1, int(os.environ.get(
                "TPC_DENSIFY_COMPRESS_ATTR_DWELL",
                os.environ.get("TPC_DENSIFY_ATTR_DWELL", "60"),
            )))
            meal_dwell = max(1, int(os.environ.get(
                "TPC_DENSIFY_COMPRESS_MEAL_DWELL",
                os.environ.get("TPC_DENSIFY_MEAL_DWELL", "60"),
            )))
        except Exception:
            return
        for day in plan.get("itinerary", []) or []:
            for activity in day.get("activities", []) or []:
                kind = activity.get("type")
                if kind == "attraction":
                    target = attr_dwell
                elif kind in ("breakfast", "lunch", "dinner"):
                    target = meal_dwell
                else:
                    continue
                try:
                    start_min = time_to_minutes(str(activity.get("start_time", "")))
                    end_min = time_to_minutes(str(activity.get("end_time", "")))
                except Exception:
                    continue
                new_end = start_min + target
                if new_end >= end_min:
                    continue
                old_end = activity.get("end_time")
                activity["end_time"] = minutes_to_time(new_end)
                try:
                    if self._accepted(*check(plan)):
                        continue
                except Exception:
                    pass
                activity["end_time"] = old_end

    def _find_hotel_for_day(self, plan, day_idx):
        itinerary = plan.get("itinerary", []) or []
        for scan in range(day_idx, -1, -1):
            activities = itinerary[scan].get("activities", []) or []
            for activity in reversed(activities):
                if activity.get("type") == "accommodation" and activity.get("position"):
                    return str(activity["position"])
        for scan in range(day_idx + 1, len(itinerary)):
            activities = itinerary[scan].get("activities", []) or []
            for activity in activities:
                if activity.get("type") == "accommodation" and activity.get("position"):
                    return str(activity["position"])
        return None

    def _insert_breakfast(self, plan, day_idx, hotel_name, check):
        activities = plan["itinerary"][day_idx].get("activities", [])
        if not activities:
            return False
        if day_idx == 0 and activities[0].get("type") in ("airplane", "train"):
            return False
        try:
            first_act = activities[0]
            first_transports = first_act.get("transports", []) or []
            if first_transports:
                anchor_raw = first_transports[0].get("start_time", "")
            else:
                anchor_raw = first_act.get("start_time", "00:00")
            default_hotel_breakfast_end = "09:00" if self.use_oracle else "08:30"
            end_min = min(
                time_to_minutes(str(anchor_raw)),
                self._env_time_minutes("TPC_DENSIFY_HOTEL_BREAKFAST_END", default_hotel_breakfast_end),
            )
            default_meal_dwell = "45" if self.use_oracle else "60"
            dwell = max(1, int(os.environ.get(
                "TPC_DENSIFY_HOTEL_BREAKFAST_DWELL",
                os.environ.get("TPC_DENSIFY_MEAL_DWELL", default_meal_dwell),
            )))
            start_min = end_min - dwell
            if start_min < time_to_minutes("06:00"):
                return False
        except Exception:
            return False
        before_key = self._accepted_eval_key(plan)
        activity = self._make_hotel_breakfast(hotel_name, minutes_to_time(start_min), minutes_to_time(end_min))
        activities.insert(0, activity)
        try:
            if self._accepted(*check(plan)) and self._accepted_eval_key(plan) > before_key:
                return True
        except Exception:
            pass
        del activities[0]
        return False

    def _insert_restaurant_breakfast(self, plan, day_idx, restaurants, city, people, check, used_restaurants=None):
        activities = plan["itinerary"][day_idx].get("activities", [])
        if not activities:
            return None
        window = (6 * 60, self._env_time_minutes("TPC_DENSIFY_BREAKFAST_WIN_CLOSE", "09:00"))
        default_gap = "45" if self.use_oracle else "60"
        meal_gap_min = max(1, int(os.environ.get("TPC_DENSIFY_MEAL_GAP_MIN", default_gap)))
        for restaurant in restaurants:
            r_name = self._norm_text(restaurant.get("name", ""))
            if not r_name or (used_restaurants is not None and r_name in used_restaurants):
                continue
            if self._insert_activity_before_first(plan, day_idx, restaurant, "breakfast", window, city, people, check):
                return r_name
            for prev_idx, _gap_start, _gap_end in self._day_gaps(activities, window[0], window[1], meal_gap_min):
                if self._insert_activity(plan, day_idx, prev_idx, restaurant, "breakfast", window, city, people, check):
                    return r_name
            if self._insert_activity_after_last(plan, day_idx, restaurant, "breakfast", window, city, people, check):
                return r_name
        return None

    def _insertion_commit_allowed(self, plan, before, before_key, check, repair_context=None):
        """Preserve legacy insert scoring unless a named repair supplied its original plan."""
        if not self._accepted(*check(plan)) or self._activity_counts(plan) <= before:
            return False
        if repair_context is None:
            return self._accepted_eval_key(plan) >= before_key
        original, query, was_accepted = repair_context
        return self._repair_commit_allowed(original, plan, query, check, was_accepted)

    def _insert_activity_before_first(self, plan, day_idx, poi, kind, window, city, people, check,
                                      repair_context=None):
        activities = plan["itinerary"][day_idx].get("activities", [])
        if not activities:
            return False
        first_act = activities[0]
        next_pos = self._activity_start_position(first_act)
        poi_name = str(poi.get("name", ""))
        if not next_pos or not poi_name:
            return False

        prev_pos = None
        anchor_min = None
        transports_in = first_act.get("transports", []) or []
        if transports_in:
            first_leg = transports_in[0]
            prev_pos = str(first_leg.get("start", "") or "")
            try:
                anchor_min = time_to_minutes(str(first_leg.get("start_time", "")))
            except Exception:
                anchor_min = None
        if (not prev_pos or anchor_min is None) and day_idx > 0:
            hotel_name = self._find_hotel_for_day(plan, day_idx)
            if hotel_name:
                prev_pos = hotel_name
                anchor_min = time_to_minutes("08:30")
        if not prev_pos or anchor_min is None:
            return False

        try:
            next_start_min = time_to_minutes(str(first_act.get("start_time", "")))
        except Exception:
            return False
        if anchor_min >= next_start_min:
            return False

        win_open, win_close = window
        poi_open, poi_close = self._poi_open_bounds(poi)
        try:
            transports_to_poi, arrival = self._best_transport_via_get_transport(
                city, prev_pos, poi_name, minutes_to_time(anchor_min), people)
        except Exception:
            return False
        if transports_to_poi is None or arrival is None:
            return False
        try:
            arrival_min = time_to_minutes(str(arrival))
        except Exception:
            return False

        start_min = max(arrival_min, win_open, poi_open)
        dwell = self._densify_dwell_minutes(poi, kind)
        end_min = start_min + dwell
        if end_min > min(win_close, poi_close):
            return False

        end_time = minutes_to_time(end_min)
        try:
            transports_to_next, next_arrival = self._best_transport_via_get_transport(
                city, poi_name, next_pos, end_time, people)
        except Exception:
            return False
        if transports_to_next is None or next_arrival is None:
            return False
        try:
            if time_to_minutes(str(next_arrival)) > next_start_min:
                return False
        except Exception:
            return False

        start_time = minutes_to_time(start_min)
        if kind == "attraction":
            activity = self._make_attraction_activity(poi, people, start_time, end_time, transports_to_poi)
        else:
            activity = self._make_meal_activity(kind, poi, people, start_time, end_time, transports_to_poi)

        before = self._activity_counts(plan)
        before_key = self._accepted_eval_key(plan)
        old_first_transports = deepcopy(first_act.get("transports", []))
        first_act["transports"] = transports_to_next
        activities.insert(0, activity)
        try:
            if self._insertion_commit_allowed(plan, before, before_key, check, repair_context):
                return True
        except Exception:
            pass
        del activities[0]
        first_act["transports"] = old_first_transports
        return False

    def _insert_activity_after_last(self, plan, day_idx, poi, kind, window, city, people, check,
                                    repair_context=None):
        activities = plan["itinerary"][day_idx].get("activities", [])
        if not activities:
            return False
        last_act = activities[-1]
        prev_pos = self._activity_end_position(last_act)
        poi_name = str(poi.get("name", ""))
        if not prev_pos or not poi_name:
            return False
        if last_act.get("type") in ("airplane", "train"):
            return False

        # Preserve final intercity departure on the last day.
        itinerary = plan.get("itinerary", []) or []
        if day_idx == len(itinerary) - 1:
            return False

        try:
            start_anchor_min = time_to_minutes(str(last_act.get("end_time", "")))
        except Exception:
            return False

        win_open, win_close = window
        poi_open, poi_close = self._poi_open_bounds(poi)
        try:
            transports_to_poi, arrival = self._best_transport_via_get_transport(
                city, prev_pos, poi_name, minutes_to_time(start_anchor_min), people)
        except Exception:
            return False
        if transports_to_poi is None or arrival is None:
            return False
        try:
            arrival_min = time_to_minutes(str(arrival))
        except Exception:
            return False

        start_min = max(arrival_min, win_open, poi_open)
        dwell = self._densify_dwell_minutes(poi, kind)
        end_min = start_min + dwell
        if end_min > min(win_close, poi_close):
            return False

        start_time = minutes_to_time(start_min)
        end_time = minutes_to_time(end_min)
        if kind == "attraction":
            activity = self._make_attraction_activity(poi, people, start_time, end_time, transports_to_poi)
        else:
            activity = self._make_meal_activity(kind, poi, people, start_time, end_time, transports_to_poi)

        before = self._activity_counts(plan)
        before_key = self._accepted_eval_key(plan)
        activities.append(activity)
        try:
            if self._insertion_commit_allowed(plan, before, before_key, check, repair_context):
                return True
        except Exception:
            pass
        activities.pop()
        return False

    def _insert_activity(self, plan, day_idx, prev_idx, poi, kind, window, city, people, check,
                         repair_context=None):
        activities = plan["itinerary"][day_idx].get("activities", [])
        if prev_idx < 0 or prev_idx + 1 >= len(activities):
            return False
        prev_act = activities[prev_idx]
        next_act = activities[prev_idx + 1]
        prev_pos = self._activity_end_position(prev_act)
        next_pos = self._activity_start_position(next_act)
        poi_name = str(poi.get("name", ""))
        if not prev_pos or not next_pos or not poi_name:
            return False
        try:
            prev_end_min = time_to_minutes(str(prev_act.get("end_time", "")))
            next_start_min = time_to_minutes(str(next_act.get("start_time", "")))
        except Exception:
            return False
        if prev_end_min >= next_start_min:
            return False

        win_open, win_close = window
        poi_open, poi_close = self._poi_open_bounds(poi)
        try:
            transports_in, arrival = self._best_transport_via_get_transport(
                city, prev_pos, poi_name, str(prev_act.get("end_time", "")), people)
        except Exception:
            return False
        if transports_in is None or arrival is None:
            return False
        try:
            arrival_min = time_to_minutes(str(arrival))
        except Exception:
            return False
        start_min = max(arrival_min, win_open, poi_open)
        dwell = self._densify_dwell_minutes(poi, kind)
        end_min = start_min + dwell
        if end_min > min(win_close, poi_close):
            return False

        start_time = minutes_to_time(start_min)
        end_time = minutes_to_time(end_min)
        try:
            transports_out, next_arrival = self._best_transport_via_get_transport(
                city, poi_name, next_pos, end_time, people)
        except Exception:
            return False
        if transports_out is None or next_arrival is None:
            return False
        try:
            if time_to_minutes(str(next_arrival)) > next_start_min:
                return False
        except Exception:
            return False

        if kind == "attraction":
            activity = self._make_attraction_activity(poi, people, start_time, end_time, transports_in)
        else:
            activity = self._make_meal_activity(kind, poi, people, start_time, end_time, transports_in)

        before = self._activity_counts(plan)
        before_key = self._accepted_eval_key(plan)
        old_next_transports = deepcopy(next_act.get("transports", []))
        next_act["transports"] = transports_out
        activities.insert(prev_idx + 1, activity)
        try:
            if self._insertion_commit_allowed(plan, before, before_key, check, repair_context):
                return True
        except Exception:
            pass
        del activities[prev_idx + 1]
        next_act["transports"] = old_next_transports
        return False

    def _topup_hotel_breakfasts(self, plan, check):
        """Reach three meals/day by inserting free hotel breakfasts next to the day's hotel.

        This mirrors the Phase 1 maxpack loophole behind an explicit flag. Each day-level block is
        tried all at once and reverted unless the full checker still accepts and the accepted-plan
        preference key does not regress.
        """
        changed = False
        slots = [
            ("06:00", "06:30"),
            ("06:35", "07:05"),
            ("07:10", "07:40"),
            ("07:45", "08:15"),
            ("08:20", "08:50"),
        ]
        for day_idx, day in enumerate(plan.get("itinerary", []) or []):
            activities = day.get("activities", []) or []
            meal_count = sum(
                1 for activity in activities
                if activity.get("type") in ("breakfast", "lunch", "dinner")
            )
            if meal_count >= 3:
                continue
            hotel = self._find_hotel_for_day(plan, day_idx)
            if not hotel:
                continue
            hotel_name = self._norm_text(hotel)
            insert_at = None
            for idx, activity in enumerate(activities):
                if (
                    self._norm_text(activity.get("position")) == hotel_name
                    and activity.get("type") in ("accommodation", "breakfast")
                ):
                    insert_at = idx + 1
                    break
            if insert_at is None:
                if (
                    activities
                    and self._norm_text(self._activity_start_position(activities[0])) == hotel_name
                    and activities[0].get("type") not in ("train", "airplane")
                ):
                    insert_at = 0
                else:
                    continue

            need = 3 - meal_count
            before_key = self._accepted_eval_key(plan)
            snapshot = deepcopy(activities)
            block = [
                self._make_hotel_breakfast(hotel, slots[idx % len(slots)][0], slots[idx % len(slots)][1])
                for idx in range(need)
            ]
            activities[insert_at:insert_at] = block
            try:
                new_meal_count = sum(
                    1 for activity in activities
                    if activity.get("type") in ("breakfast", "lunch", "dinner")
                )
                if (
                    self._accepted(*check(plan))
                    and new_meal_count > meal_count
                    and self._accepted_eval_key(plan) >= before_key
                ):
                    changed = True
                    continue
            except Exception:
                pass
            day["activities"] = snapshot
        return changed

    def _transport_leg_valid(self, activity, from_pos):
        """Mirror ``Is_space_correct``'s edge check: the activity's inbound leg must start at
        ``from_pos`` and end at the activity's own position (both compared via the checker's own
        ``normalize_poi_name`` alias table, not the lower-cased ``_norm_text``)."""
        to_pos = self._activity_start_position(activity)
        legs = activity.get("transports") or []
        if not legs:
            return False
        try:
            leg_start = normalize_poi_name(str(legs[0].get("start", "")))
            leg_end = normalize_poi_name(str(legs[-1].get("end", "")))
        except Exception:
            return False
        return (
            leg_start == normalize_poi_name(str(from_pos))
            and leg_end == normalize_poi_name(str(to_pos))
        )

    def _fix_transport_leg_if_broken(self, activity, from_pos, depart_time, city, people):
        """Recompute one activity's inbound leg if it does not already connect ``from_pos`` to the
        activity's position. Only commits within the caller's trial dict (mutates ``activity`` in
        place); the caller re-validates the whole plan afterward. Skipped (returns False, activity
        left untouched) when there is nothing to anchor from, no route exists under the full
        allowed mode set, or the recomputed arrival would land after the activity's own start_time
        -- this repair never shifts timing, only fills/corrects the leg itself."""
        if self._transport_leg_valid(activity, from_pos):
            return False
        to_pos = self._activity_start_position(activity)
        if not from_pos or not to_pos or not depart_time:
            return False
        try:
            transports, arrival = self._get_transport_resilient(self.env, city, from_pos, to_pos, depart_time, people)
        except Exception:
            return False
        if transports is None or arrival is None:
            return False
        cur_start = str(activity.get("start_time", ""))
        try:
            if cur_start and time_to_minutes(str(arrival)) > time_to_minutes(cur_start):
                return False
        except Exception:
            return False
        activity["transports"] = transports
        return True

    def _repair_transport_gaps(self, plan, query, constraints, check):
        """Ground every broken inner-city leg in one batched, acceptance-gated trial (roadmap step
        4, the "Invalid Transport information across positions" commonsense residual).

        Walks the plan in checker order (continuous across day boundaries, exactly like
        ``Is_space_correct``'s ``position_list``), skipping the very first activity of the whole
        plan and any intercity activity (their own transport shape is out of this move's scope --
        see ``_sanitize_plan_for_grounding`` for mid-itinerary intercity cleanup). For every other
        activity whose position differs from the previous activity's, recomputes the inbound leg
        under the full allowed mode set (``_forced_inner_mode`` cleared, so an exploratory
        restart's forced/excluded mode that had no route for this particular pair no longer blocks
        it; real constraint exclusions still apply via ``_set_transport_context``) when the
        existing leg does not already connect the two positions. All fixes land in one deepcopy
        trial and are committed together only if the commit rule allows -- never a partial commit,
        since a single remaining broken leg would still fail the full checker on its own. See
        ``_repair_commit_allowed``: an already-accepted plan keeps the strict
        still-accepted-and-no-preference-regression rule, while an *unaccepted* plan (only under
        ``TPC_COMMONSENSE_FIRST``) commits when the repair turns it commonsense-valid without losing
        parsed-constraint passes. A grounded leg has a real, nonzero cost where the broken original
        had none, so the "preference must not regress" guard only applies when the *starting* plan was
        already accepted: turning an invalid plan valid is a pure win regardless of the small cost
        added, matching the invariant's own wording (never trade a *valid* plan for a higher score) --
        it does not forbid spending cost to make an invalid plan valid at all."""
        city = query.get("target_city", "")
        people = int(query.get("people_number", 1) or 1)
        saved_forced_mode = getattr(self, "_forced_inner_mode", None)
        self._forced_inner_mode = None
        try:
            was_accepted = self._accepted(*check(plan))
            trial = deepcopy(plan)
            changed = False
            prev_pos = None
            prev_end = None
            for day in trial.get("itinerary", []) or []:
                for activity in day.get("activities", []) or []:
                    is_intercity = activity.get("type") in ("airplane", "train")
                    if prev_pos is not None and not is_intercity:
                        cur_pos = self._activity_start_position(activity)
                        # Compare via normalize_poi_name, exactly like Is_space_correct's own
                        # position_list check -- two alias-equivalent names (e.g. a POI listed
                        # under both a short and long form) are the same position to the checker,
                        # so raw-string inequality here would misfire a repair (and its cost) where
                        # none is required.
                        if cur_pos and normalize_poi_name(cur_pos) != normalize_poi_name(prev_pos):
                            if self._fix_transport_leg_if_broken(
                                activity, prev_pos, prev_end, city, people
                            ):
                                changed = True
                    prev_pos = self._activity_end_position(activity)
                    prev_end = str(activity.get("end_time", "")) or prev_end
            if not changed:
                return
            if not self._repair_commit_allowed(plan, trial, query, check, was_accepted):
                return
            plan["itinerary"] = trial["itinerary"]
        except Exception:
            pass
        finally:
            self._forced_inner_mode = saved_forced_mode

    def _intercity_mode_preferences(self, constraints):
        outbound_pref = return_pref = None
        intercity_mode = (constraints or {}).get("intercity_mode", None)
        if isinstance(intercity_mode, dict):
            outbound_pref = intercity_mode.get("outbound", None)
            return_pref = intercity_mode.get("return", None)
        elif isinstance(intercity_mode, str):
            outbound_pref = return_pref = intercity_mode
        return outbound_pref, return_pref

    def _intercity_mode_order(self, existing_type, preferred_mode):
        order = []
        if existing_type in ("airplane", "train"):
            order.append(existing_type)
        pref = self._norm_text(preferred_mode)
        if pref in ("airplane", "flight", "plane"):
            order.append("airplane")
        elif pref in ("train", "rail"):
            order.append("train")
        for mode in ("airplane", "train"):
            if mode not in order:
                order.append(mode)
        return order

    def _iter_intercity_rows(self, from_city, to_city, mode):
        try:
            df = self.env.intercitytransport.select(from_city, to_city, mode)
        except Exception:
            return []
        if df is None or isinstance(df, str):
            return []
        rows = []
        try:
            for i in range(len(df)):
                rows.append(df.iloc[i].to_dict())
        except Exception:
            return []
        return rows

    def _intercity_activity_matches_row(self, activity, row, mode):
        if not isinstance(activity, dict) or mode not in ("airplane", "train"):
            return False
        if activity.get("type") != mode:
            return False
        required_id = "FlightID" if mode == "airplane" else "TrainID"
        forbidden_id = "TrainID" if mode == "airplane" else "FlightID"
        if required_id not in activity or forbidden_id in activity:
            return False
        try:
            row_price = float(row.get("Cost"))
            activity_price = float(activity.get("price"))
            tickets = float(activity.get("tickets"))
            activity_cost = float(activity.get("cost"))
        except (TypeError, ValueError):
            return False
        return (
            activity.get(required_id) == row.get(required_id)
            and activity.get("start") == row.get("From")
            and activity.get("end") == row.get("To")
            and activity.get("start_time") == row.get("BeginTime")
            and activity.get("end_time") == row.get("EndTime")
            and activity_price == row_price
            and activity_cost == row_price * tickets
        )

    def _endpoint_is_grounded(self, activity, from_city, to_city):
        if not self._is_intercity_activity(activity):
            return False
        mode = str(activity.get("type", ""))
        if mode not in ("airplane", "train"):
            return False
        for row in self._iter_intercity_rows(from_city, to_city, mode):
            if self._intercity_activity_matches_row(activity, row, mode):
                return True
        return False

    def _safe_time_minutes(self, value):
        try:
            return time_to_minutes(str(value))
        except Exception:
            return None

    def _safe_inbound_transport(self, city, from_pos, to_pos, depart_time, latest_arrival, people):
        if not to_pos:
            return None, None
        if from_pos == to_pos:
            return [], depart_time
        try:
            transports, arrival = self._get_transport(
                self.env, city, from_pos, to_pos, depart_time, people)
        except Exception:
            return None, None
        if transports is None or arrival is None:
            return None, None
        arr_min = self._safe_time_minutes(arrival)
        if arr_min is None:
            return None, None
        if latest_arrival is not None and arr_min > latest_arrival:
            return None, None
        return transports, arrival

    def _repair_intercity_endpoints(self, plan, query, constraints, check):
        """Repair first/last intercity endpoint grounding in one commit-gated trial.

        Commit rule is shared with the transport-gap pass (``_repair_commit_allowed``): an accepted
        input keeps the strict still-accepted-and-no-preference-regression rule, while an unaccepted
        input (only under ``TPC_COMMONSENSE_FIRST``) commits when the re-grounding turns the plan
        commonsense-valid without losing parsed-constraint passes."""
        if self.env is None or not isinstance(plan, dict):
            return
        itinerary = plan.get("itinerary", []) or []
        if not isinstance(itinerary, list) or len(itinerary) == 0:
            return

        start_city = str(query.get("start_city", "") or "")
        target_city = str(query.get("target_city", "") or "")
        if not start_city or not target_city:
            return
        people = int(query.get("people_number", 1) or 1)
        outbound_pref, return_pref = self._intercity_mode_preferences(constraints)

        try:
            was_accepted = self._accepted(*check(plan))
        except Exception:
            was_accepted = False
        trial = deepcopy(plan)
        changed = False

        # Outbound endpoint: day-1 first activity.
        first_day = (trial.get("itinerary", []) or [{}])[0] or {}
        first_day_acts = first_day.get("activities", []) or []
        first_act = first_day_acts[0] if first_day_acts else None
        outbound_ok = self._endpoint_is_grounded(first_act, start_city, target_city)
        if not outbound_ok:
            existing_type = first_act.get("type") if isinstance(first_act, dict) else None
            modes = self._intercity_mode_order(existing_type, outbound_pref)
            first_incity_idx = None
            for idx, activity in enumerate(first_day_acts):
                if idx == 0 and self._is_intercity_activity(activity):
                    continue
                if not self._is_intercity_activity(activity):
                    first_incity_idx = idx
                    break
            first_incity = first_day_acts[first_incity_idx] if first_incity_idx is not None else None
            first_incity_start = self._safe_time_minutes(first_incity.get("start_time")) if isinstance(first_incity, dict) else None
            first_incity_pos = self._activity_start_position(first_incity) if isinstance(first_incity, dict) else None

            chosen_row = None
            chosen_transports = []
            for mode in modes:
                for row in self._iter_intercity_rows(start_city, target_city, mode):
                    arr_min = self._safe_time_minutes(row.get("EndTime"))
                    if arr_min is None:
                        continue
                    if first_incity_start is not None and arr_min > first_incity_start:
                        continue
                    transports_to_first = []
                    if first_incity is not None:
                        transports_to_first, _ = self._safe_inbound_transport(
                            target_city,
                            str(row.get("To", "")),
                            first_incity_pos,
                            str(row.get("EndTime", "")),
                            first_incity_start,
                            people,
                        )
                        if transports_to_first is None:
                            continue
                    chosen_row = row
                    chosen_transports = transports_to_first
                    break
                if chosen_row is not None:
                    break

            if chosen_row is not None:
                new_first = self._make_intercity_activity(chosen_row, people, [])
                if first_day_acts and self._is_intercity_activity(first_day_acts[0]):
                    first_day_acts[0] = new_first
                else:
                    first_day_acts.insert(0, new_first)
                    if first_incity_idx is not None:
                        first_incity_idx += 1
                if first_incity_idx is not None and first_incity_idx < len(first_day_acts):
                    if not self._is_intercity_activity(first_day_acts[first_incity_idx]):
                        first_day_acts[first_incity_idx]["transports"] = chosen_transports
                changed = True

        # Return endpoint: last-day final activity.
        last_day = (trial.get("itinerary", []) or [{}])[-1] or {}
        last_day_acts = last_day.get("activities", []) or []
        last_act = last_day_acts[-1] if last_day_acts else None
        return_ok = self._endpoint_is_grounded(last_act, target_city, start_city)
        if not return_ok:
            existing_type = last_act.get("type") if isinstance(last_act, dict) else None
            modes = self._intercity_mode_order(existing_type, return_pref)

            if (
                self._repair_drop_trailing_stay_enabled()
                and len(itinerary) == 1
                and last_day_acts
                and isinstance(last_day_acts[-1], dict)
                and last_day_acts[-1].get("type") == "accommodation"
            ):
                # A single-day trip has no business ending in an overnight stay in the first
                # place, and its 24:00 end_time floors the return-departure search below to
                # "after midnight" -- no row can ever clear it. Drop it so last_incity_idx/
                # floor_time/floor_min/floor_pos below are recomputed from the real last
                # in-city activity, exactly as if it had never been there.
                last_day_acts.pop()

            last_incity_idx = None
            search_end = len(last_day_acts) - 1
            if search_end >= 0 and self._is_intercity_activity(last_day_acts[search_end]):
                search_end -= 1
            for idx in range(search_end, -1, -1):
                if not self._is_intercity_activity(last_day_acts[idx]):
                    last_incity_idx = idx
                    break

            floor_time = "00:00"
            floor_min = 0
            floor_pos = None
            if last_incity_idx is not None:
                anchor = last_day_acts[last_incity_idx]
                floor_time = str(anchor.get("end_time", "")) or floor_time
                floor_min = self._safe_time_minutes(floor_time)
                if floor_min is None:
                    floor_min = 0
                    floor_time = "00:00"
                floor_pos = self._activity_end_position(anchor)

            chosen_row = None
            chosen_transports = []
            for mode in modes:
                for row in self._iter_intercity_rows(target_city, start_city, mode):
                    dep_min = self._safe_time_minutes(row.get("BeginTime"))
                    if dep_min is None or dep_min < floor_min:
                        continue
                    transports_to_depart = []
                    if floor_pos:
                        transports_to_depart, arrival = self._safe_inbound_transport(
                            target_city,
                            floor_pos,
                            str(row.get("From", "")),
                            floor_time,
                            dep_min,
                            people,
                        )
                        if transports_to_depart is None or arrival is None:
                            continue
                    chosen_row = row
                    chosen_transports = transports_to_depart
                    break
                if chosen_row is not None:
                    break

            if chosen_row is not None:
                new_last = self._make_intercity_activity(chosen_row, people, chosen_transports)
                if last_day_acts and self._is_intercity_activity(last_day_acts[-1]):
                    last_day_acts[-1] = new_last
                else:
                    last_day_acts.append(new_last)
                changed = True

        if not changed:
            return
        try:
            if not self._repair_commit_allowed(plan, trial, query, check, was_accepted):
                return
            plan["itinerary"] = trial["itinerary"]
        except Exception:
            return

    def _pin_timed_windows(self, plan, query, constraints, check):
        """Retime a present-but-mistimed named-POI activity into its ``[earliest, end_before]``
        window. Purely additive and fully acceptance-gated: each shift is trialed on a deepcopy and
        kept only if the full checker still accepts and the preference key does not regress, so a
        shift that breaks ordering/transport/duration is silently reverted.

        This targets the roadmap-G8 failure family (familiar-100's dominant solver-only gap): the
        base build now *includes* the named POI (see ``_apply_search_constraints``' pool projection)
        but the greedy slotter schedules it by visit order, not by its clause window -- e.g. a
        required 07:50-08:40 hotel breakfast landing at 07:30-08:30. Local retiming is tried first
        (recomputing the activity's own inbound leg and the following activity's inbound leg); when
        that lacks slack because a fixed neighbour blocks it (e.g. a required evening visit built
        into the morning, with another activity already occupying the evening slot), ``_resequence_day``
        is tried next -- reordering the day's meal/attraction activities around their target windows,
        with intercity legs and the overnight accommodation stay left fixed."""
        windows = [
            w for w in (constraints.get("activity_time_windows", []) or [])
            if isinstance(w, dict) and w.get("location") and (w.get("earliest") or w.get("end_before"))
        ]
        if not windows:
            return
        city = query.get("target_city", "")
        people = int(query.get("people_number", 1) or 1)

        for w in windows:
            loc = str(w["location"])
            lo = time_to_minutes(str(w["earliest"])) if w.get("earliest") else None
            hi = time_to_minutes(str(w["end_before"])) if w.get("end_before") else None
            matches = self._find_activities_at(plan, loc)
            if not matches:
                continue  # absent -> needs insertion/reselection, out of this move's scope
            # The clause is satisfied by ANY matching activity in the window, so skip if one already
            # is, then try each candidate until one retiming commits (an arrival-day copy that can't
            # reach the window is skipped in favour of a stay-day copy that can).
            if any(self._activity_in_window(plan, d, a, lo, hi) for d, a in matches):
                continue
            pinned = False
            for day_idx, act_idx in matches:
                if self._try_pin_activity(plan, day_idx, act_idx, loc, lo, hi, city, people, check):
                    pinned = True
                    break
            if pinned:
                continue
            # Same-slot retime lacked slack (a fixed neighbour blocks it) -- try reordering the
            # whole day around its target windows instead (roadmap G8 day-resequencer follow-on).
            resequenced = False
            for day_idx, act_idx in matches:
                if self._resequence_day(plan, day_idx, query, constraints, check):
                    resequenced = True
                    break
            if resequenced or not self._cascade_timed_windows_enabled():
                continue
            # Cascading forward-shift fallback (opt-in; post-pin timed_visit residual). The day is
            # already in the right ORDER but a windowed activity still starts too early, and pushing
            # it into its window ripples a delay onto the following activities: _try_pin_activity
            # reverts that push ("no cascading reorder") and _resequence_day bails because the order
            # is unchanged. Re-lay the day's movable block in its *current* order with the windows
            # honored, so the clamp cascades the delay through the following legs. Deepcopy-trialed
            # and committed only on a still-accepting, non-regressing plan, same as the moves above.
            # _enforce_windows_in_order re-lays the whole day honoring every window, so one call per
            # day suffices even when several matched activities share a day -- dedup by day_idx to
            # avoid redundant deepcopy+relayout+check work.
            seen_days = set()
            for day_idx, _act_idx in matches:
                if day_idx in seen_days:
                    continue
                seen_days.add(day_idx)
                if self._enforce_windows_in_order(plan, day_idx, query, constraints, check):
                    break

    def _activity_in_window(self, plan, day_idx, act_idx, lo, hi):
        activity = plan["itinerary"][day_idx]["activities"][act_idx]
        try:
            cur_start = time_to_minutes(str(activity.get("start_time", "")))
            cur_end = time_to_minutes(str(activity.get("end_time", "")))
        except Exception:
            return False
        return (lo is None or cur_start >= lo) and (hi is None or cur_end <= hi)

    def _try_pin_activity(self, plan, day_idx, act_idx, loc, lo, hi, city, people, check):
        """Trial-retime one activity into ``[lo, hi]``; commit iff still accepted and not regressing.
        Returns True on commit."""
        activities = plan["itinerary"][day_idx].get("activities", []) or []
        activity = activities[act_idx]
        try:
            cur_start = time_to_minutes(str(activity.get("start_time", "")))
            cur_end = time_to_minutes(str(activity.get("end_time", "")))
        except Exception:
            return False
        win_lo = lo if lo is not None else cur_start
        win_hi = hi if hi is not None else cur_end
        if win_hi <= win_lo:
            return False
        desired_dwell = cur_end - cur_start
        if desired_dwell <= 0:
            desired_dwell = min(60, win_hi - win_lo)
        desired_dwell = min(desired_dwell, win_hi - win_lo)

        trial = deepcopy(plan)
        tacts = trial["itinerary"][day_idx]["activities"]
        tact = tacts[act_idx]
        # Recompute this activity's inbound leg first (skipped for a day's first activity, whose
        # inbound transports are empty -- e.g. a hotel breakfast). Pin the start to the later of the
        # window's earliest and the actual arrival, so a POI reachable only partway into the window
        # can still be pinned as long as it then fits before end_before.
        new_start = win_lo
        if act_idx > 0:
            prev = tacts[act_idx - 1]
            from_pos = self._activity_end_position(prev)
            depart = str(prev.get("end_time", "")) or minutes_to_time(win_lo)
            try:
                transports_in, arrival = self._get_transport(
                    self.env, city, from_pos, loc, depart, people)
            except Exception:
                return False
            if arrival is None:
                return False
            new_start = max(win_lo, time_to_minutes(arrival))
            tact["transports"] = transports_in
        dwell = min(desired_dwell, win_hi - new_start)
        if dwell <= 0:
            return False  # cannot fit even a minimal visit before end_before
        new_end = new_start + dwell
        tact["start_time"] = minutes_to_time(new_start)
        tact["end_time"] = minutes_to_time(new_end)
        # Recompute the following activity's inbound leg from the retimed POI; revert if it can no
        # longer be reached in time (no cascading reorder).
        if act_idx + 1 < len(tacts):
            nxt = tacts[act_idx + 1]
            if nxt.get("type") not in ("airplane", "train"):
                next_pos = self._activity_start_position(nxt)
                try:
                    transports_out, next_arrival = self._get_transport(
                        self.env, city, loc, next_pos, minutes_to_time(new_end), people)
                except Exception:
                    return False
                if next_arrival is None:
                    return False
                next_start = str(nxt.get("start_time", ""))
                if next_start and time_to_minutes(next_arrival) > time_to_minutes(next_start):
                    return False
                nxt["transports"] = transports_out

        before_key = self._accepted_eval_key(plan)
        try:
            if self._accepted(*check(trial)) and self._accepted_eval_key(trial) >= before_key:
                plan["itinerary"][day_idx]["activities"] = tacts
                return True
        except Exception:
            return False
        return False

    _WINDOW_ACTIVITY_TYPES = ("breakfast", "lunch", "dinner", "attraction")

    def _find_activities_at(self, plan, location):
        """Return ``[(day_idx, act_idx), ...]`` for every meal/attraction activity whose position
        matches ``location`` (bidirectional constraint-text match). The overnight ``accommodation``
        stay shares an inn's name but is never a timed-visit target, so it is excluded."""
        out = []
        for day_idx, day in enumerate(plan.get("itinerary", []) or []):
            for act_idx, activity in enumerate(day.get("activities", []) or []):
                if activity.get("type") not in self._WINDOW_ACTIVITY_TYPES:
                    continue
                pos = str(activity.get("position", ""))
                if not pos:
                    continue
                if self._match_constraint_text(pos, location) or self._match_constraint_text(location, pos):
                    out.append((day_idx, act_idx))
        return out

    def _window_for_position(self, windows, position):
        pos = str(position or "")
        for w in windows:
            loc = str(w.get("location", ""))
            if loc and (self._match_constraint_text(pos, loc) or self._match_constraint_text(loc, pos)):
                return w
        return None

    def _resequence_day(self, plan, day_idx, query, constraints, check):
        """Within-day resequencing move (roadmap G8 follow-on): order a day's meal/attraction
        activities by their target window (windowed POIs at ``[earliest, end_before]``, others by
        current ``start_time``), recompute each activity's inbound leg sequentially from the new
        predecessor, and commit on a deepcopy only if the full checker still accepts and the
        preference key does not regress.

        This is the fallback for when ``_try_pin_activity``'s local, same-slot retime lacks slack
        (the target's own dwell can move but its neighbours cannot) -- e.g. a required evening
        visit that the greedy slotter built into the morning. Intercity legs and the overnight
        accommodation activity are never moved: only the meal/attraction slots between them are
        reordered, so the floor stays byte-identical when the flag is off."""
        activities = plan["itinerary"][day_idx].get("activities", []) or []
        # A missing/empty position is treated as a foreign, non-reorderable anchor -- same
        # convention as ``_find_activities_at`` -- rather than a movable slot: otherwise its
        # position would poison the running ``prev_pos`` and silently skip the *next* activity's
        # inbound-leg recompute (an empty string is falsy, so ``if prev_pos:`` reads it as "no
        # predecessor" instead of "predecessor with an unknown position").
        movable_slots = [
            i for i, a in enumerate(activities)
            if a.get("type") in self._WINDOW_ACTIVITY_TYPES and str(a.get("position", ""))
        ]
        if len(movable_slots) < 2:
            return False
        if movable_slots[-1] - movable_slots[0] + 1 != len(movable_slots):
            # The head/tail recompute below assumes one contiguous movable block bounded by at most
            # one fixed predecessor and one fixed successor. A fixed activity (e.g. an intercity leg)
            # sitting between two movable ones would violate that and isn't safe to reorder across.
            return False

        windows = [
            w for w in (constraints.get("activity_time_windows", []) or [])
            if isinstance(w, dict) and w.get("location") and (w.get("earliest") or w.get("end_before"))
        ]

        def sort_key(act):
            w = self._window_for_position(windows, act.get("position"))
            if w is not None:
                if w.get("earliest"):
                    return time_to_minutes(str(w["earliest"]))
                if w.get("end_before"):
                    return time_to_minutes(str(w["end_before"]))
            try:
                return time_to_minutes(str(act.get("start_time", "")))
            except Exception:
                return 0

        order = sorted(range(len(movable_slots)), key=lambda k: (sort_key(activities[movable_slots[k]]), k))
        if order == list(range(len(movable_slots))):
            return False  # already in target order -- nothing to trial

        city = query.get("target_city", "")
        people = int(query.get("people_number", 1) or 1)

        trial = deepcopy(plan)
        if not self._relayout_movable_block(trial, day_idx, movable_slots, order, city, people,
                                             windows=windows):
            return False

        before_key = self._accepted_eval_key(plan)
        try:
            if self._accepted(*check(trial)) and self._accepted_eval_key(trial) >= before_key:
                plan["itinerary"][day_idx]["activities"] = trial["itinerary"][day_idx]["activities"]
                return True
        except Exception:
            return False
        return False

    def _enforce_windows_in_order(self, plan, day_idx, query, constraints, check):
        """Cascading forward-shift move (opt-in; post-pin ``timed_visit_named_poi`` residual).

        For the case neither ``_try_pin_activity`` nor ``_resequence_day`` handles: the day is
        already in the correct order, but a windowed activity still starts before its
        ``[earliest, end_before]`` clause window, and clamping it into that window would push the
        following activities later. ``_try_pin_activity`` reverts such a push ("no cascading
        reorder") and ``_resequence_day`` returns early because the target order equals the current
        order -- so the window stays unsatisfied. This re-lays the day's contiguous movable
        (meal/attraction) block in its *current* order with the windows honored, reusing
        ``_relayout_movable_block``: each windowed slot is clamped to ``max(arrival, earliest)`` and
        the resulting delay ripples through every following inbound leg. Intercity legs and the
        day's fixed head/tail are never moved, and if the ripple makes a downstream fixed activity
        (e.g. an evening train) unreachable, the relayout fails and nothing is committed.

        Deepcopy-trialed and committed only if the full checker still accepts and the preference key
        does not regress -- the same commit rule as ``_try_pin_activity`` / ``_resequence_day``."""
        activities = plan["itinerary"][day_idx].get("activities", []) or []
        movable_slots = [
            i for i, a in enumerate(activities)
            if a.get("type") in self._WINDOW_ACTIVITY_TYPES and str(a.get("position", ""))
        ]
        if not movable_slots:
            return False
        if movable_slots[-1] - movable_slots[0] + 1 != len(movable_slots):
            # Same contiguity requirement as _resequence_day: a fixed activity between two movable
            # ones is not safe to re-leg across.
            return False
        windows = [
            w for w in (constraints.get("activity_time_windows", []) or [])
            if isinstance(w, dict) and w.get("location") and (w.get("earliest") or w.get("end_before"))
        ]
        if not windows:
            return False

        city = query.get("target_city", "")
        people = int(query.get("people_number", 1) or 1)
        identity_order = list(range(len(movable_slots)))

        trial = deepcopy(plan)
        if not self._relayout_movable_block(trial, day_idx, movable_slots, identity_order, city,
                                            people, windows=windows):
            return False

        before_key = self._accepted_eval_key(plan)
        try:
            if self._accepted(*check(trial)) and self._accepted_eval_key(trial) >= before_key:
                plan["itinerary"][day_idx]["activities"] = trial["itinerary"][day_idx]["activities"]
                return True
        except Exception:
            return False
        return False

    def _relayout_movable_block(self, trial, day_idx, movable_slots, order, city, people, windows=None,
                                slot_windows=None, retime_stay_tail=False):
        """Reorder and re-leg one day's contiguous movable (meal/attraction) block in place on
        ``trial``, shared by ``_resequence_day`` (window-driven order) and the Stage 3 LLM refine's
        ``reorder_day``/``swap_activity`` edits (LLM-proposed order, no windows).

        ``movable_slots`` are the day's original movable activity indices (already validated
        contiguous by the caller); ``order`` is a permutation of ``range(len(movable_slots))``
        giving the new slot order. Every inbound leg from the block's fixed predecessor (if any)
        through its fixed successor (if any) is recomputed via ``_get_transport``; a leg that
        cannot be grounded fails the whole relayout. Intercity legs and the day's fixed head/tail
        are never touched. ``windows`` (``activity_time_windows``-shaped dicts), when given, clamps
        a retimed slot into its clause window exactly like ``_resequence_day`` always did; omitted
        for a plain LLM-proposed reorder/swap, which has no window to honor. Returns True on a
        structurally valid relayout -- callers still apply their own acceptance gate.

        ``slot_windows`` (opt-in, ``TPC_WINDOW_ANCHOR``) supersedes ``windows`` with an explicit
        ``{original slot index: (lo_minutes, hi_minutes)}`` map, letting the caller resolve a window
        *per activity* -- by activity type, and by intersecting every window naming that position --
        instead of taking the first window whose location matches. ``retime_stay_tail`` lets a
        ripple that pushes the day later also push the overnight ``accommodation`` tail's
        ``start_time`` later, which is legitimate (the stay starts when you arrive) whereas moving an
        intercity departure is not. Both default to the previous behaviour."""
        tacts = trial["itinerary"][day_idx]["activities"]
        reordered = [deepcopy(tacts[movable_slots[k]]) for k in order]
        # An activity's window belongs to the activity, not to the position it lands in, so key the
        # per-activity map by the slot it came *from* under ``order``.
        slot_window_by_new_slot = None
        if slot_windows is not None:
            slot_window_by_new_slot = {
                movable_slots[j]: slot_windows.get(movable_slots[k])
                for j, k in enumerate(order)
            }

        # No fixed head (movable_slots[0] == 0) leaves prev_pos/prev_end at None: the activity
        # landing in slot 0 keeps its own original start/end time and empty transports, exactly
        # like _try_pin_activity's act_idx == 0 case -- a guessed hotel-departure time here would
        # misinterpret that activity's own original start_time as a real departure clock.
        prev_pos, prev_end = None, None
        if movable_slots[0] > 0:
            head = tacts[movable_slots[0] - 1]
            prev_pos = self._activity_end_position(head)
            if not prev_pos:
                # A fixed predecessor exists but its position can't be resolved -- bail rather
                # than silently drop the inbound leg and produce a discontinuous day.
                return False
            prev_end = str(head.get("end_time", ""))

        for slot_i, act in zip(movable_slots, reordered):
            try:
                cur_start = time_to_minutes(str(act.get("start_time", "")))
                cur_end = time_to_minutes(str(act.get("end_time", "")))
            except Exception:
                return False
            dwell = max(1, cur_end - cur_start)
            if prev_pos:
                try:
                    transports_in, arrival = self._get_transport(
                        self.env, city, prev_pos, str(act.get("position", "")), prev_end or "00:00", people)
                except Exception:
                    return False
                if arrival is None:
                    return False
                new_start = time_to_minutes(arrival)
                act["transports"] = transports_in
            else:
                new_start = cur_start
                act["transports"] = []
            if slot_window_by_new_slot is not None:
                bounds = slot_window_by_new_slot.get(slot_i)
                if bounds is not None:
                    lo, hi = bounds
                    new_start = max(new_start, lo)
                    dwell = min(dwell, hi - new_start)
                    if dwell <= 0:
                        return False
            elif windows is not None:
                w = self._window_for_position(windows, act.get("position"))
                if w is not None:
                    lo = time_to_minutes(str(w["earliest"])) if w.get("earliest") else new_start
                    hi = time_to_minutes(str(w["end_before"])) if w.get("end_before") else new_start + dwell
                    new_start = max(new_start, lo)
                    dwell = min(dwell, hi - new_start)
                    if dwell <= 0:
                        return False
            new_end = new_start + dwell
            if slot_window_by_new_slot is not None and new_end > 23 * 60 + 59:
                # ``minutes_to_time`` clamps at 23:59, so a ripple that overflows the day would
                # silently truncate this activity's dwell and hand a bogus 23:59 departure to the
                # next leg. Existing callers keep the old (clamping) behaviour; the anchored path
                # rejects the layout instead. A day cannot legitimately end after 24:00.
                return False
            act["start_time"] = minutes_to_time(new_start)
            act["end_time"] = minutes_to_time(new_end)
            tacts[slot_i] = act
            prev_pos = str(act.get("position", ""))
            prev_end = minutes_to_time(new_end)

        tail_idx = movable_slots[-1] + 1
        if tail_idx < len(tacts):
            # Recompute the inbound leg regardless of the tail's type: an intercity activity's own
            # `transports` field represents the leg from the previous activity to the station/
            # airport, and reordering changes what that previous activity is. Its scheduled
            # start/end time stays fixed (this only rejects if the new arrival can't make it).
            tail = tacts[tail_idx]
            tail_pos = self._activity_start_position(tail)
            if not tail_pos:
                # Symmetric with the head-side guard above: don't call _get_transport with an
                # unresolvable destination and risk silently accepting a bogus leg.
                return False
            try:
                transports_out, tail_arrival = self._get_transport(
                    self.env, city, prev_pos, tail_pos, prev_end, people)
            except Exception:
                return False
            if tail_arrival is None:
                return False
            tail_start = str(tail.get("start_time", ""))
            if tail_start and time_to_minutes(tail_arrival) > time_to_minutes(tail_start):
                # The overnight stay's start_time records when the traveller got back to the hotel,
                # not a departure that can be missed, so a later arrival may simply move it -- but
                # only within the same calendar day, since a plan's day boundary is 24:00 and the
                # stay must still end there. An intercity departure is never moved.
                arrival_min = time_to_minutes(tail_arrival)
                if not (retime_stay_tail and tail.get("type") == "accommodation"
                        and arrival_min < 24 * 60):
                    return False
                tail["start_time"] = minutes_to_time(arrival_min)
            tail["transports"] = transports_out
        return True

    def _window_activity_types(self, window):
        """Normalized activity types a window applies to, or ``None`` for "any position match".

        Both constraint sources now record this (``parse_constraints._window_activity_types`` from
        the sentence's verb, ``solver_constraints._window_activity_types`` from the oracle clause's
        ``activity_type`` test); a window without the key keeps the previous type-agnostic reading.
        """
        raw = window.get("activity_types") if isinstance(window, dict) else None
        if not raw:
            return None
        if isinstance(raw, str):
            raw = [raw]
        types = tuple(str(t).strip().lower() for t in raw if str(t).strip())
        return types or None

    def _resolve_slot_windows(self, activities, windows):
        """``{slot index: (lo_minutes, hi_minutes)}`` for a day's movable activities (roadmap P1).

        Two things this does that ``_window_for_position`` cannot:

        * **Type matching.** A window that names its activity types only applies to an activity of
          one of them, so a hotel's ``Stay at ... between 20:10 and 24:00`` window never lands on
          that hotel's breakfast.
        * **Intersection.** Several windows may legitimately constrain the same activity (a POI
          named by two clauses, e.g. ``07:45-08:40`` and ``07:50-08:35``). All of them must hold, so
          the effective bound is ``max(earliest)``/``min(end_before)``; resolving to just the first
          match satisfies one clause and breaks the other.

        A slot whose intersected window is empty (``hi <= lo``) is dropped rather than reported as
        an impossible bound: the clause set is unsatisfiable *for that activity*, and the caller's
        job is to lay the rest of the day out, not to fabricate a zero-length visit.
        """
        resolved = {}
        for idx, activity in enumerate(activities or []):
            if activity.get("type") not in self._WINDOW_ACTIVITY_TYPES:
                continue
            position = str(activity.get("position", ""))
            if not position:
                continue
            lo = hi = None
            for window in windows or []:
                if not isinstance(window, dict) or not window.get("location"):
                    continue
                types = self._window_activity_types(window)
                if types is not None and str(activity.get("type", "")).lower() not in types:
                    continue
                location = str(window["location"])
                if not (self._match_constraint_text(position, location)
                        or self._match_constraint_text(location, position)):
                    continue
                try:
                    w_lo = time_to_minutes(str(window["earliest"])) if window.get("earliest") else None
                    w_hi = time_to_minutes(str(window["end_before"])) if window.get("end_before") else None
                except Exception:
                    continue
                if w_lo is not None:
                    lo = w_lo if lo is None else max(lo, w_lo)
                if w_hi is not None:
                    hi = w_hi if hi is None else min(hi, w_hi)
            if lo is not None and hi is not None and hi > lo:
                resolved[idx] = (lo, hi)
        return resolved

    def _anchor_timed_windows(self, plan, query, constraints, check):
        """Window-anchored day relayout for the post-pin ``timed_visit_named_poi`` residual
        (roadmap P1; opt-in via ``TPC_WINDOW_ANCHOR``).

        Runs after ``_pin_timed_windows`` on every day that has at least one resolvable window, and
        re-lays that day's contiguous movable block at the earliest feasible time, clamped into each
        activity's *own* intersected, type-matched window. Two mechanisms distinguish it from
        ``_enforce_windows_in_order``, and both were chosen from a measured classification of the
        residual rather than guessed -- see ``_window_anchor_enabled``.

        Commit rule, matching ``_repair_commit_allowed``'s two regimes: the trial must be fully
        accepted by the checker either way, and additionally must not lower the preference key when
        the *input* plan was already accepted. Requiring a non-regressing key against an
        **unaccepted** input is pure friction -- it can reject a layout that flips the plan to
        accepted because a rerouted leg cost a fraction of an ATT point.
        """
        windows = [
            w for w in (constraints.get("activity_time_windows", []) or [])
            if isinstance(w, dict) and w.get("location") and (w.get("earliest") or w.get("end_before"))
        ]
        if not windows:
            return False
        city = query.get("target_city", "")
        people = int(query.get("people_number", 1) or 1)
        committed = False

        for day_idx, day in enumerate(plan.get("itinerary", []) or []):
            activities = day.get("activities", []) or []
            slot_windows = self._resolve_slot_windows(activities, windows)
            if not slot_windows:
                continue
            movable_slots = [
                i for i, a in enumerate(activities)
                if a.get("type") in self._WINDOW_ACTIVITY_TYPES and str(a.get("position", ""))
            ]
            if not movable_slots:
                continue
            if movable_slots[-1] - movable_slots[0] + 1 != len(movable_slots):
                # Same contiguity requirement as _resequence_day / _enforce_windows_in_order: a
                # fixed activity between two movable ones is not safe to re-leg across.
                continue
            if all(self._activity_in_window(plan, day_idx, slot, *slot_windows[slot])
                   for slot in slot_windows):
                continue  # every windowed activity on this day already sits inside its window

            was_accepted = False
            before_key = self._accepted_eval_key(plan)
            try:
                was_accepted = self._accepted(*check(plan))
            except Exception:
                was_accepted = False

            trial = deepcopy(plan)
            if not self._relayout_movable_block(
                    trial, day_idx, movable_slots, list(range(len(movable_slots))), city, people,
                    slot_windows=slot_windows, retime_stay_tail=True):
                continue
            try:
                if not self._accepted(*check(trial)):
                    continue
                if was_accepted and self._accepted_eval_key(trial) < before_key:
                    continue
            except Exception:
                continue
            plan["itinerary"][day_idx]["activities"] = trial["itinerary"][day_idx]["activities"]
            committed = True
        return committed

    def _translate_transport_segments(self, transports, minutes):
        """Translate a grounded inner-city leg without changing its mode, duration, or cost."""
        for segment in transports or []:
            try:
                start = time_to_minutes(str(segment.get("start_time", ""))) + minutes
                end = time_to_minutes(str(segment.get("end_time", ""))) + minutes
            except Exception:
                return False
            if start < 0 or end <= start or end >= 24 * 60:
                return False
            segment["start_time"] = minutes_to_time(start)
            segment["end_time"] = minutes_to_time(end)
        return True

    def _transport_duration_minutes(self, transports):
        if not transports:
            return 0
        try:
            return time_to_minutes(str(transports[-1]["end_time"])) - time_to_minutes(
                str(transports[0]["start_time"]))
        except Exception:
            return None

    def _push_activity_open(self, city, activity, start_min, end_min):
        bounds = self._lookup_poi_open_bounds(
            city, str(activity.get("position", "")), activity.get("type"), activity.get("tickets"))
        if bounds is None:
            return True
        open_min, close_min = bounds
        return open_min <= start_min and end_min <= close_min

    def _push_timed_windows(self, plan, query, constraints, check):
        """Bounded local forward push for present timed POIs (roadmap P8).

        The anchor relayout is intentionally broad: it recomputes an entire movable day. This pass
        instead clamps one forward/shorten target, preserves every successor dwell and route, and
        propagates only the resulting delay. Existing slack is consumed before a successor's clock
        moves. The full checker remains the authority for every deepcopy trial.
        """
        windows = [
            window for window in (constraints.get("activity_time_windows", []) or [])
            if isinstance(window, dict) and window.get("location")
            and (window.get("earliest") or window.get("end_before"))
        ]
        if not windows:
            return False
        try:
            max_push = max(0, int(os.environ.get("TPC_WINDOW_PUSH_MAX_MIN", "30")))
        except ValueError:
            max_push = 30
        city = str(query.get("target_city", ""))
        committed = False

        for day_idx, day in enumerate(plan.get("itinerary", []) or []):
            activities = day.get("activities", []) or []
            slot_windows = self._resolve_slot_windows(activities, windows)
            movable_slots = [
                idx for idx, activity in enumerate(activities)
                if activity.get("type") in self._WINDOW_ACTIVITY_TYPES and str(activity.get("position", ""))
            ]
            if not slot_windows or not movable_slots:
                continue
            if movable_slots[-1] - movable_slots[0] + 1 != len(movable_slots):
                continue

            for target_idx in movable_slots:
                if target_idx not in slot_windows:
                    continue
                try:
                    old_start = time_to_minutes(str(activities[target_idx]["start_time"]))
                    old_end = time_to_minutes(str(activities[target_idx]["end_time"]))
                except Exception:
                    continue
                lo, hi = slot_windows[target_idx]
                # P8 deliberately excludes backward relocation: only a forward clamp or a dwell
                # shortening that fits on this day belongs to this local move.
                if old_start >= lo and old_end <= hi:
                    continue

                was_accepted = False
                try:
                    was_accepted = self._accepted(*check(plan))
                except Exception:
                    pass
                trial = deepcopy(plan)
                tacts = trial["itinerary"][day_idx]["activities"]
                tact = tacts[target_idx]
                new_start = max(old_start, lo)
                start_shift = new_start - old_start
                if start_shift > max_push:
                    continue
                if start_shift and not self._translate_transport_segments(
                        tact.get("transports", []), start_shift):
                    continue
                dwell = min(max(1, old_end - old_start), hi - new_start)
                new_end = new_start + dwell
                if dwell <= 0 or new_end >= 24 * 60 or not self._push_activity_open(
                        city, tact, new_start, new_end):
                    continue
                delay = new_end - old_end
                if delay > max_push:
                    continue
                tact["start_time"] = minutes_to_time(new_start)
                tact["end_time"] = minutes_to_time(new_end)

                original_times = {}
                valid = True
                for slot in movable_slots:
                    try:
                        original_times[slot] = (
                            time_to_minutes(str(activities[slot]["start_time"])),
                            time_to_minutes(str(activities[slot]["end_time"])),
                        )
                    except Exception:
                        valid = False
                        break
                if not valid:
                    continue

                target_pos = movable_slots.index(target_idx)
                carry = max(0, delay)
                for successor_idx in movable_slots[target_pos + 1:]:
                    successor = tacts[successor_idx]
                    predecessor_idx = movable_slots[movable_slots.index(successor_idx) - 1]
                    duration = self._transport_duration_minutes(successor.get("transports", []))
                    if duration is None:
                        valid = False
                        break
                    old_successor_start, old_successor_end = original_times[successor_idx]
                    _old_predecessor_start, old_predecessor_end = original_times[predecessor_idx]
                    gap = max(0, old_successor_start - (old_predecessor_end + duration))
                    # The leg must leave with its predecessor's delayed end; its activity clock
                    # moves only after consuming the idle gap following that leg.
                    if carry and not self._translate_transport_segments(
                            successor.get("transports", []), carry):
                        valid = False
                        break
                    activity_shift = max(0, carry - gap)
                    new_successor_start = old_successor_start + activity_shift
                    new_successor_end = old_successor_end + activity_shift
                    if new_successor_end >= 24 * 60 or not self._push_activity_open(
                            city, successor, new_successor_start, new_successor_end):
                        valid = False
                        break
                    successor["start_time"] = minutes_to_time(new_successor_start)
                    successor["end_time"] = minutes_to_time(new_successor_end)
                    carry = activity_shift
                if not valid:
                    continue

                tail_idx = movable_slots[-1] + 1
                if carry and tail_idx < len(tacts):
                    tail = tacts[tail_idx]
                    if tail.get("type") != "accommodation":
                        continue
                    if not self._translate_transport_segments(tail.get("transports", []), carry):
                        continue
                    try:
                        arrival = (time_to_minutes(str(tail["transports"][-1]["end_time"]))
                                   if tail.get("transports")
                                   else time_to_minutes(str(tacts[movable_slots[-1]]["end_time"])))
                        tail_start = max(time_to_minutes(str(tail.get("start_time", ""))), arrival)
                    except Exception:
                        continue
                    if tail_start >= 24 * 60:
                        continue
                    tail["start_time"] = minutes_to_time(tail_start)

                try:
                    if not self._accepted(*check(trial)):
                        continue
                except Exception:
                    continue
                if not self._repair_commit_allowed(plan, trial, query, check, was_accepted):
                    continue
                plan["itinerary"][day_idx]["activities"] = tacts
                committed = True
                break
        return committed

    def _resolve_timed_window_poi(self, city, location, activity_type):
        """Resolve a named timed-visit POI from WorldEnv into an insert-helper row dict."""
        if self.env is None:
            return None
        if activity_type == "attraction":
            pool = getattr(self.env, "attractions", None)
        elif activity_type in ("breakfast", "lunch", "dinner"):
            pool = getattr(self.env, "restaurants", None)
        else:
            return None
        if pool is None:
            return None
        try:
            data = getattr(pool, "data", {})
            rows = data.get(city) if isinstance(data, dict) else None
            if rows is None:
                rows = pool.select(city, "name", lambda value: True)
            if hasattr(rows, "iterrows"):
                rows = (dict(row) for _idx, row in rows.iterrows())
            for row in rows or []:
                candidate = dict(row)
                name = str(candidate.get("name", ""))
                if name and self._match_window_location(name, location):
                    return candidate
        except Exception:
            return None
        return None

    def _match_window_location(self, candidate, location):
        """Match normalized POI aliases without accepting an arbitrary leading qualifier."""
        candidate_norm = self._norm_text(candidate)
        location_norm = self._norm_text(location)
        return bool(
            candidate_norm and location_norm
            and (candidate_norm == location_norm
                 or candidate_norm.startswith(location_norm)
                 or location_norm.startswith(candidate_norm))
        )

    def _window_has_planned_position(self, plan, location, activity_type):
        matching_types = ({"breakfast", "lunch", "dinner"}
                          if activity_type in ("breakfast", "lunch", "dinner")
                          else {activity_type})
        for day in plan.get("itinerary", []) or []:
            for activity in day.get("activities", []) or []:
                if activity.get("type") not in matching_types:
                    continue
                position = str(activity.get("position", ""))
                if position and self._match_window_location(position, location):
                    return True
        return False

    def _insert_absent_timed_window_pois(self, plan, query, constraints, check):
        """Try grounded insertion slots for the P9 absent-POI timed-window residual."""
        city = str(query.get("target_city", ""))
        bounds_by_target = {}
        for window in (constraints.get("activity_time_windows", []) or []):
            if not isinstance(window, dict) or not window.get("location"):
                continue
            try:
                lo = time_to_minutes(str(window["earliest"])) if window.get("earliest") else None
                hi = time_to_minutes(str(window["end_before"])) if window.get("end_before") else None
            except Exception:
                continue
            for activity_type in self._window_activity_types(window) or ():
                if activity_type not in self._WINDOW_ACTIVITY_TYPES:
                    continue
                location = str(window["location"])
                poi = self._resolve_timed_window_poi(city, location, activity_type)
                canonical_location = str(poi.get("name", location)) if poi else location
                key = (canonical_location, activity_type)
                old_lo, old_hi = bounds_by_target.get(key, (None, None))
                bounds_by_target[key] = (
                    lo if old_lo is None else (max(old_lo, lo) if lo is not None else old_lo),
                    hi if old_hi is None else (min(old_hi, hi) if hi is not None else old_hi),
                )
        if not bounds_by_target:
            return False

        people = int(query.get("people_number", 1) or 1)
        inserted = False
        for (location, activity_type), (lo, hi) in bounds_by_target.items():
            if self._window_has_planned_position(plan, location, activity_type):
                continue
            poi = self._resolve_timed_window_poi(city, location, activity_type)
            if poi is None:
                continue
            poi_open, poi_close = self._poi_open_bounds(poi)
            lo = poi_open if lo is None else max(lo, poi_open)
            hi = poi_close if hi is None else min(hi, poi_close)
            if hi <= lo:
                continue
            try:
                was_accepted = self._accepted(*check(plan))
            except Exception:
                was_accepted = False
            repair_context = (deepcopy(plan), query, was_accepted)
            for day_idx, day in enumerate(plan.get("itinerary", []) or []):
                activities = day.get("activities", []) or []
                if not activities:
                    continue
                if self._insert_activity_before_first(
                        plan, day_idx, poi, activity_type, (lo, hi), city, people, check, repair_context):
                    inserted = True
                    break
                if any(self._insert_activity(
                        plan, day_idx, prev_idx, poi, activity_type, (lo, hi), city, people, check,
                        repair_context) for prev_idx in range(len(activities) - 1)):
                    inserted = True
                    break
                if self._insert_activity_after_last(
                        plan, day_idx, poi, activity_type, (lo, hi), city, people, check, repair_context):
                    inserted = True
                    break
        return inserted

    def _remove_movable_activity(self, trial, day_idx, act_idx, city, people):
        """Delete one movable (meal/attraction) activity from a day and re-leg its neighbours so
        the day stays a schema-valid, continuous itinerary (roadmap P25's move-then-delete half).

        Mutates ``trial`` in place. Refuses (leaving ``trial`` unchanged) rather than producing a
        day whose legs cannot be grounded: an unreachable direct predecessor->successor route, or
        a fixed tail (an intercity leg) that can no longer be met on time. An overnight
        accommodation tail may still have its ``start_time`` pulled later, mirroring
        ``_relayout_movable_block``'s own ``retime_stay_tail`` convention -- that time records
        when the traveller got back to the hotel, not a departure that can be missed."""
        activities = trial["itinerary"][day_idx].get("activities", []) or []
        if not (0 <= act_idx < len(activities)):
            return False
        if activities[act_idx].get("type") not in self._WINDOW_ACTIVITY_TYPES:
            return False

        prev_pos, prev_end = None, None
        if act_idx > 0:
            prev_act = activities[act_idx - 1]
            prev_pos = self._activity_end_position(prev_act)
            if not prev_pos:
                return False
            prev_end = str(prev_act.get("end_time", ""))
        elif day_idx > 0:
            hotel_name = self._find_hotel_for_day(trial, day_idx)
            if hotel_name:
                prev_pos = hotel_name
                prev_end = "08:30"

        next_idx = act_idx + 1
        if next_idx < len(activities):
            nxt = activities[next_idx]
            next_pos = self._activity_start_position(nxt)
            if not next_pos:
                return False
            try:
                next_start_min = time_to_minutes(str(nxt.get("start_time", "")))
            except Exception:
                return False
            if prev_pos:
                try:
                    transports, arrival = self._best_transport_via_get_transport(
                        city, prev_pos, next_pos, prev_end or "00:00", people)
                except Exception:
                    return False
                if transports is None or arrival is None:
                    return False
                try:
                    arrival_min = time_to_minutes(str(arrival))
                except Exception:
                    return False
                if arrival_min > next_start_min:
                    if nxt.get("type") == "accommodation" and arrival_min < 24 * 60:
                        nxt["start_time"] = minutes_to_time(arrival_min)
                    else:
                        return False
                nxt["transports"] = transports
            else:
                # No predecessor remains (day-start removal with no known hotel anchor): the
                # successor becomes the day's new first activity, matching
                # ``_relayout_movable_block``'s own no-fixed-head convention (keeps its own
                # start/end time, empty transports).
                nxt["transports"] = []
        del activities[act_idx]
        return True

    def _relocate_timed_windows_across_days(self, plan, query, constraints, check):
        """Move a present-but-window-missing timed visit to a different day (roadmap P25).

        Scope, deliberately narrow. This only handles a POI ``_window_has_planned_position``
        already finds *somewhere* in the plan for its required activity type -- a genuinely absent
        POI is ``_insert_absent_timed_window_pois``'s job (P9), not this one's. Among present
        occurrences, only a target whose window no existing copy satisfies is a candidate (an
        already-satisfied window has nothing left to fix). The relocated copy always lands on a
        *different* day: same-day reshuffling already belongs to ``_anchor_timed_windows``/
        ``_push_timed_windows``, which run before this pass, so a same-day fix would already have
        committed by the time this runs.

        Move-then-delete, not copy: a duplicate visit trips the repeated-attraction commonsense
        rule, so the source occurrence is always removed from its old day in the same trial that
        adds the new one, and the combined trial is re-checked as one atomic unit before it may
        replace either day in ``plan``.

        Bounded to one relocation per call, in a fixed ascending-day-index target order, matching
        the roadmap's "one relocation per attempt" bar -- this pass runs again on the next
        ``_pack_plan`` invocation (a later restart/repair pass), so a second residual gets its own
        call rather than this one cascading unboundedly through a single plan.
        """
        city = str(query.get("target_city", ""))
        itinerary = plan.get("itinerary", []) or []
        if len(itinerary) < 2:
            return False  # nothing to relocate *to*
        people = int(query.get("people_number", 1) or 1)

        bounds_by_target = {}
        for window in (constraints.get("activity_time_windows", []) or []):
            if not isinstance(window, dict) or not window.get("location"):
                continue
            try:
                lo = time_to_minutes(str(window["earliest"])) if window.get("earliest") else None
                hi = time_to_minutes(str(window["end_before"])) if window.get("end_before") else None
            except Exception:
                continue
            for activity_type in self._window_activity_types(window) or ():
                if activity_type not in self._WINDOW_ACTIVITY_TYPES:
                    continue
                location = str(window["location"])
                poi = self._resolve_timed_window_poi(city, location, activity_type)
                canonical_location = str(poi.get("name", location)) if poi else location
                # Keyed exactly like _insert_absent_timed_window_pois's bounds_by_target: two
                # window clauses that are aliases of the same catalog POI (e.g. "Museum Garden"
                # and "Museum Scenic Area") must intersect into one target, not two, or a POI with
                # sibling-alias windows can never be fully satisfied by either alone.
                key = (canonical_location, activity_type)
                old_lo, old_hi = bounds_by_target.get(key, (None, None))
                bounds_by_target[key] = (
                    lo if old_lo is None else (max(old_lo, lo) if lo is not None else old_lo),
                    hi if old_hi is None else (min(old_hi, hi) if hi is not None else old_hi),
                )
        if not bounds_by_target:
            return False

        try:
            was_accepted = self._accepted(*check(plan))
        except Exception:
            was_accepted = False
        before_key = self._accepted_eval_key(plan)

        # ``location`` here is each key's *canonical* catalog name (matching
        # _insert_absent_timed_window_pois's own re-binding) -- re-resolving and re-matching
        # against it works because a plan's own activities are positioned with catalog names too,
        # and _match_window_location/_resolve_timed_window_poi both accept an already-canonical
        # name as trivially matching itself.
        for (location, activity_type), (lo, hi) in bounds_by_target.items():
            poi = self._resolve_timed_window_poi(city, location, activity_type)
            if poi is None:
                continue
            poi_open, poi_close = self._poi_open_bounds(poi)
            lo2 = poi_open if lo is None else max(lo, poi_open)
            hi2 = poi_close if hi is None else min(hi, poi_close)
            if hi2 <= lo2:
                continue

            matching_types = ({"breakfast", "lunch", "dinner"}
                              if activity_type in ("breakfast", "lunch", "dinner")
                              else {activity_type})
            occurrences = [
                (d, a) for d, day in enumerate(itinerary)
                for a, act in enumerate(day.get("activities", []) or [])
                if act.get("type") in matching_types
                and self._match_window_location(str(act.get("position", "")), location)
            ]
            if not occurrences:
                continue  # absent -- P9's (_insert_absent_timed_window_pois) job, not this one's
            if any(self._activity_in_window(plan, d, a, lo2, hi2) for d, a in occurrences):
                continue  # some existing copy already satisfies the window

            source_day, source_idx = occurrences[0]
            occurrence_days = {d for d, _ in occurrences}
            source_activities = itinerary[source_day].get("activities", []) or []
            movable_slots = [
                i for i, act in enumerate(source_activities)
                if act.get("type") in self._WINDOW_ACTIVITY_TYPES and str(act.get("position", ""))
            ]
            if source_idx not in movable_slots:
                continue
            if movable_slots[-1] - movable_slots[0] + 1 != len(movable_slots):
                continue  # not a contiguous block -- same precondition every other window move shares

            for target_day in range(len(itinerary)):
                if target_day in occurrence_days:
                    # Already has a (still-unsatisfying) copy of this POI -- inserting a second one
                    # here would create the exact duplicate the repeated-attraction commonsense
                    # rule rejects. Skip rather than risk it; a day with a genuinely free span and
                    # no existing copy is what this move exists to find.
                    continue
                trial = deepcopy(plan)
                if not self._remove_movable_activity(trial, source_day, source_idx, city, people):
                    continue
                target_activities = trial["itinerary"][target_day].get("activities", []) or []
                if not target_activities:
                    continue
                # ``original`` must be the plan as it stood at function entry, not the post-removal
                # trial: _repair_commit_allowed's unaccepted-input regime (TPC_COMMONSENSE_FIRST)
                # would otherwise compare the insertion against a baseline this move itself just
                # broke by deleting the source activity, so a plan that regresses relative to the
                # true starting point could still satisfy "improves on original".
                repair_context = (deepcopy(plan), query, was_accepted)
                placed = self._insert_activity_before_first(
                    trial, target_day, poi, activity_type, (lo2, hi2), city, people, check,
                    repair_context)
                if not placed:
                    for prev_idx in range(len(target_activities) - 1):
                        if self._insert_activity(
                                trial, target_day, prev_idx, poi, activity_type, (lo2, hi2), city,
                                people, check, repair_context):
                            placed = True
                            break
                if not placed:
                    placed = self._insert_activity_after_last(
                        trial, target_day, poi, activity_type, (lo2, hi2), city, people, check,
                        repair_context)
                if not placed:
                    continue
                if was_accepted and self._accepted_eval_key(trial) < before_key:
                    continue
                plan["itinerary"][source_day] = trial["itinerary"][source_day]
                plan["itinerary"][target_day] = trial["itinerary"][target_day]
                return True
        return False

    # --- Stage 3 LLM refine support (roadmap Next step 7 / TPC_P2_LLM_REFINE) ------------------
    #
    # The orchestrator's Stage 3 owns the bounded/timed/revert-on-failure control flow (see
    # ``orchestrator.llm_refine``); these methods are the WorldEnv-grounded primitives it calls
    # through the ``ground_and_check``/``apply_refine_edits`` hooks ``make_tpcagent_solve_fn``
    # attaches to the returned solve_fn. The LLM only proposes typed edit ops -- every position,
    # time, and leg an edit touches is re-derived here from ``self.env``/``_get_transport``, never
    # trusted from the model's output.

    def ground_and_check(self, plan, query):
        """Ground ``plan`` against WorldEnv and score it with the same acceptance checker
        ``_solve`` used for this query's best-so-far candidate (``_last_solve_constraints``,
        updated live during the search -- mirrors ``_timeout_recovery_plan``'s "best so far"
        semantics). Falls back to a fresh no-oracle constraint derivation if the search never
        got that far (e.g. every restart raised). Never raises. Returns ``(accepted,
        grounded_plan, eval_key, failure_summary)``."""
        constraints = self._last_solve_constraints
        if constraints is None:
            try:
                variants = self._constraint_variants(query) or [{}]
                constraints = deepcopy(variants[0] or {})
            except Exception:
                constraints = {}
        try:
            grounded = self._sanitize_plan_for_grounding(deepcopy(plan), query)
            check = self._make_checker(query, constraints)
            passed, total = check(grounded)
        except Exception:
            return False, plan, None, {}
        accepted = self._accepted(passed, total)
        eval_key = self._accepted_eval_key(grounded)
        failure_summary = self._describe_check_failure(query, constraints, grounded)
        return accepted, grounded, eval_key, failure_summary

    # Families whose value is a list of names (POIs/types/cuisines) or a list of dicts naming a
    # "location" -- these can be broken down to the specific failing item. Scalar/dict-shaped
    # families (budgets, room_type, hotel_nearby, intercity_mode, ...) have no single POI/location
    # to name and stay family-level only, in ``failed_constraint_families``.
    _REFINE_PER_ITEM_CLAUSE_FAMILIES = frozenset({
        "required_attractions", "excluded_attractions",
        "required_attraction_types", "excluded_attraction_types",
        "required_restaurants", "excluded_restaurants",
        "cuisine_preference", "excluded_cuisine_types",
        "required_hotels", "excluded_hotels", "required_hotel_all_types",
        "stay_duration", "activity_time_windows",
    })

    def _describe_failed_clause_items(self, family, value, plan, target_city):
        """Break a failing ``family`` down to the specific POI/location its list holds, by
        re-running ``evaluate_parsed_constraints`` one item at a time -- it returns a flat
        ``list[bool]`` with no label, so isolating a single item is the cheap way to name which one
        is unmet (bounded by a family's own item count, never more than a handful). Only families in
        ``_REFINE_PER_ITEM_CLAUSE_FAMILIES`` are broken down; everything else returns ``[]`` (still
        reported at family level by the caller). Never raises."""
        if family not in self._REFINE_PER_ITEM_CLAUSE_FAMILIES:
            return []
        items = value if isinstance(value, list) else [value]
        out = []
        for item in items:
            try:
                results = evaluate_parsed_constraints({family: [item]}, plan, target_city)
            except Exception:
                continue
            if results and all(results):
                continue
            if isinstance(item, dict):
                detail = item.get("location")
                if not detail:
                    continue
                # "item" is generic on purpose: dict-shaped families in this allowlist are not all
                # time windows (e.g. stay_duration's {location, min_minutes}) -- a family-specific
                # key like "window" would misdescribe those (Copilot review finding on PR #36).
                out.append({"family": family, "location": detail, "item": item})
            elif isinstance(item, str) and item:
                out.append({"family": family, "detail": item})
        return out

    def _find_space_gaps(self, plan):
        """Read-only diagnostic naming every broken inbound leg (day, position, expected origin)
        for the Stage 3 refine failure_summary -- mirrors ``_repair_transport_gaps``'s walk order
        (continuous across day boundaries, matching ``Is_space_correct``'s ``position_list``) but
        never mutates or attempts a fix; ``_repair_transport_gaps`` is the separately-gated,
        separately-tested repair pass this only informs the LLM prompt for. Never raises."""
        gaps = []
        try:
            prev_pos = None
            for day in plan.get("itinerary", []) or []:
                if not isinstance(day, dict):
                    continue
                for activity in day.get("activities", []) or []:
                    if not isinstance(activity, dict):
                        continue
                    is_intercity = activity.get("type") in ("airplane", "train")
                    if prev_pos is not None and not is_intercity:
                        if not self._transport_leg_valid(activity, prev_pos):
                            gaps.append({
                                "day": day.get("day"),
                                "position": self._activity_start_position(activity),
                                "expected_from": prev_pos,
                            })
                    prev_pos = self._activity_end_position(activity)
        except Exception:
            return []
        return gaps

    def _describe_check_failure(self, query, constraints, plan):
        """Compact, oracle-free description of which no-oracle constraint families and
        commonsense checks ``plan`` currently fails -- built only from the parsed ``constraints``
        dict (never ``hard_logic_py``) and the plan itself, for the Stage 3 LLM refine prompt.
        ``failed_constraint_families`` stays family-level (``evaluate_parsed_constraints`` returns a
        flat ``list[bool]`` with no label); ``failed_clauses`` sharpens the families in
        ``_REFINE_PER_ITEM_CLAUSE_FAMILIES`` down to the specific POI/location/window at fault
        (roadmap Next step 7 bucket 2), and ``space_gaps`` names the specific broken leg(s) when the
        commonsense "Invalid Transport information across positions" check fails."""
        target_city = query.get("target_city", "")
        failed_families = []
        failed_clauses = []
        for key, value in (constraints or {}).items():
            if value in (None, [], {}, ""):
                continue
            try:
                results = evaluate_parsed_constraints({key: value}, plan, target_city)
            except Exception:
                continue
            if results and not all(results):
                failed_families.append(key)
                failed_clauses.extend(self._describe_failed_clause_items(key, value, plan, target_city))
        failed_commonsense = self._commonsense_failure_columns(query, plan)
        schema_ok = self._schema_ok(query, plan)
        space_gaps = []
        if "Invalid Transport information across positions" in failed_commonsense:
            space_gaps = self._find_space_gaps(plan)
        # Feasible-window grounding costs a _get_transport lookup per activity -- skip it when
        # there is no env to ground against, or nothing is actually failing (an already-accepted
        # plan has nothing for Stage 3 to repair, so the context would be computed and discarded).
        feasible_windows = []
        if self.env is not None and (failed_families or failed_commonsense or not schema_ok):
            try:
                feasible_windows = self._refine_feasible_windows(query, plan)
            except Exception:
                feasible_windows = []
        return {
            "failed_constraint_families": failed_families,
            "failed_clauses": failed_clauses,
            "failed_commonsense_checks": failed_commonsense,
            "space_gaps": space_gaps,
            "schema_ok": schema_ok,
            "activity_feasible_windows": feasible_windows,
        }

    def _commonsense_failure_columns(self, query, plan):
        """Failing commonsense sub-check names (e.g. ``Is_space_correct``) for ``plan``, reusing
        the same no-oracle-safe call ``_commonsense_ok`` makes (``query`` is the harness-visible
        query dict, never ``hard_logic_py``). Returns ``[]`` on any error or when already passing."""
        uid = str(query.get("uid", ""))
        try:
            with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                _, _, result_agg, pass_id = evaluate_commonsense_constraints(
                    [uid], {uid: query}, {uid: plan}, verbose=False, lang=self.lang)
            if uid in pass_id:
                return []
            rows = result_agg[result_agg["data_id"] == uid]
            if rows.empty:
                return []
            row = rows.iloc[0]
            return [col for col in result_agg.columns if col != "data_id" and bool(row[col])]
        except Exception:
            return []

    _REFINE_MAX_EDITS = 6
    _REFINE_OP_HANDLERS_ATTR = (
        ("shift_activity_window", "_refine_shift_activity"),
        ("drop_activity", "_refine_drop_activity"),
        ("swap_activity", "_refine_swap_activity"),
        ("reorder_day", "_refine_reorder_day"),
        ("insert_activity", "_refine_insert_activity"),
    )

    def apply_refine_edits(self, plan, query, edits):
        """Apply a bounded list of LLM-proposed, typed edit ops to a deepcopy of ``plan``. Each op
        is grounded against WorldEnv through the same helpers the deterministic repair passes use
        (``_get_transport``, ``_activity_start/end_position``); an edit that references a day/POI
        the environment cannot resolve, or that cannot be legally re-legged, is dropped rather than
        fabricated. Never raises -- the caller re-checks the whole batch with ``ground_and_check``.
        Returns ``(trial_plan, applied_count, reasons)`` where ``reasons`` is a per-edit diagnostic
        list (``{"op", "committed", "reason"}``, oracle-free WorldEnv-grounding facts only) so a
        screen can see *why* a batch committed nothing (roadmap Next step 7's ``no_groundable_edits``
        bucket) instead of just the count."""
        trial = deepcopy(plan)
        city = str(query.get("target_city", ""))
        people = int(query.get("people_number", 1) or 1)
        handlers = dict(self._REFINE_OP_HANDLERS_ATTR)
        applied = 0
        reasons = []
        for edit in list(edits or [])[: self._REFINE_MAX_EDITS]:
            if not isinstance(edit, dict):
                reasons.append({"op": None, "committed": False, "reason": "malformed_edit"})
                continue
            op = str(edit.get("op") or "").strip()
            handler_name = handlers.get(op)
            if handler_name is None:
                reasons.append({"op": op or None, "committed": False, "reason": "unknown_op"})
                continue
            handler = getattr(self, handler_name)
            diag: list = []
            try:
                ok = handler(trial, edit, city, people, diag)
            except Exception:
                ok = False
                diag = ["handler_exception"]
            if ok:
                applied += 1
            reasons.append({"op": op, "committed": bool(ok), "reason": (diag[-1] if diag else None)})
        return trial, applied, reasons

    def _refine_day_index(self, plan, day_value):
        """Resolve an edit's 1-based ``day`` field to an itinerary index: match the day object's
        own ``day`` field first (robust to a plan whose list order and day numbers ever diverge),
        falling back to treating ``day_value`` as a 1-based position."""
        itinerary = plan.get("itinerary", []) or []
        try:
            day_num = int(day_value)
        except (TypeError, ValueError):
            return None
        for idx, day in enumerate(itinerary):
            if isinstance(day, dict) and day.get("day") == day_num:
                return idx
        if 1 <= day_num <= len(itinerary):
            return day_num - 1
        return None

    def _refine_find_activity_index(self, activities, location):
        """Index of the meal/attraction activity in ``activities`` whose position matches
        ``location`` (same bidirectional text match as ``_find_activities_at``). ``None`` when the
        edit names a POI not actually in this day -- the caller drops such an edit."""
        if not isinstance(location, str) or not location.strip():
            return None
        for idx, act in enumerate(activities):
            if not isinstance(act, dict) or act.get("type") not in self._WINDOW_ACTIVITY_TYPES:
                continue
            pos = str(act.get("position", ""))
            if pos and self._match_constraint_text(pos, location):
                return idx
        return None

    def _refine_shift_activity(self, trial, edit, city, people, diag=None):
        """``shift_activity_window`` edit: retime one named activity to an explicit
        ``[start_time, end_time]``, recomputing its own inbound leg and the following activity's
        inbound leg (same grounding as ``_try_pin_activity``, without that method's own
        accept-gate -- the batch is gated once, by the caller, via ``ground_and_check``).

        The proposed window is first snapped into the POI's real WorldEnv opening/closing bounds
        (roadmap Next step 7, bucket 1) rather than trialed verbatim: a plausible-but-slightly-off-
        hours proposal still grounds this way, instead of being dropped here or (previously) trialed
        only to fail the checker's commonsense hours check later. ``diag``, if given, gets one short
        reason string appended -- why the edit failed, or ``"committed"``."""
        def _fail(reason):
            if diag is not None:
                diag.append(reason)
            return False

        day_idx = self._refine_day_index(trial, edit.get("day"))
        if day_idx is None:
            return _fail("day_not_found")
        activities = trial["itinerary"][day_idx].get("activities", []) or []
        act_idx = self._refine_find_activity_index(activities, edit.get("location"))
        if act_idx is None:
            return _fail("location_not_found")
        activity = activities[act_idx]
        try:
            cur_start = time_to_minutes(str(activity.get("start_time", "00:00")))
            cur_end = time_to_minutes(str(activity.get("end_time", "00:00")))
            new_start = time_to_minutes(str(edit["start_time"])) if edit.get("start_time") else cur_start
            new_end = time_to_minutes(str(edit["end_time"])) if edit.get("end_time") else cur_end
        except Exception:
            return _fail("bad_time_format")
        if new_end <= new_start:
            return _fail("empty_window")

        bounds = self._lookup_poi_open_bounds(
            city, edit.get("location"), activity.get("type"), activity.get("tickets"))
        if bounds is not None:
            poi_open, poi_close = bounds
            new_start = max(new_start, poi_open)
            new_end = min(new_end, poi_close)
            if new_end <= new_start:
                return _fail("poi_closed_during_requested_window")

        if act_idx > 0 and activities[act_idx - 1].get("type") not in ("airplane", "train"):
            prev = activities[act_idx - 1]
            from_pos = self._activity_end_position(prev)
            depart = str(prev.get("end_time", "")) or minutes_to_time(new_start)
            try:
                transports_in, arrival = self._get_transport(
                    self.env, city, from_pos, self._activity_start_position(activity), depart, people)
            except Exception:
                return _fail("inbound_transport_error")
            if arrival is None:
                return _fail("inbound_transport_ungroundable")
            new_start = max(new_start, time_to_minutes(arrival))
            activity["transports"] = transports_in
        if new_end <= new_start:
            return _fail("no_time_left_after_arrival")
        activity["start_time"] = minutes_to_time(new_start)
        activity["end_time"] = minutes_to_time(new_end)

        if act_idx + 1 < len(activities) and activities[act_idx + 1].get("type") not in ("airplane", "train"):
            nxt = activities[act_idx + 1]
            next_pos = self._activity_start_position(nxt)
            try:
                transports_out, next_arrival = self._get_transport(
                    self.env, city, self._activity_end_position(activity), next_pos, minutes_to_time(new_end), people)
            except Exception:
                return _fail("outbound_transport_error")
            if next_arrival is None:
                return _fail("outbound_transport_ungroundable")
            next_start = str(nxt.get("start_time", ""))
            if next_start and time_to_minutes(next_arrival) > time_to_minutes(next_start):
                return _fail("next_activity_unreachable")
            nxt["transports"] = transports_out
        if diag is not None:
            diag.append("committed")
        return True

    def _refine_drop_activity(self, trial, edit, city, people, diag=None):
        """``drop_activity`` edit: remove one named activity from its day and reconnect the
        following activity's inbound leg from the new previous activity (same reconnect pattern as
        ``_sanitize_plan_for_grounding``'s illegal-intercity cleanup). Never drops a day down to
        zero activities."""
        def _fail(reason):
            if diag is not None:
                diag.append(reason)
            return False

        day_idx = self._refine_day_index(trial, edit.get("day"))
        if day_idx is None:
            return _fail("day_not_found")
        activities = trial["itinerary"][day_idx].get("activities", []) or []
        if len(activities) <= 1:
            return _fail("would_empty_day")
        act_idx = self._refine_find_activity_index(activities, edit.get("location"))
        if act_idx is None:
            return _fail("location_not_found")
        del activities[act_idx]
        if act_idx < len(activities):
            nxt = activities[act_idx]
            if nxt.get("type") not in ("airplane", "train"):
                transports = []
                if act_idx > 0:
                    prev = activities[act_idx - 1]
                    from_pos = self._activity_end_position(prev)
                    depart = str(prev.get("end_time", ""))
                    to_pos = self._activity_start_position(nxt)
                    if from_pos and depart and to_pos:
                        try:
                            transports, _arrival = self._get_transport(self.env, city, from_pos, to_pos, depart, people)
                        except Exception:
                            transports = []
                nxt["transports"] = transports or []
        if diag is not None:
            diag.append("committed")
        return True

    def _refine_swap_activity(self, trial, edit, city, people, diag=None):
        """``swap_activity`` edit: swap two named activities' order within a day and re-leg the
        day's movable block (``_relayout_movable_block``, no window clamp)."""
        def _fail(reason):
            if diag is not None:
                diag.append(reason)
            return False

        day_idx = self._refine_day_index(trial, edit.get("day"))
        if day_idx is None:
            return _fail("day_not_found")
        activities = trial["itinerary"][day_idx].get("activities", []) or []
        movable_slots = [
            i for i, a in enumerate(activities)
            if a.get("type") in self._WINDOW_ACTIVITY_TYPES and str(a.get("position", ""))
        ]
        if len(movable_slots) < 2 or movable_slots[-1] - movable_slots[0] + 1 != len(movable_slots):
            return _fail("day_not_contiguous_movable_block")
        idx_a = self._refine_find_activity_index(activities, edit.get("location_a"))
        idx_b = self._refine_find_activity_index(activities, edit.get("location_b"))
        if idx_a is None or idx_b is None or idx_a == idx_b:
            return _fail("location_not_found")
        if idx_a not in movable_slots or idx_b not in movable_slots:
            return _fail("location_not_movable")
        pos_a, pos_b = movable_slots.index(idx_a), movable_slots.index(idx_b)
        order = list(range(len(movable_slots)))
        order[pos_a], order[pos_b] = order[pos_b], order[pos_a]
        ok = self._relayout_movable_block(trial, day_idx, movable_slots, order, city, people)
        if diag is not None:
            diag.append("committed" if ok else "relayout_ungroundable")
        return ok

    def _refine_reorder_day(self, trial, edit, city, people, diag=None):
        """``reorder_day`` edit: reorder a day's movable block to an explicit LLM-given
        ``order`` (list of position names). A named entry that cannot be matched, or that is
        missing entirely, keeps the unmatched slots at the end in their original relative order --
        a partial match is worse than nothing, but not fatal on its own; the caller's acceptance
        gate is the real filter."""
        def _fail(reason):
            if diag is not None:
                diag.append(reason)
            return False

        day_idx = self._refine_day_index(trial, edit.get("day"))
        if day_idx is None:
            return _fail("day_not_found")
        activities = trial["itinerary"][day_idx].get("activities", []) or []
        movable_slots = [
            i for i, a in enumerate(activities)
            if a.get("type") in self._WINDOW_ACTIVITY_TYPES and str(a.get("position", ""))
        ]
        if len(movable_slots) < 2 or movable_slots[-1] - movable_slots[0] + 1 != len(movable_slots):
            return _fail("day_not_contiguous_movable_block")

        order_locations = [x for x in (edit.get("order") or []) if isinstance(x, str)]
        if not order_locations:
            return _fail("empty_order")
        remaining = list(range(len(movable_slots)))
        picked = []
        for loc in order_locations:
            match_k = None
            for k in remaining:
                if self._match_constraint_text(activities[movable_slots[k]].get("position", ""), loc):
                    match_k = k
                    break
            if match_k is not None:
                picked.append(match_k)
                remaining.remove(match_k)
        order = picked + remaining
        if order == list(range(len(movable_slots))):
            return _fail("no_change_proposed")
        ok = self._relayout_movable_block(trial, day_idx, movable_slots, order, city, people)
        if diag is not None:
            diag.append("committed" if ok else "relayout_ungroundable")
        return ok

    def _refine_insert_activity(self, trial, edit, city, people, diag=None):
        """``insert_activity`` edit (roadmap P6): add a WorldEnv-grounded activity for a named POI
        the plan does not yet contain -- the one thing the other four ops cannot express, since
        each of them only ever references an activity already in the plan. A missing required
        attraction/restaurant is a real, common failure shape a shift/swap/drop/reorder loop can
        never fix.

        ``location`` is never trusted as free-form JSON: it must resolve to a real catalog row via
        ``_resolve_timed_window_poi`` or the edit is dropped -- matching the roadmap's "add an
        insertion/replacement op only through a WorldEnv lookup, never as free-form plan JSON".
        Placement is derived from the requested ``start_time`` (the first existing activity that
        starts no earlier becomes the successor; falls back to appending at the end), and every
        leg on both sides is recomputed via ``_best_transport_via_get_transport`` -- same grounding
        discipline as ``_insert_activity``/``_insert_activity_before_first``/
        ``_insert_activity_after_last`` (P8/P9/P25), but without their own per-op accept-gate: like
        every other ``_refine_*`` handler, acceptance of the whole batch is the caller's job via
        ``ground_and_check``."""
        def _fail(reason):
            if diag is not None:
                diag.append(reason)
            return False

        day_idx = self._refine_day_index(trial, edit.get("day"))
        if day_idx is None:
            return _fail("day_not_found")
        activity_type = str(edit.get("activity_type") or "").strip().lower()
        if activity_type not in self._WINDOW_ACTIVITY_TYPES:
            return _fail("bad_activity_type")
        location = edit.get("location")
        if not isinstance(location, str) or not location.strip():
            return _fail("missing_location")
        poi = self._resolve_timed_window_poi(city, location, activity_type)
        if poi is None:
            return _fail("poi_not_found_in_catalog")
        poi_name = str(poi.get("name", location))

        activities = trial["itinerary"][day_idx].get("activities", []) or []
        matching_types = ({"breakfast", "lunch", "dinner"}
                          if activity_type in ("breakfast", "lunch", "dinner")
                          else {activity_type})
        for act in activities:
            if act.get("type") in matching_types and self._match_constraint_text(
                    str(act.get("position", "")), poi_name):
                # Already present for this type -- adding a second copy would trip the
                # repeated-attraction commonsense rule and reject the whole batch for nothing.
                return _fail("already_present")

        try:
            req_start = time_to_minutes(str(edit["start_time"])) if edit.get("start_time") else None
            req_end = time_to_minutes(str(edit["end_time"])) if edit.get("end_time") else None
        except Exception:
            return _fail("bad_time_format")

        insert_idx = len(activities)
        if req_start is not None:
            for i, act in enumerate(activities):
                try:
                    act_start = time_to_minutes(str(act.get("start_time", "")))
                except Exception:
                    continue
                if act_start >= req_start:
                    insert_idx = i
                    break

        prev_act = activities[insert_idx - 1] if insert_idx > 0 else None
        next_act = activities[insert_idx] if insert_idx < len(activities) else None
        if prev_act is not None and prev_act.get("type") in ("airplane", "train") and next_act is None:
            # Appending after the day's final intercity departure would place a visit after the
            # traveller has already left the city -- nonsensical regardless of grounding.
            return _fail("cannot_append_after_intercity_departure")

        poi_open, poi_close = self._poi_open_bounds(poi)
        dwell = self._densify_dwell_minutes(poi, activity_type)

        prev_pos = self._activity_end_position(prev_act) if prev_act is not None else None
        if prev_pos:
            prev_end = str(prev_act.get("end_time", "")) or minutes_to_time(poi_open)
            try:
                transports_in, arrival = self._best_transport_via_get_transport(
                    city, prev_pos, poi_name, prev_end, people)
            except Exception:
                return _fail("inbound_transport_error")
            if transports_in is None or arrival is None:
                return _fail("inbound_transport_ungroundable")
            try:
                arrival_min = time_to_minutes(str(arrival))
            except Exception:
                return _fail("bad_time_format")
        else:
            transports_in, arrival_min = [], poi_open

        start_min = max(arrival_min, poi_open, req_start if req_start is not None else arrival_min)
        end_min = min(req_end if req_end is not None else start_min + dwell, poi_close)
        if end_min - start_min < 1:
            return _fail("no_time_available")

        transports_out = None
        if next_act is not None:
            next_pos = self._activity_start_position(next_act)
            if not next_pos:
                return _fail("next_position_unresolvable")
            try:
                transports_out, next_arrival = self._best_transport_via_get_transport(
                    city, poi_name, next_pos, minutes_to_time(end_min), people)
            except Exception:
                return _fail("outbound_transport_error")
            if transports_out is None or next_arrival is None:
                return _fail("outbound_transport_ungroundable")
            next_start = str(next_act.get("start_time", ""))
            try:
                if next_start and time_to_minutes(next_arrival) > time_to_minutes(next_start):
                    return _fail("next_activity_unreachable")
            except Exception:
                return _fail("bad_time_format")

        if activity_type == "attraction":
            activity = self._make_attraction_activity(
                poi, people, minutes_to_time(start_min), minutes_to_time(end_min), transports_in)
        else:
            activity = self._make_meal_activity(
                activity_type, poi, people, minutes_to_time(start_min), minutes_to_time(end_min),
                transports_in)

        if next_act is not None:
            next_act["transports"] = transports_out
        activities.insert(insert_idx, activity)
        trial["itinerary"][day_idx]["activities"] = activities
        if diag is not None:
            diag.append("committed")
        return True

    def _extend_window_meals(self, plan, query, constraints, check, restaurants):
        """Swap a bounding intercity to a wider-window option and add the meal it unlocks.

        Purely additive: every existing activity is preserved and the trial is discarded
        unless the full checker accepts it and the activity count rises. This targets
        travel-day DDR -- a last-day dinner reachable after a later return, a day-1
        breakfast reachable after an earlier arrival -- the meal slots the default
        earliest-departure selection closes. Gains are locked in by the monotonic merge.
        """
        if not plan.get("itinerary"):
            return
        start_city = query.get("start_city", "")
        target_city = query.get("target_city", "")
        people = int(query.get("people_number", 1) or 1)
        intercity_mode = constraints.get("intercity_mode", None)
        outbound_pref = return_pref = None
        if isinstance(intercity_mode, dict):
            outbound_pref = intercity_mode.get("outbound", None)
            return_pref = intercity_mode.get("return", None)
        elif isinstance(intercity_mode, str):
            outbound_pref = return_pref = intercity_mode
        default_late_dinner = "1" if self.use_oracle else "0"
        default_early_breakfast = "1" if self.use_oracle else "0"
        if os.environ.get("TPC_DENSIFY_LATE_DINNER", default_late_dinner) == "1":
            self._swap_return_add_dinner(plan, start_city, target_city, people, return_pref, restaurants, check)
        if os.environ.get("TPC_DENSIFY_EARLY_BREAKFAST", default_early_breakfast) == "1":
            self._swap_outbound_add_breakfast(plan, start_city, target_city, people, outbound_pref, restaurants, check)

    def _swap_return_add_dinner(self, plan, start_city, target_city, people, return_pref, restaurants, check):
        itinerary = plan.get("itinerary", []) or []
        last_idx = len(itinerary) - 1
        if last_idx < 0:
            return
        before_key = self._accepted_eval_key(plan)
        acts = itinerary[last_idx].get("activities", []) or []
        if len(acts) < 2 or acts[-1].get("type") not in ("airplane", "train"):
            return
        if any(a.get("type") == "dinner" for a in acts):
            return
        try:
            cur_dep = time_to_minutes(str(acts[-1].get("start_time", "")))
        except Exception:
            return
        min_dep = self._env_time_minutes("TPC_DENSIFY_LATE_DINNER_MIN_DEP", "20:30")
        dinner_close = self._env_time_minutes("TPC_DENSIFY_DINNER_WIN_CLOSE", "20:00")
        if cur_dep >= min_dep:
            return
        later = self._get_intercity(
            self.env, target_city, start_city, "00:00", return_pref,
            self._budget_limits, {}, pending_intercity=None, people=people, window="late")
        if later is None:
            return
        try:
            new_dep = time_to_minutes(str(later.get("BeginTime", "")))
        except Exception:
            return
        if new_dep < min_dep or new_dep <= cur_dep:
            return
        trial = deepcopy(plan)
        tacts = trial["itinerary"][last_idx]["activities"]
        prev_pos = self._activity_end_position(tacts[-2])
        try:
            transports, _ = self._get_transport(
                self.env, target_city, prev_pos, later["From"], str(tacts[-2].get("end_time", "")), people)
        except Exception:
            transports = None
        tacts[-1] = self._make_intercity_activity(later, people, transports or [])
        for restaurant in restaurants:
            if not self._norm_text(restaurant.get("name", "")):
                continue
            if self._insert_activity(
                    trial, last_idx, len(tacts) - 2, restaurant, "dinner",
                    (17 * 60, dinner_close), target_city, people, check):
                try:
                    if self._accepted_eval_key(trial) >= before_key:
                        itinerary[last_idx]["activities"] = trial["itinerary"][last_idx]["activities"]
                        return
                except Exception:
                    continue

    def _swap_outbound_add_breakfast(self, plan, start_city, target_city, people, outbound_pref, restaurants, check):
        itinerary = plan.get("itinerary", []) or []
        if not itinerary:
            return
        before_key = self._accepted_eval_key(plan)
        acts = itinerary[0].get("activities", []) or []
        if len(acts) < 2 or acts[0].get("type") not in ("airplane", "train"):
            return
        if any(a.get("type") == "breakfast" for a in acts):
            return
        try:
            cur_arr = time_to_minutes(str(acts[0].get("end_time", "")))
        except Exception:
            return
        earlier = self._get_intercity(
            self.env, start_city, target_city, "00:00", outbound_pref,
            self._budget_limits, {}, pending_intercity=None, people=people, window="early_arrival")
        if earlier is None:
            return
        try:
            new_dep = time_to_minutes(str(earlier.get("BeginTime", "")))
            new_arr = time_to_minutes(str(earlier.get("EndTime", "")))
            if new_arr < new_dep:
                new_arr += 1440
        except Exception:
            return
        # Breakfast must end by 09:00; require an arrival early enough to seat it with transport.
        if new_arr > time_to_minutes("08:15") or new_arr >= cur_arr:
            return
        trial = deepcopy(plan)
        tacts = trial["itinerary"][0]["activities"]
        tacts[0] = self._make_intercity_activity(earlier, people, [])
        for restaurant in restaurants:
            if not self._norm_text(restaurant.get("name", "")):
                continue
            if self._insert_activity(
                    trial, 0, 0, restaurant, "breakfast",
                    (6 * 60, 9 * 60), target_city, people, check):
                try:
                    if self._accepted_eval_key(trial) >= before_key:
                        itinerary[0]["activities"] = trial["itinerary"][0]["activities"]
                        return
                except Exception:
                    continue

    def _densify_plan(self, plan, query, constraints, check):
        """Insert opt-in meals/attractions into proven idle gaps without trading away acceptance.

        Only runs for already accepted plans and only when at least one Task 3 packing flag is on.
        Every insertion is gated by the full oracle/schema/commonsense checker and reverted on
        failure, so budget, exclusion, timing, transport, and query-specific hard constraints stay
        correct even though this pass only reasons locally about idle windows.
        """
        try:
            if not self._accepted(*check(plan)):
                return plan
        except Exception:
            return plan
        if not self._packing_enabled():
            return plan
        try:
            from agent.tpc_agent.cp_candidates import build_candidate_context
            ctx = build_candidate_context(
                self, query, constraints or {}, {"attractions": 80, "restaurants": 50, "hotels": 1})
        except Exception:
            return plan

        dense = deepcopy(plan)
        city = query.get("target_city", "")
        people = int(query.get("people_number", 1) or 1)
        constraints = constraints or {}
        self._set_transport_context(constraints)

        restaurants = sorted(ctx.get("restaurants", []) or [], key=lambda r: (r.get("price_cents", 0), r.get("name", "")))
        attractions = list(ctx.get("attractions", []) or [])
        coords = {}
        for row in attractions + restaurants + (ctx.get("hotels", []) or []):
            name = self._norm_text(row.get("name", ""))
            if name and "lat" in row and "lon" in row:
                coords[name] = row

        used_restaurants = set()
        used_attractions = set()
        for day in dense.get("itinerary", []) or []:
            for activity in day.get("activities", []) or []:
                name = self._norm_text(activity.get("position", ""))
                if activity.get("type") in ("breakfast", "lunch", "dinner") and name:
                    used_restaurants.add(name)
                elif activity.get("type") == "attraction" and name:
                    used_attractions.add(name)

        itinerary = dense.get("itinerary", []) or []
        # Opt-in (``TPC_DENSIFY_COMPRESS_BEFORE``, default off): trim over-long visits back to the
        # standard dwell before packing, so a day whose meal band is merely *occupied* -- not
        # genuinely full -- can still take the missing meal or attraction. Each trim is reverted
        # unless the full checker still accepts, so a ``stay_duration`` clause that requires the
        # longer visit keeps it. Counts and transports are untouched, so this move alone cannot
        # change any preference term; it only creates room for the passes below.
        self._compress_activity_windows(dense, check)
        # Idle-gap attraction packing knobs. The former 130-min threshold / 18:00 cutoff left
        # many real 90-120 min gaps (breakfast->lunch, afternoon->dinner) and all evening slots
        # unfilled; every insertion is still gated by the full checker via _insert_activity.
        default_attr_gap = "60" if self.use_oracle else "75"
        attr_gap_min = int(os.environ.get("TPC_DENSIFY_ATTR_GAP_MIN", default_attr_gap))
        attr_win_open = int(os.environ.get("TPC_DENSIFY_ATTR_WIN_OPEN", "9")) * 60
        attr_win_close = int(os.environ.get("TPC_DENSIFY_ATTR_WIN_CLOSE", "21")) * 60
        default_attr_candidates = "32" if self.use_oracle else "24"
        attr_candidate_limit = int(os.environ.get("TPC_DENSIFY_ATTR_CANDIDATES", default_attr_candidates))
        def _ranked_attractions(anchor_row=None, next_row=None):
            return sorted(
                attractions,
                key=lambda a: (
                    (self._haversine_km(anchor_row, a) if anchor_row is not None else 0.0)
                    + (self._haversine_km(a, next_row) if next_row is not None else 0.0),
                    a.get("price_cents", 0),
                    a.get("name", ""),
                ),
            )[:attr_candidate_limit]

        # The official DAV score is plan-level -- ``attraction_count / (4 * day_count)``, clamped
        # at 1 -- so a day that physically cannot hold four attractions (a travel day around a
        # fixed train, a day whose POIs all shut early) is recoverable: a later day with room can
        # carry the shortfall. Packing every day to a hard four leaves that headroom on the table.
        # Days are visited in order, so the allowance accumulates forward; a deficit on the final
        # day still cannot be made up, and the per-day ceiling keeps a single day from absorbing
        # the whole plan.
        attr_day_cap = max(4, int(os.environ.get("TPC_DENSIFY_ATTR_DAY_CAP", "8")))
        attr_plan_target = 4 * max(1, len(itinerary))

        def day_attr_cap(day_index):
            total = sum(
                1
                for day_i in itinerary
                for activity in (day_i.get("activities", []) or [])
                if activity.get("type") == "attraction"
            )
            here = sum(
                1
                for activity in (itinerary[day_index].get("activities", []) or [])
                if activity.get("type") == "attraction"
            )
            if total >= attr_plan_target:
                return 4  # plan already at a perfect DAV; keep the original per-day target
            return min(attr_day_cap, here + (attr_plan_target - total))

        for day_idx, day in enumerate(itinerary):
            activities = day.get("activities", []) or []
            if not activities:
                continue
            meal_types = {a.get("type") for a in activities if a.get("type") in ("breakfast", "lunch", "dinner")}
            default_gap = "45" if self.use_oracle else "60"
            meal_gap_min = max(1, int(os.environ.get("TPC_DENSIFY_MEAL_GAP_MIN", default_gap)))
            if self._pack_ddr_enabled():
                # Breakfast first: it is the earliest band (06:00--09:00) and the only meal the
                # top-up used to skip entirely, so on an arrival day it competes with nothing.
                # _insert_restaurant_breakfast owns the band and the before-first/gap/after-last
                # placement order; every placement it tries is full-checker gated.
                if "breakfast" not in meal_types:
                    breakfast_name = self._insert_restaurant_breakfast(
                        dense, day_idx, restaurants, city, people, check, used_restaurants)
                    if breakfast_name:
                        used_restaurants.add(breakfast_name)
                        meal_types.add("breakfast")
                lunch_close = self._env_time_minutes("TPC_DENSIFY_LUNCH_WIN_CLOSE", "14:00")
                dinner_close = self._env_time_minutes("TPC_DENSIFY_DINNER_WIN_CLOSE", "20:00")
                for meal_type, window in (("lunch", (11 * 60, lunch_close)), ("dinner", (17 * 60, dinner_close))):
                    if meal_type in meal_types:
                        continue
                    inserted = False
                    for restaurant in restaurants:
                        r_name = self._norm_text(restaurant.get("name", ""))
                        if not r_name or r_name in used_restaurants:
                            continue
                        if self._insert_activity_before_first(dense, day_idx, restaurant, meal_type, window, city, people, check):
                            used_restaurants.add(r_name)
                            meal_types.add(meal_type)
                            inserted = True
                            break
                        for prev_idx, _gap_start, _gap_end in self._day_gaps(activities, window[0], window[1], meal_gap_min):
                            if self._insert_activity(dense, day_idx, prev_idx, restaurant, meal_type, window, city, people, check):
                                used_restaurants.add(r_name)
                                meal_types.add(meal_type)
                                inserted = True
                                break
                        if inserted:
                            break
                        if self._insert_activity_after_last(dense, day_idx, restaurant, meal_type, window, city, people, check):
                            used_restaurants.add(r_name)
                            meal_types.add(meal_type)
                            inserted = True
                            break

            if self._pack_dav_enabled():
                while sum(1 for a in activities if a.get("type") == "attraction") < day_attr_cap(day_idx):
                    gaps = self._day_gaps(activities, attr_win_open, attr_win_close, attr_gap_min)
                    inserted = False
                    for prev_idx, _gap_start, _gap_end in gaps:
                        prev_name = self._norm_text(self._activity_end_position(activities[prev_idx]))
                        next_name = self._norm_text(self._activity_start_position(activities[prev_idx + 1]))
                        for attr in _ranked_attractions(coords.get(prev_name), coords.get(next_name)):
                            a_name = self._norm_text(attr.get("name", ""))
                            if not a_name or a_name in used_attractions:
                                continue
                            if self._insert_activity(dense, day_idx, prev_idx, attr, "attraction", (attr_win_open, attr_win_close), city, people, check):
                                used_attractions.add(a_name)
                                inserted = True
                                break
                        if inserted:
                            break
                    if not inserted:
                        first_name = self._norm_text(self._activity_start_position(activities[0]))
                        first_coords = coords.get(first_name)
                        for attr in _ranked_attractions(first_coords, first_coords):
                            a_name = self._norm_text(attr.get("name", ""))
                            if not a_name or a_name in used_attractions:
                                continue
                            if self._insert_activity_before_first(dense, day_idx, attr, "attraction", (attr_win_open, attr_win_close), city, people, check):
                                used_attractions.add(a_name)
                                inserted = True
                                break
                    if not inserted:
                        last_name = self._norm_text(self._activity_end_position(activities[-1]))
                        for attr in _ranked_attractions(coords.get(last_name)):
                            a_name = self._norm_text(attr.get("name", ""))
                            if not a_name or a_name in used_attractions:
                                continue
                            if self._insert_activity_after_last(dense, day_idx, attr, "attraction", (attr_win_open, attr_win_close), city, people, check):
                                used_attractions.add(a_name)
                                inserted = True
                                break
                    if not inserted:
                        break

        if self._pack_hotel_breakfast_enabled():
            self._topup_hotel_breakfasts(dense, check)
        if self._pack_att_enabled():
            dense = self._optimize_att(dense, query, constraints, check, attractions, restaurants, coords)
        return dense

    def _optimize_att(self, plan, query, constraints, check, attractions, restaurants, coords):
        """Count-preserving ATT pass: faster hop modes, then nearer POIs, until it converges.

        Runs after the top-up passes so it also shortens the hops those passes introduced. Each
        sub-move is independently full-checker gated and keeps attraction/meal counts fixed, so
        DAV/DDR/C-LPR/FPR cannot regress; the loop stops as soon as a round stops improving the
        preference sum (bounded by ``TPC_PACK_ATT_ROUNDS``, default 3).
        """
        try:
            rounds = max(1, int(os.environ.get("TPC_PACK_ATT_ROUNDS", "3")))
        except Exception:
            rounds = 3
        for _ in range(rounds):
            try:
                before = sum(self._default_preference_components(plan))
            except Exception:
                return plan
            for step in (
                lambda p: self._upgrade_transport_modes(p, query, constraints, check),
                lambda p: self._swap_attractions_for_att(p, query, constraints, check, attractions, coords),
                lambda p: self._swap_restaurants_for_att(p, query, constraints, check, restaurants, coords),
            ):
                try:
                    plan = step(plan) or plan
                except Exception:
                    continue
            try:
                if sum(self._default_preference_components(plan)) <= before + 1e-9:
                    break
            except Exception:
                break
        return plan

    def _swap_restaurants_for_att(self, plan, query, constraints, check, restaurants, coords):
        """Replace high-transit meal venues with nearer alternatives.

        This complements `_swap_attractions_for_att`: many remaining low-ATT plans
        are dominated by long walks to lunch/dinner while the attraction set is
        already near-optimal. Every swap is acceptance-gated and keeps meal count
        unchanged, so DDR/FPR/C-LPR do not regress.
        """
        if os.environ.get("TPC_DENSIFY_SWAP_MEALS", "1") == "0":
            return plan
        try:
            if not self._accepted(*check(plan)):
                return plan
        except Exception:
            return plan

        city = query.get("target_city", "")
        people = int(query.get("people_number", 1) or 1)
        constraints = constraints or {}

        protected_locations = set()
        for req in constraints.get("required_restaurants", []) or []:
            protected_locations.add(self._norm_text(req))
        for window in constraints.get("activity_time_windows", []) or []:
            if isinstance(window, dict) and window.get("location"):
                protected_locations.add(self._norm_text(window["location"]))
        for stay in constraints.get("stay_duration", []) or []:
            if isinstance(stay, dict) and stay.get("location"):
                protected_locations.add(self._norm_text(stay["location"]))
        for name in constraints.get("position_presence", []) or []:
            if name:
                protected_locations.add(self._norm_text(name))

        cuisine_pref = constraints.get("cuisine_preference", None)
        meal_windows = {
            "breakfast": (6 * 60, self._env_time_minutes("TPC_DENSIFY_BREAKFAST_WIN_CLOSE", "09:00")),
            "lunch": (11 * 60, self._env_time_minutes("TPC_DENSIFY_LUNCH_WIN_CLOSE", "14:00")),
            "dinner": (17 * 60, self._env_time_minutes("TPC_DENSIFY_DINNER_WIN_CLOSE", "20:00")),
        }
        max_swaps = int(os.environ.get("TPC_DENSIFY_MEAL_SWAP_MAX", "8"))
        swap_candidate_limit = int(os.environ.get("TPC_DENSIFY_MEAL_SWAP_CANDIDATES", "16"))
        swaps_done = 0

        used_names = set()
        for day in plan.get("itinerary", []) or []:
            for activity in day.get("activities", []) or []:
                if activity.get("type") in ("breakfast", "lunch", "dinner"):
                    used_names.add(self._norm_text(activity.get("position", "")))

        swappable = []
        for day_idx, day in enumerate(plan.get("itinerary", []) or []):
            activities = day.get("activities", []) or []
            for act_idx, activity in enumerate(activities):
                meal_type = activity.get("type")
                if meal_type not in meal_windows:
                    continue
                if self._safe_float(activity.get("price", 0.0), 0.0) <= 0.0:
                    continue
                pos_name = self._norm_text(activity.get("position", ""))
                if not pos_name:
                    continue
                if any(self._match_constraint_text(pos_name, p) for p in protected_locations):
                    continue
                transit_min = self._inner_activity_minutes(activity)
                swappable.append((transit_min, day_idx, act_idx, pos_name))
        swappable.sort(reverse=True)

        for transit_min, day_idx, act_idx, old_name in swappable:
            if swaps_done >= max_swaps:
                break
            if transit_min <= 10:
                break

            activities = plan["itinerary"][day_idx]["activities"]
            activity = activities[act_idx]
            meal_type = activity.get("type")
            window_open, window_close = meal_windows[meal_type]

            prev_raw_pos = None
            next_raw_pos = None
            if act_idx > 0:
                prev_raw_pos = self._activity_end_position(activities[act_idx - 1])
            if act_idx + 1 < len(activities):
                next_raw_pos = self._activity_start_position(activities[act_idx + 1])
            prev_coord = coords.get(self._norm_text(prev_raw_pos or ""))
            next_coord = coords.get(self._norm_text(next_raw_pos or ""))

            candidates = sorted(
                restaurants,
                key=lambda r: (
                    (self._haversine_km(prev_coord, r) if prev_coord is not None else 0.0)
                    + (self._haversine_km(r, next_coord) if next_coord is not None else 0.0),
                    r.get("price_cents", 0),
                    r.get("name", ""),
                ),
            )[:swap_candidate_limit]

            old_activity = deepcopy(activity)
            old_start_time = str(activity.get("start_time", ""))
            old_end_time = str(activity.get("end_time", ""))
            meal_len = time_to_minutes(old_end_time) - time_to_minutes(old_start_time) if old_start_time and old_end_time else 60
            from_pos = prev_raw_pos or str(activity.get("position", ""))
            if prev_raw_pos and act_idx > 0:
                depart_time = str(activities[act_idx - 1].get("end_time", "08:00"))
            else:
                depart_time = old_start_time

            for cand in candidates:
                cand_name = self._norm_text(cand.get("name", ""))
                cand_actual_name = str(cand.get("name", ""))
                if not cand_name or cand_name == old_name or cand_name in used_names:
                    continue
                if cuisine_pref and not self._match_constraint_text(cand.get("cuisine", ""), cuisine_pref):
                    continue

                cand_open, cand_close = self._poi_open_bounds(cand)
                transports_in, arrival = self._get_transport(
                    self.env, city, from_pos, cand_actual_name, depart_time, people)
                if transports_in is None or arrival is None:
                    continue
                start_min = max(time_to_minutes(arrival), window_open, cand_open)
                end_min = start_min + meal_len
                if end_min > min(window_close, cand_close):
                    continue

                transports_out = None
                if next_raw_pos and act_idx + 1 < len(activities):
                    next_start = str(activities[act_idx + 1].get("start_time", ""))
                    transports_out, next_arrival = self._get_transport(
                        self.env, city, cand_actual_name, next_raw_pos, minutes_to_time(end_min), people)
                    if transports_out is None or next_arrival is None:
                        continue
                    if next_start and time_to_minutes(next_arrival) > time_to_minutes(next_start):
                        continue

                new_activity = self._make_meal_activity(
                    meal_type, cand, people, minutes_to_time(start_min), minutes_to_time(end_min), transports_in)
                new_transit = self._inner_activity_minutes(new_activity)
                if new_transit >= transit_min:
                    continue

                before_key = self._accepted_eval_key(plan)
                old_next_transports = None
                if transports_out is not None and act_idx + 1 < len(activities):
                    old_next_transports = deepcopy(activities[act_idx + 1].get("transports", []))
                    activities[act_idx + 1]["transports"] = transports_out
                activities[act_idx] = new_activity
                try:
                    if self._accepted(*check(plan)) and self._accepted_eval_key(plan) >= before_key:
                        used_names.discard(old_name)
                        used_names.add(cand_name)
                        swaps_done += 1
                        break
                except Exception:
                    pass
                activities[act_idx] = old_activity
                if old_next_transports is not None:
                    activities[act_idx + 1]["transports"] = old_next_transports

        return plan

    def _swap_attractions_for_att(self, plan, query, constraints, check, attractions, coords):
        """Replace high-transit-time attractions with geographically closer alternatives.

        Targets ATT by reducing average innercity_transport_time. Each swap is gated by the
        full checker so hard constraints, budget, and activity counts never regress. Only
        non-required attractions are considered for replacement.
        """
        if os.environ.get("TPC_DENSIFY_SWAP_ATT", "1") == "0":
            return plan
        try:
            if not self._accepted(*check(plan)):
                return plan
        except Exception:
            return plan

        city = query.get("target_city", "")
        people = int(query.get("people_number", 1) or 1)
        constraints = constraints or {}
        required_attractions = set()
        for req in constraints.get("required_attractions", []) or []:
            required_attractions.add(self._norm_text(req))
        for req in constraints.get("required_attraction_types", []) or []:
            required_attractions.add(self._norm_text(req))
        # Also protect attractions named in time windows or stay duration constraints.
        for w in constraints.get("activity_time_windows", []) or []:
            if isinstance(w, dict) and w.get("location"):
                required_attractions.add(self._norm_text(w["location"]))
        for d in constraints.get("stay_duration", []) or []:
            if isinstance(d, dict) and d.get("location"):
                required_attractions.add(self._norm_text(d["location"]))

        max_swaps = int(os.environ.get("TPC_DENSIFY_SWAP_MAX", "8"))
        swap_candidate_limit = int(os.environ.get("TPC_DENSIFY_SWAP_CANDIDATES", "12"))
        swaps_done = 0

        # Collect all current attraction names in the plan to avoid duplicates.
        used_names = set()
        for day in plan.get("itinerary", []) or []:
            for activity in day.get("activities", []) or []:
                if activity.get("type") == "attraction":
                    used_names.add(self._norm_text(activity.get("position", "")))

        # Build ranked list of swappable attractions by transit duration (longest first).
        swappable = []
        for day_idx, day in enumerate(plan.get("itinerary", []) or []):
            activities = day.get("activities", []) or []
            for act_idx, activity in enumerate(activities):
                if activity.get("type") != "attraction":
                    continue
                pos_name = self._norm_text(activity.get("position", ""))
                if not pos_name:
                    continue
                # Don't swap required attractions.
                if any(self._match_constraint_text(pos_name, r) for r in required_attractions):
                    continue
                transit_min = self._inner_activity_minutes(activity)
                swappable.append((transit_min, day_idx, act_idx, pos_name))
        swappable.sort(reverse=True)

        for transit_min, day_idx, act_idx, old_name in swappable:
            if swaps_done >= max_swaps:
                break
            if transit_min <= 10:
                break  # Not worth swapping short transits.

            activities = plan["itinerary"][day_idx]["activities"]
            activity = activities[act_idx]
            # Get raw (non-normalized) position names for transport API.
            prev_raw_pos = None
            next_raw_pos = None
            if act_idx > 0:
                prev_raw_pos = self._activity_end_position(activities[act_idx - 1])
            if act_idx + 1 < len(activities):
                next_raw_pos = self._activity_start_position(activities[act_idx + 1])
            prev_coord = coords.get(self._norm_text(prev_raw_pos or ""))
            next_coord = coords.get(self._norm_text(next_raw_pos or ""))

            # Rank candidate attractions by combined distance to prev + next.
            candidates = sorted(
                attractions,
                key=lambda a: (
                    (self._haversine_km(prev_coord, a) if prev_coord is not None else 0.0)
                    + (self._haversine_km(a, next_coord) if next_coord is not None else 0.0)
                ),
            )[:swap_candidate_limit]

            old_activity = deepcopy(activity)
            old_start_time = str(activity.get("start_time", ""))
            old_end_time = str(activity.get("end_time", ""))
            visit_len = time_to_minutes(old_end_time) - time_to_minutes(old_start_time) if old_start_time and old_end_time else 60

            # Departure point and time for reaching the candidate.
            from_pos = prev_raw_pos or str(activity.get("position", ""))
            if prev_raw_pos and act_idx > 0:
                depart_time = str(activities[act_idx - 1].get("end_time", "08:00"))
            else:
                depart_time = old_start_time

            for cand in candidates:
                cand_name = self._norm_text(cand.get("name", ""))
                cand_actual_name = str(cand.get("name", ""))
                if not cand_name or cand_name == old_name or cand_name in used_names:
                    continue
                # Check open hours.
                cand_open, cand_close = self._poi_open_bounds(cand)
                # Build transport from prev to candidate.
                transports_in, arrival = self._get_transport(
                    self.env, city, from_pos, cand_actual_name, depart_time, people)
                if transports_in is None or arrival is None:
                    continue
                start_min = max(time_to_minutes(arrival), cand_open)
                end_min = start_min + visit_len
                if end_min > cand_close or end_min > 22 * 60:
                    continue
                # Check we can reach the next activity in time.
                transports_out = None
                if next_raw_pos and act_idx + 1 < len(activities):
                    next_start = str(activities[act_idx + 1].get("start_time", ""))
                    transports_out, next_arrival = self._get_transport(
                        self.env, city, cand_actual_name, next_raw_pos, minutes_to_time(end_min), people)
                    if transports_out is None or next_arrival is None:
                        continue
                    if next_start and time_to_minutes(next_arrival) > time_to_minutes(next_start):
                        continue

                # Build replacement activity.
                new_activity = self._make_attraction_activity(
                    cand, people, minutes_to_time(start_min), minutes_to_time(end_min), transports_in)

                # Check new transit is actually shorter.
                new_transit = self._inner_activity_minutes(new_activity)
                if new_transit >= transit_min:
                    continue

                # Try the swap.
                before_key = self._accepted_eval_key(plan)
                old_next_transports = None
                if transports_out is not None and act_idx + 1 < len(activities):
                    old_next_transports = deepcopy(activities[act_idx + 1].get("transports", []))
                    activities[act_idx + 1]["transports"] = transports_out
                activities[act_idx] = new_activity
                try:
                    if self._accepted(*check(plan)) and self._accepted_eval_key(plan) >= before_key:
                        used_names.discard(old_name)
                        used_names.add(cand_name)
                        swaps_done += 1
                        break
                except Exception:
                    pass
                # Revert.
                activities[act_idx] = old_activity
                if old_next_transports is not None:
                    activities[act_idx + 1]["transports"] = old_next_transports

        return plan

    def _rebuild_hop(self, city, from_pos, to_pos, start_time, people, mode):
        """Build one inner-city hop in `mode`, mirroring _get_transport's segment dicts.
        Returns (transports_list, duration_min) or (None, None)."""
        try:
            result = self.env.transportation.goto(city, from_pos, to_pos, start_time, mode)
        except Exception:
            return None, None
        if not isinstance(result, list) or len(result) == 0:
            return None, None
        transports = []
        for seg in result:
            t = {
                "start": seg["start"],
                "end": seg["end"],
                "mode": seg["mode"],
                "start_time": seg["start_time"],
                "end_time": seg["end_time"],
                "distance": seg["distance"],
            }
            if seg["mode"] == "taxi":
                cars = max(1, int(math.ceil(float(people) / 4.0)))
                t["price"] = seg["cost"]
                t["cost"] = seg["cost"] * cars
                t["cars"] = cars
            elif seg["mode"] == "metro":
                t["price"] = seg["cost"]
                t["cost"] = seg["cost"] * people
                t["tickets"] = people
            else:
                t["price"] = 0
                t["cost"] = 0
            transports.append(t)
        try:
            dur = time_to_minutes(str(transports[-1]["end_time"])) - time_to_minutes(str(transports[0]["start_time"]))
        except Exception:
            return None, None
        if dur < 0:
            return None, None
        return transports, dur

    def _upgrade_transport_modes(self, plan, query, constraints, check):
        """Acceptance-gated ATT optimizer: swap each inner-city hop to a faster mode, keeping
        the leg's start_time fixed so arrivals only move earlier (no downstream cascade). Each
        hop carries a candidate list (faster modes, fastest first), so a budget-tight query that
        rejects taxi can still fall back to metro. Lowers innercity_transport_time -> lifts ATT
        and never changes attraction/meal counts, so DAV/DDR/FPR/C-LPR cannot regress."""
        try:
            if not self._accepted(*check(plan)):
                return plan
        except Exception:
            return plan
        city = query.get("target_city", "")
        people = int(query.get("people_number", 1) or 1)

        def _legs_minutes(legs):
            tot = 0
            for leg in legs or []:
                try:
                    tot += time_to_minutes(str(leg["end_time"])) - time_to_minutes(str(leg["start_time"]))
                except Exception:
                    pass
            return tot

        hops = []  # (day_idx, act_idx, old_min, [candidate_transports, fastest first])
        for day_idx, day in enumerate(plan.get("itinerary", []) or []):
            activities = day.get("activities", []) or []
            for act_idx, activity in enumerate(activities):
                transports = activity.get("transports", []) or []
                if not transports:
                    continue
                modes_present = {self._norm_text(t.get("mode", "")) for t in transports}
                if not modes_present or (modes_present - {"walk", "metro", "taxi"}):
                    continue
                old_min = self._inner_activity_minutes(activity)
                from_pos = str(transports[0].get("start", "") or "")
                to_pos = str(transports[-1].get("end", "") or "")
                start_time = str(transports[0].get("start_time", "") or "")
                cur_start = str(activity.get("start_time", "") or "")
                if not from_pos or not to_pos or not start_time or from_pos == to_pos:
                    continue
                cands = []
                for mode in ("taxi", "metro"):
                    cand, dur = self._rebuild_hop(city, from_pos, to_pos, start_time, people, mode)
                    if cand is None or dur >= old_min:
                        continue
                    try:
                        if cur_start and time_to_minutes(str(cand[-1]["end_time"])) > time_to_minutes(cur_start):
                            continue
                    except Exception:
                        continue
                    cands.append((dur, cand))
                if cands:
                    cands.sort(key=lambda c: c[0])
                    hops.append((day_idx, act_idx, old_min, [c[1] for c in cands]))
        if not hops:
            return plan

        originals = [
            deepcopy(plan["itinerary"][d]["activities"][a]["transports"])
            for d, a, _o, _cl in hops
        ]
        # Fast path: apply each hop's fastest candidate, check once.
        for d, a, _o, cl in hops:
            plan["itinerary"][d]["activities"][a]["transports"] = cl[0]
        try:
            if self._accepted(*check(plan)):
                return plan
        except Exception:
            pass
        # Fallback: revert, then greedily upgrade by potential saving; per hop try fastest->slowest.
        for (d, a, _o, _cl), orig in zip(hops, originals):
            plan["itinerary"][d]["activities"][a]["transports"] = orig
        order = sorted(
            range(len(hops)),
            key=lambda i: hops[i][2] - _legs_minutes(hops[i][3][0]),
            reverse=True,
        )
        for i in order:
            d, a, _old_min, cl = hops[i]
            orig = plan["itinerary"][d]["activities"][a]["transports"]
            for cand in cl:
                plan["itinerary"][d]["activities"][a]["transports"] = cand
                try:
                    if self._accepted(*check(plan)):
                        break
                except Exception:
                    pass
                plan["itinerary"][d]["activities"][a]["transports"] = orig
        return plan

    def _room_type_to_numbed(self, room_type):
        if room_type is None:
            return None
        if isinstance(room_type, (int, float)):
            try:
                iv = int(room_type)
                if iv in [1, 2]:
                    return iv
            except Exception:
                return None
        t = self._norm_text(room_type)
        if any(k in t for k in ["single", "1", "one"]):
            return 1
        if any(k in t for k in ["double", "twin", "2", "two"]):
            return 2
        return None

    def _safe_float(self, value, default=0.0):
        try:
            return float(value)
        except Exception:
            return default

    def _extract_budget_limits(self, constraints):
        budgets = constraints.get("budgets", {}) or {}
        if not isinstance(budgets, dict):
            budgets = {}
        limits = {
            "sightseeing": -1.0,
            "dining": -1.0,
            "accommodation": -1.0,
            "intercity_transport": -1.0,
            "inner_transport": -1.0,
            "total": -1.0,
        }
        for k in limits.keys():
            if k in budgets:
                raw_val = budgets.get(k)
                if raw_val is None:
                    continue
                try:
                    v = float(raw_val)
                except Exception:
                    continue
                if v >= 0:
                    limits[k] = v
        return limits

    def _new_budget_tracker(self):
        return {
            "sightseeing": 0.0,
            "dining": 0.0,
            "accommodation": 0.0,
            "intercity_transport": 0.0,
            "inner_transport": 0.0,
            "total": 0.0,
        }

    def _transport_cost_total(self, transports):
        total = 0.0
        for t in transports or []:
            total += self._safe_float(t.get("cost", 0.0), 0.0)
        return total

    def _activity_bucket_costs(self, activity):
        bucket_costs = {
            "sightseeing": 0.0,
            "dining": 0.0,
            "accommodation": 0.0,
            "intercity_transport": 0.0,
            "inner_transport": self._transport_cost_total(activity.get("transports", [])),
            "total": 0.0,
        }
        atype = activity.get("type", "")
        main_cost = self._safe_float(activity.get("cost", 0.0), 0.0)

        if atype == "attraction":
            bucket_costs["sightseeing"] += main_cost
        elif atype in ["breakfast", "lunch", "dinner"]:
            bucket_costs["dining"] += main_cost
        elif atype == "accommodation":
            bucket_costs["accommodation"] += main_cost
        elif atype in ["airplane", "train"]:
            bucket_costs["intercity_transport"] += main_cost

        for k in ["sightseeing", "dining", "accommodation", "intercity_transport", "inner_transport"]:
            bucket_costs["total"] += bucket_costs[k]
        return bucket_costs

    def _can_add_activity_under_budget(self, activity, budget_limits, budget_tracker):
        if not budget_limits:
            return True
        inc = self._activity_bucket_costs(activity)
        for k, limit in budget_limits.items():
            if limit < 0:
                continue
            projected = self._safe_float(budget_tracker.get(k, 0.0), 0.0) + self._safe_float(inc.get(k, 0.0), 0.0)
            if projected > limit + 1e-6:
                return False
        return True

    def _register_activity_cost(self, activity, budget_tracker):
        inc = self._activity_bucket_costs(activity)
        for k in budget_tracker.keys():
            budget_tracker[k] = self._safe_float(budget_tracker.get(k, 0.0), 0.0) + self._safe_float(inc.get(k, 0.0), 0.0)

    def _append_activity(self, activities, activity, budget_limits, budget_tracker, force=False):
        if force or self._can_add_activity_under_budget(activity, budget_limits, budget_tracker):
            activities.append(activity)
            self._register_activity_cost(activity, budget_tracker)
            return True
        return False

    def _append_preregistered_activity(self, activities, activity):
        """Append an activity whose cost was already pre-registered in the budget_tracker."""
        activities.append(activity)
        return True

    def _timing_constraint_minutes(self, timing_constraints, locations, constraint_type, take_max):
        if not timing_constraints or not locations:
            return None
        values = []
        for constraint in timing_constraints:
            if not isinstance(constraint, dict) or constraint.get("type") != constraint_type:
                continue
            constraint_location = str(constraint.get("location", "")).strip()
            constraint_time = constraint.get("time", None)
            if not constraint_location or not constraint_time:
                continue
            for location in locations:
                location = str(location).strip()
                if not location:
                    continue
                if self._match_constraint_text(location, constraint_location) or self._match_constraint_text(
                    constraint_location, location
                ):
                    values.append(time_to_minutes(str(constraint_time)))
                    break
        if not values:
            return None
        return max(values) if take_max else min(values)

    def _timing_departure_floor(self, timing_constraints, locations):
        return self._timing_constraint_minutes(timing_constraints, locations, "depart_no_earlier", True)

    def _timing_arrival_ceiling(self, timing_constraints, locations):
        return self._timing_constraint_minutes(timing_constraints, locations, "arrive_no_later", False)

    def _activity_timing_allowed(self, location, start_time, timing_constraints, extra_locations=None):
        locations = [location]
        if extra_locations:
            locations.extend(extra_locations)
        ceiling = self._timing_arrival_ceiling(timing_constraints, locations)
        if ceiling is not None and time_to_minutes(start_time) > ceiling:
            return False
        return True

    def _route_timing_allowed(self, timing_constraints, from_locations, to_locations, begin_time, end_time):
        depart_floor = self._timing_departure_floor(timing_constraints, from_locations)
        if depart_floor is not None and time_to_minutes(begin_time) < depart_floor:
            return False
        arrival_ceiling = self._timing_arrival_ceiling(timing_constraints, to_locations)
        if arrival_ceiling is not None and time_to_minutes(end_time) > arrival_ceiling:
            return False
        return True

    def _affordable_main_cost(self, bucket, cost_value, budget_limits, budget_tracker):
        if not budget_limits:
            return True
        c = self._safe_float(cost_value, 0.0)
        bucket_limit = budget_limits.get(bucket)
        if bucket_limit is not None and bucket_limit >= 0 and self._safe_float(budget_tracker.get(bucket, 0.0), 0.0) + c > bucket_limit + 1e-6:
            return False
        total_limit = budget_limits.get("total")
        if total_limit is not None and total_limit >= 0 and self._safe_float(budget_tracker.get("total", 0.0), 0.0) + c > total_limit + 1e-6:
            return False
        return True

    def _pick_restaurant(self, restaurants, start_idx, people, budget_limits, budget_tracker):
        idx = start_idx
        fallback = None
        while idx < len(restaurants):
            r = restaurants[idx]
            full_cost = self._safe_float(r.get("price", 0.0), 0.0) * people
            if self._affordable_main_cost("dining", full_cost, budget_limits, budget_tracker):
                return r, idx + 1
            if fallback is None:
                fallback = (r, idx + 1)
            idx += 1
        return fallback if fallback is not None else (None, start_idx)

    def _is_required_attraction(self, attr, required_attractions, required_attraction_types):
        if attr is None:
            return False
        name = str(attr.get("name", ""))
        attr_type = str(attr.get("type", ""))
        by_name = bool(required_attractions) and any(
            self._match_constraint_text(name, req)
            for req in required_attractions
        )
        by_type = bool(required_attraction_types) and any(
            self._match_type(attr_type, req_t)
            for req_t in required_attraction_types
        )
        return by_name or by_type

    def _is_required_restaurant(self, restaurant, required_restaurants):
        if restaurant is None:
            return False
        if not required_restaurants:
            return False
        name = str(restaurant.get("name", ""))
        return any(self._match_constraint_text(name, req) for req in required_restaurants)

    def run(self, query, prob_idx=None, oralce_translation=False):
        self.reset_clock()
        self.reset_timeout_recovery_plan()

        try:
            plan = self._solve(query)
        except Exception:
            import traceback
            traceback.print_exc()
            plan = {
                "people_number": query.get("people_number", 1),
                "start_city": query.get("start_city", ""),
                "target_city": query.get("target_city", ""),
                "itinerary": [],
            }
            self._set_timeout_recovery_plan(plan)

        plan["elapsed_time(sec)"] = time.time() - self.start_clock
        return True, plan

    def _build_plan(self, query, constraints=None, params=None):
        """Build a valid itinerary with proper transport, timing, and costs.

        `params` carries per-restart search knobs (visit_minutes, attr_per_day, attr_offset,
        rest_offset, hotel_index, forced_inner_mode, intercity_go_pref/back_pref); every
        default reproduces the original greedy behaviour.
        """
        params = params or {}
        people = query["people_number"]
        start_city = query["start_city"]
        target_city = query["target_city"]
        days = query["days"]
        if constraints is None:
            constraints = self._collect_constraints(query)
        constraints = self._apply_search_constraints(constraints, params)
        self._forced_inner_mode = params.get("forced_inner_mode")
        timing_constraints = constraints.get("timing_constraints", []) or []
        self._active_timing_constraints = timing_constraints
        budget_limits = self._extract_budget_limits(constraints)
        budget_tracker = self._new_budget_tracker()
        self._budget_limits = budget_limits
        self._budget_tracker = budget_tracker
        self._transport_constraints = {
            "excluded_inner_transport": constraints.get("excluded_inner_transport", []),
            "conditional_transport": constraints.get("conditional_transport", None),
            "taxi_cars_equals": constraints.get("taxi_cars_equals", None),
        }

        env = self.env
        if env is None:
            return {
                "people_number": people,
                "start_city": start_city,
                "target_city": target_city,
                "itinerary": [],
            }

        # --- Get intercity transport (outbound + return) ---
        intercity_mode = constraints.get("intercity_mode", None)
        outbound_pref = None
        return_pref = None
        if isinstance(intercity_mode, dict):
            outbound_pref = intercity_mode.get("outbound", None)
            return_pref = intercity_mode.get("return", None)
        elif isinstance(intercity_mode, str):
            outbound_pref = intercity_mode
            return_pref = intercity_mode
        # Search may override the intercity mode preference per direction.
        if "intercity_go_pref" in params:
            outbound_pref = params["intercity_go_pref"]
        if "intercity_back_pref" in params:
            return_pref = params["intercity_back_pref"]

        _ic_late = os.environ.get("TPC_INTERCITY_LATE_RETURN", "0") == "1"
        _ic_early = os.environ.get("TPC_INTERCITY_EARLY_ARRIVAL", "0") == "1"
        outbound = self._get_intercity(
            env, start_city, target_city, "00:00" if _ic_early else "07:00", outbound_pref,
            budget_limits, budget_tracker, people=people,
            window="early_arrival" if _ic_early else None)
        if _ic_late:
            # Latest affordable departure maximizes the last-day in-city window so the
            # densify pass can place breakfast/lunch/dinner and a 4th attraction.
            return_transport = self._get_intercity(
                env, target_city, start_city, "00:00", return_pref, budget_limits,
                budget_tracker, pending_intercity=outbound, people=people, window="late")
        else:
            return_transport = self._get_intercity(env, target_city, start_city, "17:00", return_pref, budget_limits, budget_tracker, pending_intercity=outbound, people=people)
        # If no return at 17:00, try earlier
        if return_transport is None:
            return_transport = self._get_intercity(env, target_city, start_city, "14:00", return_pref, budget_limits, budget_tracker, pending_intercity=outbound, people=people)
        if return_transport is None:
            return_transport = self._get_intercity(env, target_city, start_city, "00:00", return_pref, budget_limits, budget_tracker, pending_intercity=outbound, people=people)

        # Pre-register intercity costs so hotel/meal selections see the correct remaining budget
        _out_cost = self._safe_float(outbound.get("Cost", 0.0), 0.0) * people if outbound else 0.0
        _ret_cost = self._safe_float(return_transport.get("Cost", 0.0), 0.0) * people if return_transport else 0.0
        budget_tracker["intercity_transport"] = budget_tracker.get("intercity_transport", 0.0) + _out_cost + _ret_cost
        budget_tracker["total"] = budget_tracker.get("total", 0.0) + _out_cost + _ret_cost

        # --- Get one accommodation near the arrival/departure point ---
        arrival_pos = outbound["To"] if outbound else None
        required_hotels = constraints.get("required_hotels", []) or []
        excluded_hotels = constraints.get("excluded_hotels", []) or []
        room_numbed = self._room_type_to_numbed(constraints.get("room_type", None))
        hotel_type = constraints.get("hotel_type", None)
        hotel_amenity = constraints.get("hotel_amenity", None)
        required_hotel_all_types = constraints.get("required_hotel_all_types", []) or []
        required_hotel_any_types = constraints.get("required_hotel_any_types", []) or []
        hotel_nearby = constraints.get("hotel_nearby", None)

        accom_df = env.accommodations.select(target_city, "name", lambda x: True)
        required_hotels = self._resolve_required_names(required_hotels, [str(accom_df.iloc[i]["name"]) for i in range(len(accom_df))])

        def _hotel_ok(h):
            name = str(h["name"])
            feature_type = str(h.get("featurehoteltype", ""))
            if required_hotels and not any(self._match_constraint_text(name, n) for n in required_hotels):
                return False
            if excluded_hotels and any(self._match_constraint_text(name, n) for n in excluded_hotels):
                return False
            if room_numbed is not None:
                try:
                    if int(h["numbed"]) != room_numbed:
                        return False
                except Exception:
                    return False
            if hotel_type:
                if not self._match_constraint_text(feature_type, hotel_type):
                    return False
            if hotel_amenity:
                if not self._match_constraint_text(feature_type, hotel_amenity):
                    return False
            if required_hotel_all_types and any(not self._match_constraint_text(feature_type, t) for t in required_hotel_all_types):
                return False
            if required_hotel_any_types and not any(self._match_constraint_text(feature_type, t) for t in required_hotel_any_types):
                return False
            try:
                rooms_local = math.ceil(people / int(h.get("numbed", 1)))
            except Exception:
                rooms_local = people
            h_cost = self._safe_float(h.get("price", 0.0), 0.0) * rooms_local * max(days - 1, 0)
            if not self._affordable_main_cost("accommodation", h_cost, budget_limits, budget_tracker):
                return False
            return True

        hotel_index = max(0, int(params.get("hotel_index", 0)))

        def _pick_ok(df):
            ok_list = [df.iloc[i] for i in range(len(df)) if _hotel_ok(df.iloc[i])]
            if not ok_list:
                return None
            return ok_list[min(hotel_index, len(ok_list) - 1)]

        hotel = None
        nearby_df = None
        hotel_from_nearby_constraint = False
        if isinstance(hotel_nearby, dict):
            ref = hotel_nearby.get("reference", None)
            dist_km = hotel_nearby.get("distance_km", 5)
            if ref:
                try:
                    nearby_df = env.accommodations.nearby(target_city, ref, topk=20, dist=dist_km)
                except Exception:
                    nearby_df = None

        if nearby_df is not None and not isinstance(nearby_df, str) and len(nearby_df) > 0:
            hotel = _pick_ok(nearby_df)
            if hotel is not None:
                hotel_from_nearby_constraint = True

        if hotel is None and arrival_pos and not hotel_from_nearby_constraint:
            try:
                nearby_hotels = env.accommodations.nearby(target_city, arrival_pos, topk=5, dist=20)
                if not isinstance(nearby_hotels, str) and len(nearby_hotels) > 0:
                    hotel = _pick_ok(nearby_hotels)
            except Exception:
                pass
        if hotel is None:
            hotel = _pick_ok(accom_df)
        if hotel is None:
            # Fall back to cheapest option even when strict filters are infeasible.
            best = None
            best_price = None
            best_affordable = False
            for i in range(len(accom_df)):
                h = accom_df.iloc[i]
                p = self._safe_float(h.get("price", 0.0), 0.0)
                try:
                    rooms_local = math.ceil(people / int(h.get("numbed", 1)))
                except Exception:
                    rooms_local = people
                h_cost = p * rooms_local * max(days - 1, 0)
                affordable = self._affordable_main_cost("accommodation", h_cost, budget_limits, budget_tracker)
                should_take = False
                if best is None or best_price is None:
                    should_take = True
                elif affordable and not best_affordable:
                    should_take = True
                elif affordable == best_affordable and p < best_price:
                    should_take = True
                if should_take:
                    best = h
                    best_price = p
                    best_affordable = affordable
            hotel = best if best is not None else accom_df.iloc[0]
        hotel_name = str(hotel["name"])
        rooms_needed = math.ceil(people / int(hotel["numbed"]))

        # Pre-register hotel accommodation costs so that subsequent meal/attraction budget checks
        # see the correct remaining budget (hotel is force-appended later without re-registering)
        _hotel_price = self._safe_float(hotel.get("price", 0.0), 0.0)
        _hotel_total = _hotel_price * rooms_needed * max(days - 1, 0)
        budget_tracker["accommodation"] = budget_tracker.get("accommodation", 0.0) + _hotel_total
        budget_tracker["total"] = budget_tracker.get("total", 0.0) + _hotel_total

        # --- Get attractions that are open during reasonable visit hours ---
        required_attractions = constraints.get("required_attractions", []) or []
        required_attraction_types = constraints.get("required_attraction_types", []) or []
        excluded_attractions = constraints.get("excluded_attractions", []) or []
        excluded_attraction_types = constraints.get("excluded_attraction_types", []) or []
        free_attractions_only = bool(constraints.get("free_attractions_only", False))

        attr_df = env.attractions.select(target_city, "name", lambda x: True)
        required_attractions = self._resolve_required_names(required_attractions, [str(attr_df.iloc[i]["name"]) for i in range(len(attr_df))])

        # Augment required_attractions with named locations from timing constraints that exist in the attraction DB
        _attr_names_list = [str(attr_df.iloc[i]["name"]) for i in range(len(attr_df))]
        _timing_locs_for_restaurants = []  # locations not found in attractions, will check restaurants later
        for _tc in timing_constraints:
            _loc = str(_tc.get("location", "")).strip()
            if not _loc or _loc in {start_city, target_city}:
                continue
            _matches = [n for n in _attr_names_list if self._match_constraint_text(n, _loc) or self._match_constraint_text(_loc, n)]
            if _matches:
                _canon = _matches[0]
                if not any(self._match_constraint_text(_canon, ex) for ex in required_attractions):
                    required_attractions.append(_canon)
            else:
                _timing_locs_for_restaurants.append(_loc)

        prioritized_required = []
        optional_pool = []
        seen_attr = set()
        for i in range(len(attr_df)):
            a = attr_df.iloc[i]
            name = str(a["name"])
            attr_type = str(a.get("type", ""))

            if excluded_attractions and any(self._match_constraint_text(name, ex) for ex in excluded_attractions):
                continue
            if excluded_attraction_types and any(self._match_constraint_text(attr_type, ex) for ex in excluded_attraction_types):
                continue
            if free_attractions_only:
                try:
                    if float(a["price"]) > 0:
                        continue
                except Exception:
                    continue

            required_by_name = required_attractions and any(
                self._match_constraint_text(name, req)
                for req in required_attractions
            )
            required_by_type = required_attraction_types and any(
                self._match_type(attr_type, req_t)
                for req_t in required_attraction_types
            )

            name_key = self._norm_text(name)
            if required_by_name or required_by_type:
                if name_key not in seen_attr:
                    prioritized_required.append(a)
                    seen_attr.add(name_key)
            else:
                if name_key not in seen_attr:
                    optional_pool.append(a)
                    seen_attr.add(name_key)

        candidate_attrs = prioritized_required + optional_pool

        # Sort optional attractions by price to improve budget feasibility while keeping required first.
        if len(prioritized_required) < len(candidate_attrs):
            sorted_optional = sorted(
                optional_pool,
                key=lambda x: self._safe_float(x.get("price", 0.0), 0.0),
            )
            candidate_attrs = prioritized_required + sorted_optional

        # Filter to attractions open during daytime visit windows (09:00-17:00)
        # Required attractions always bypass the opentime filter.
        required_set = set(self._norm_text(str(a["name"])) for a in prioritized_required)
        good_attrs = []
        for a in candidate_attrs:
            name_key = self._norm_text(str(a["name"]))
            is_required = name_key in required_set
            opentime = str(a["opentime"])
            endtime = str(a["endtime"])
            ot_min = time_to_minutes(opentime)
            et_min = time_to_minutes(endtime)
            # Handle wrap-around (e.g., 00:00-24:00 = always open)
            if et_min <= ot_min:
                et_min += 24 * 60
            # Must be open by 09:30 and stay open until at least 12:00
            # so we can fit a 90-min visit in the morning or afternoon
            passes_filter = ot_min <= 570 and et_min >= 720  # 09:30=570, 12:00=720
            if is_required or passes_filter:
                good_attrs.append(a)
            if len(good_attrs) >= days * 4 + len(required_set):
                break
        # Fallback: just take the first ones
        if len(good_attrs) < days * 2:
            base_pool = candidate_attrs if len(candidate_attrs) > 0 else [attr_df.iloc[i] for i in range(len(attr_df))]
            good_attrs = list(base_pool[: min(len(base_pool), days * 4)])

        # --- Get restaurants open during meal times ---
        required_restaurants = constraints.get("required_restaurants", []) or []
        excluded_restaurants = constraints.get("excluded_restaurants", []) or []
        cuisine_preference = constraints.get("cuisine_preference", None)
        excluded_cuisine_types = constraints.get("excluded_cuisine_types", []) or []

        rest_df = env.restaurants.select(target_city, "name", lambda x: True)
        required_restaurants = self._resolve_required_names(required_restaurants, [str(rest_df.iloc[i]["name"]) for i in range(len(rest_df))])

        # Augment required_restaurants with timing constraint locations found in the restaurant DB
        _rest_names_list = [str(rest_df.iloc[i]["name"]) for i in range(len(rest_df))]
        for _loc in _timing_locs_for_restaurants:
            _matches = [n for n in _rest_names_list if self._match_constraint_text(n, _loc) or self._match_constraint_text(_loc, n)]
            if _matches:
                _canon = _matches[0]
                if not any(self._match_constraint_text(_canon, ex) for ex in required_restaurants):
                    required_restaurants.append(_canon)
        lunch_restaurants = []
        dinner_restaurants = []
        required_rest_pool = []
        optional_rest_pool = []
        seen_rest = set()
        for i in range(len(rest_df)):
            r = rest_df.iloc[i]
            name = str(r["name"])
            cuisine = str(r.get("cuisine", ""))

            if excluded_restaurants and any(self._match_constraint_text(name, ex) for ex in excluded_restaurants):
                continue
            if excluded_cuisine_types and any(self._match_constraint_text(cuisine, ex) for ex in excluded_cuisine_types):
                continue

            is_required = required_restaurants and any(
                self._match_constraint_text(name, req)
                for req in required_restaurants
            )
            cuisine_match = cuisine_preference and self._match_constraint_text(cuisine, cuisine_preference)

            key = self._norm_text(name)
            if key in seen_rest:
                continue
            seen_rest.add(key)
            if is_required or cuisine_match:
                required_rest_pool.append(r)
            else:
                optional_rest_pool.append(r)

        candidate_restaurants = required_rest_pool + optional_rest_pool

        used_rest_names = set()
        for r in candidate_restaurants:
            name = str(r["name"])
            opentime = str(r["opentime"])
            endtime = str(r["endtime"])
            ot_min = time_to_minutes(opentime)
            # Handle wrap-around (endtime < opentime means open past midnight)
            if endtime < opentime:
                et_min = time_to_minutes(endtime) + 24 * 60
            else:
                et_min = time_to_minutes(endtime)
            # Check if open for lunch (11:00-14:00)
            if name not in used_rest_names and ot_min <= 660 and et_min >= 840:  # 11:00=660, 14:00=840
                lunch_restaurants.append(r)
                used_rest_names.add(name)
            # Check if open for dinner (17:00-20:00)
            elif name not in used_rest_names and ot_min <= 1020 and et_min >= 1200:  # 17:00=1020, 20:00=1200
                dinner_restaurants.append(r)
                used_rest_names.add(name)
            if len(lunch_restaurants) >= days and len(dinner_restaurants) >= days:
                break

        # Search-controlled rotation of the OPTIONAL tail (required/prioritized stay pinned at front),
        # so distinct restarts try different optional POIs/restaurants without dropping a requirement.
        attr_offset = int(params.get("attr_offset", 0))
        if attr_offset:
            good_attrs = self._rotate_tail(
                good_attrs, lambda a: self._norm_text(str(a["name"])) in required_set, attr_offset)
        rest_offset = int(params.get("rest_offset", 0))
        if rest_offset:
            lunch_restaurants = self._rotate_tail(
                lunch_restaurants, lambda r: self._is_required_restaurant(r, required_restaurants), rest_offset)
            dinner_restaurants = self._rotate_tail(
                dinner_restaurants, lambda r: self._is_required_restaurant(r, required_restaurants), rest_offset)

        # --- Build day-by-day itinerary ---
        itinerary = []
        attr_idx = 0
        lunch_idx = 0
        dinner_idx = 0
        current_pos = None  # Track current position for transport
        # Required attractions that haven't been scheduled yet — tried first at each slot
        self._required_attrs_remaining = list(prioritized_required)
        self._required_attr_types_remaining = [
            str(t).strip() for t in (required_attraction_types or []) if str(t).strip()
        ]
        self._scheduled_attr_names = set()

        early_arrival_floor = self._timing_arrival_ceiling(
            timing_constraints,
            list(required_attractions) + list(constraints.get("position_presence", []) or []),
        )
        if early_arrival_floor is not None and early_arrival_floor <= (8 * 60 + 30):
            breakfast_start_time, breakfast_end_time = "06:00", "06:20"
        else:
            breakfast_start_time, breakfast_end_time = "07:30", "08:30"

        for day_num in range(1, days + 1):
            activities = []
            # Per-day extra-attraction budget shared across the morning/afternoon/evening fills.
            # max(0, attr_per_day-2) is 0 at the base attr_per_day=2, so the accepted-plan search
            # is byte-identical to pre-refactor; enrichment only engages for attr_per_day>=3.
            extra_budget = max(0, int(params.get("attr_per_day", 2)) - 2)
            extra_used = 0

            if day_num == 1:
                # === DAY 1: Arrive + activities + hotel ===
                if outbound is not None:
                    act = self._make_intercity_activity(outbound, people)
                    self._append_preregistered_activity(activities, act)
                    current_time = outbound["EndTime"]
                    current_pos = outbound["To"]
                else:
                    current_time = "09:00"
                    current_pos = hotel_name

                # Lunch (if time allows, start between 11:00-13:00)
                if time_before(current_time, "13:00") and lunch_idx < len(lunch_restaurants):
                    restaurant, new_lunch_idx = self._pick_restaurant(
                        lunch_restaurants,
                        lunch_idx,
                        people,
                        budget_limits,
                        budget_tracker,
                    )
                    if restaurant is not None:
                        lunch_idx = new_lunch_idx
                    lunch_start = max(current_time, "11:00")
                    # Add transport to restaurant
                    rest_name = str(restaurant["name"]) if restaurant is not None else current_pos
                    transports, travel_end = self._get_transport(
                        env, target_city, current_pos, rest_name, current_time, people)
                    if transports is not None:
                        lunch_start = max(travel_end or current_time, "11:00")
                    else:
                        transports = []
                    lunch_end = add_minutes(lunch_start, 60)
                    if restaurant is not None and time_before(lunch_end, "14:00") and self._activity_timing_allowed(
                        rest_name,
                        lunch_start,
                        timing_constraints,
                        [current_pos],
                    ):
                        meal = self._make_meal_activity(
                            "lunch", restaurant, people, lunch_start, lunch_end, transports)
                        is_req_rest = self._is_required_restaurant(restaurant, required_restaurants)
                        added = self._append_activity(
                            activities,
                            meal,
                            budget_limits,
                            budget_tracker,
                            force=is_req_rest,
                        )
                        if added:
                            current_time = lunch_end
                            current_pos = rest_name

                # Afternoon attraction
                if time_before(current_time, "16:30") and attr_idx < len(good_attrs):
                    # Estimate visit time and check open hours
                    est_start = add_minutes(current_time, 20)  # ~20 min travel
                    est_end = add_minutes(est_start, self._slot_visit_len(params, constraints))
                    attr, attr_idx = self._pick_attraction(good_attrs, attr_idx, est_start, est_end)
                    if attr is not None:
                        attr_name = str(attr["name"])
                        transports, travel_end = self._get_transport(
                            env, target_city, current_pos, attr_name, current_time, people)
                        if transports is not None:
                            attr_start = travel_end
                        else:
                            transports = []
                            attr_start = current_time
                        attr_end = add_minutes(attr_start, self._visit_len(attr, params, constraints))
                        if is_open_during(attr, attr_start, attr_end) and self._activity_timing_allowed(
                            attr_name,
                            attr_start,
                            timing_constraints,
                            [current_pos],
                        ):
                            attr_act = self._make_attraction_activity(
                                attr, people, attr_start, attr_end, transports)
                            added = self._append_activity(
                                activities,
                                attr_act,
                                budget_limits,
                                budget_tracker,
                                force=self._is_required_attraction(
                                    attr,
                                    required_attractions,
                                    required_attraction_types,
                                ),
                            )
                            if added:
                                current_time = attr_end
                                current_pos = attr_name

                # Afternoon fill before dinner.
                attr_idx, current_time, current_pos, _added = self._fill_extra_attractions(
                    activities, env, target_city, good_attrs, attr_idx, current_pos, current_time,
                    people, params, constraints, budget_limits, budget_tracker, timing_constraints,
                    required_attractions, required_attraction_types,
                    extra_budget - extra_used, "16:30", latest_end="18:00")
                extra_used += _added

                # Dinner (start between 17:00-19:00)
                if time_before(current_time, "19:00") and dinner_idx < len(dinner_restaurants):
                    restaurant, new_dinner_idx = self._pick_restaurant(
                        dinner_restaurants,
                        dinner_idx,
                        people,
                        budget_limits,
                        budget_tracker,
                    )
                    if restaurant is not None:
                        dinner_idx = new_dinner_idx
                    rest_name = str(restaurant["name"]) if restaurant is not None else current_pos
                    transports, travel_end = self._get_transport(
                        env, target_city, current_pos, rest_name, current_time, people)
                    if transports is not None:
                        dinner_start = max(travel_end or current_time, "17:00")
                    else:
                        transports = []
                        dinner_start = max(current_time, "17:00")
                    dinner_end = add_minutes(dinner_start, 60)
                    if restaurant is not None and time_before(dinner_end, "20:00") and self._activity_timing_allowed(
                        rest_name,
                        dinner_start,
                        timing_constraints,
                        [current_pos],
                    ):
                        dinner = self._make_meal_activity(
                            "dinner", restaurant, people, dinner_start, dinner_end, transports)
                        added = self._append_activity(
                            activities,
                            dinner,
                            budget_limits,
                            budget_tracker,
                            force=self._is_required_restaurant(restaurant, required_restaurants),
                        )
                        if added:
                            current_time = dinner_end
                            current_pos = rest_name

                # Evening fill after dinner (only late-open attractions qualify).
                attr_idx, current_time, current_pos, _added = self._fill_extra_attractions(
                    activities, env, target_city, good_attrs, attr_idx, current_pos, current_time,
                    people, params, constraints, budget_limits, budget_tracker, timing_constraints,
                    required_attractions, required_attraction_types,
                    extra_budget - extra_used, "21:00")
                extra_used += _added

                # Accommodation
                transports, travel_end = self._get_transport(
                    env, target_city, current_pos, hotel_name, current_time, people)
                if transports is None or current_pos == hotel_name:
                    transports = []
                    travel_end = current_time
                stay = self._make_accommodation_activity(
                    hotel, rooms_needed, travel_end, transports)
                self._append_preregistered_activity(activities, stay)
                current_pos = hotel_name

            elif day_num == days:
                # === LAST DAY: breakfast + maybe attraction + return transport ===
                # First, figure out the return transport based on hotel position
                # Compute transport from hotel to departure point to know earliest feasible departure
                if return_transport is not None:
                    departure_pos = return_transport["From"]
                    hotel_to_station, hotel_to_station_end = self._get_transport(
                        env, target_city, hotel_name, departure_pos, "08:30", people)
                    if hotel_to_station is None:
                        hotel_to_station_end = "08:30"
                    # If we can't make it to the original return transport, find a later one
                    if time_to_minutes(hotel_to_station_end) > time_to_minutes(return_transport["BeginTime"]):
                        later = self._get_intercity(
                            env,
                            target_city,
                            start_city,
                            hotel_to_station_end,
                            return_pref,
                            budget_limits,
                            budget_tracker,
                            pending_intercity=outbound,
                            people=people,
                        )
                        if later is not None:
                            return_transport = later
                            departure_pos = later["From"]
                            # Re-compute transport if departure pos changed
                            if later["From"] != (hotel_to_station[-1]["end"] if hotel_to_station else hotel_name):
                                hotel_to_station, hotel_to_station_end = self._get_transport(
                                    env, target_city, hotel_name, departure_pos, "08:30", people)
                                if hotel_to_station is None:
                                    hotel_to_station_end = "08:30"

                # Breakfast at hotel (free)
                breakfast = self._make_hotel_breakfast(
                    hotel_name, breakfast_start_time, breakfast_end_time)
                self._append_activity(activities, breakfast, budget_limits, budget_tracker)
                current_time = breakfast_end_time
                current_pos = hotel_name

                # Morning attraction if time before return
                if attr_idx < len(good_attrs) and return_transport is not None:
                    departure_time = return_transport["BeginTime"]
                    departure_pos = return_transport["From"]
                    # Need time: transport to attr + 90min + transport to departure point
                    if time_to_minutes(departure_time) >= time_to_minutes(current_time) + 150:
                        est_start = add_minutes(current_time, 20)
                        est_end = add_minutes(est_start, self._slot_visit_len(params, constraints))
                        attr, attr_idx = self._pick_attraction(good_attrs, attr_idx, est_start, est_end)
                        if attr is not None:
                            attr_name = str(attr["name"])
                            transports, travel_end = self._get_transport(
                                env, target_city, current_pos, attr_name, current_time, people)
                            if transports is not None:
                                attr_start = travel_end
                            else:
                                transports = []
                                attr_start = current_time
                            attr_end = add_minutes(attr_start, self._visit_len(attr, params, constraints))
                            # Check we can get back to departure in time
                            _, return_arrival = self._get_transport(
                                env, target_city, attr_name, departure_pos, attr_end, people)
                            can_return = (return_arrival is not None and
                                         time_to_minutes(return_arrival) <= time_to_minutes(departure_time))
                            if can_return and is_open_during(attr, attr_start, attr_end) and self._activity_timing_allowed(
                                attr_name,
                                attr_start,
                                timing_constraints,
                                [current_pos],
                            ):
                                attr_act = self._make_attraction_activity(
                                    attr, people, attr_start, attr_end, transports)
                                added = self._append_activity(
                                    activities,
                                    attr_act,
                                    budget_limits,
                                    budget_tracker,
                                    force=self._is_required_attraction(
                                        attr,
                                        required_attractions,
                                        required_attraction_types,
                                    ),
                                )
                                if added:
                                    current_time = attr_end
                                    current_pos = attr_name

                # Morning fill before departure (return-guarded so we never miss the train/flight).
                if return_transport is not None:
                    _dep_t = return_transport["BeginTime"]
                    _dep_p = return_transport["From"]
                    def _return_ok(name, end, _p=_dep_p, _t=_dep_t):
                        _, _arr = self._get_transport(env, target_city, name, _p, end, people)
                        return _arr is not None and time_to_minutes(_arr) <= time_to_minutes(_t)
                    attr_idx, current_time, current_pos, _added = self._fill_extra_attractions(
                        activities, env, target_city, good_attrs, attr_idx, current_pos, current_time,
                        people, params, constraints, budget_limits, budget_tracker, timing_constraints,
                        required_attractions, required_attraction_types,
                        extra_budget - extra_used, "13:00", return_guard=_return_ok)
                    extra_used += _added

                # Lunch before departure if time allows
                if return_transport is not None and lunch_idx < len(lunch_restaurants):
                    departure_time = return_transport["BeginTime"]
                    departure_pos = return_transport["From"]
                    if time_to_minutes(departure_time) >= time_to_minutes("11:00") + 90:
                        if time_before(current_time, "13:00"):
                            restaurant, new_lunch_idx = self._pick_restaurant(
                                lunch_restaurants,
                                lunch_idx,
                                people,
                                budget_limits,
                                budget_tracker,
                            )
                            rest_name = str(restaurant["name"]) if restaurant is not None else current_pos
                            transports, travel_end = self._get_transport(
                                env, target_city, current_pos, rest_name, current_time, people)
                            if transports is not None:
                                lunch_start = max(travel_end or current_time, "11:00")
                            else:
                                transports = []
                                lunch_start = max(current_time, "11:00")
                            lunch_end = add_minutes(lunch_start, 60)
                            # Check we can still reach departure point after lunch
                            _, return_arrival = self._get_transport(
                                env, target_city, rest_name, departure_pos, lunch_end, people)
                            can_return = (return_arrival is not None and
                                         time_to_minutes(return_arrival) <= time_to_minutes(departure_time))
                            if restaurant is not None and time_before(lunch_end, "14:00") and can_return and self._activity_timing_allowed(
                                rest_name,
                                lunch_start,
                                timing_constraints,
                                [current_pos],
                            ):
                                lunch_idx = new_lunch_idx
                                lunch = self._make_meal_activity(
                                    "lunch", restaurant, people, lunch_start, lunch_end, transports)
                                added = self._append_activity(
                                    activities,
                                    lunch,
                                    budget_limits,
                                    budget_tracker,
                                    force=self._is_required_restaurant(restaurant, required_restaurants),
                                )
                                if added:
                                    current_time = lunch_end
                                    current_pos = rest_name

                # Return intercity transport
                if return_transport is not None:
                    departure_pos = return_transport["From"]
                    transports, travel_end = self._get_transport(
                        env, target_city, current_pos, departure_pos, current_time, people)
                    if transports is None or current_pos == departure_pos:
                        transports = []
                        travel_end = current_time
                    # If transport to station arrives after departure, find later transport
                    if time_to_minutes(travel_end) > time_to_minutes(return_transport["BeginTime"]):
                        later = self._get_intercity(
                            env,
                            target_city,
                            start_city,
                            travel_end,
                            return_pref,
                            budget_limits,
                            budget_tracker,
                            pending_intercity=outbound,
                            people=people,
                        )
                        if later is not None:
                            return_transport = later
                            if later["From"] != departure_pos:
                                departure_pos = later["From"]
                                transports, travel_end = self._get_transport(
                                    env, target_city, current_pos, departure_pos, current_time, people)
                                if transports is None or current_pos == departure_pos:
                                    transports = []
                    act = self._make_intercity_activity(return_transport, people, transports)
                    self._append_preregistered_activity(activities, act)

            else:
                # === MIDDLE DAYS: breakfast + attractions + meals + hotel ===
                # Breakfast at hotel (free)
                breakfast = self._make_hotel_breakfast(
                    hotel_name, breakfast_start_time, breakfast_end_time)
                self._append_activity(activities, breakfast, budget_limits, budget_tracker)
                current_time = breakfast_end_time
                current_pos = hotel_name

                # Morning attraction
                if attr_idx < len(good_attrs):
                    est_start = add_minutes(current_time, 20)
                    est_end = add_minutes(est_start, self._slot_visit_len(params, constraints))
                    attr, attr_idx = self._pick_attraction(good_attrs, attr_idx, est_start, est_end)
                    if attr is not None:
                        attr_name = str(attr["name"])
                        transports, travel_end = self._get_transport(
                            env, target_city, current_pos, attr_name, current_time, people)
                        if transports is not None:
                            attr_start = travel_end
                        else:
                            transports = []
                            attr_start = current_time
                        attr_end = add_minutes(attr_start, self._visit_len(attr, params, constraints))
                        if is_open_during(attr, attr_start, attr_end) and self._activity_timing_allowed(
                            attr_name,
                            attr_start,
                            timing_constraints,
                            [current_pos],
                        ):
                            attr_act = self._make_attraction_activity(
                                attr, people, attr_start, attr_end, transports)
                            added = self._append_activity(
                                activities,
                                attr_act,
                                budget_limits,
                                budget_tracker,
                                force=self._is_required_attraction(
                                    attr,
                                    required_attractions,
                                    required_attraction_types,
                                ),
                            )
                            if added:
                                current_time = attr_end
                                current_pos = attr_name

                # Morning fill before lunch.
                attr_idx, current_time, current_pos, _added = self._fill_extra_attractions(
                    activities, env, target_city, good_attrs, attr_idx, current_pos, current_time,
                    people, params, constraints, budget_limits, budget_tracker, timing_constraints,
                    required_attractions, required_attraction_types,
                    extra_budget - extra_used, "11:30", latest_end="13:00")
                extra_used += _added

                # Lunch
                if lunch_idx < len(lunch_restaurants) and time_before(current_time, "13:00"):
                    restaurant, new_lunch_idx = self._pick_restaurant(
                        lunch_restaurants,
                        lunch_idx,
                        people,
                        budget_limits,
                        budget_tracker,
                    )
                    rest_name = str(restaurant["name"]) if restaurant is not None else current_pos
                    transports, travel_end = self._get_transport(
                        env, target_city, current_pos, rest_name, current_time, people)
                    if transports is not None:
                        lunch_start = max(travel_end or current_time, "11:00")
                    else:
                        transports = []
                        lunch_start = max(current_time, "11:00")
                    lunch_end = add_minutes(lunch_start, 60)
                    if restaurant is not None and time_before(lunch_end, "14:00") and self._activity_timing_allowed(
                        rest_name,
                        lunch_start,
                        timing_constraints,
                        [current_pos],
                    ):
                        lunch_idx = new_lunch_idx
                        lunch = self._make_meal_activity(
                            "lunch", restaurant, people, lunch_start, lunch_end, transports)
                        added = self._append_activity(
                            activities,
                            lunch,
                            budget_limits,
                            budget_tracker,
                            force=self._is_required_restaurant(restaurant, required_restaurants),
                        )
                        if added:
                            current_time = lunch_end
                            current_pos = rest_name

                # Afternoon attraction
                if attr_idx < len(good_attrs) and time_before(current_time, "16:00"):
                    est_start = add_minutes(current_time, 20)
                    est_end = add_minutes(est_start, self._slot_visit_len(params, constraints))
                    attr, attr_idx = self._pick_attraction(good_attrs, attr_idx, est_start, est_end)
                    if attr is not None:
                        attr_name = str(attr["name"])
                        transports, travel_end = self._get_transport(
                            env, target_city, current_pos, attr_name, current_time, people)
                        if transports is not None:
                            attr_start = travel_end
                        else:
                            transports = []
                            attr_start = current_time
                        attr_end = add_minutes(attr_start, self._visit_len(attr, params, constraints))
                        if is_open_during(attr, attr_start, attr_end) and self._activity_timing_allowed(
                            attr_name,
                            attr_start,
                            timing_constraints,
                            [current_pos],
                        ):
                            attr_act = self._make_attraction_activity(
                                attr, people, attr_start, attr_end, transports)
                            added = self._append_activity(
                                activities,
                                attr_act,
                                budget_limits,
                                budget_tracker,
                                force=self._is_required_attraction(
                                    attr,
                                    required_attractions,
                                    required_attraction_types,
                                ),
                            )
                            if added:
                                current_time = attr_end
                                current_pos = attr_name

                # Afternoon fill before dinner.
                attr_idx, current_time, current_pos, _added = self._fill_extra_attractions(
                    activities, env, target_city, good_attrs, attr_idx, current_pos, current_time,
                    people, params, constraints, budget_limits, budget_tracker, timing_constraints,
                    required_attractions, required_attraction_types,
                    extra_budget - extra_used, "16:30", latest_end="18:00")
                extra_used += _added

                # Dinner
                if dinner_idx < len(dinner_restaurants) and time_before(current_time, "19:00"):
                    restaurant, new_dinner_idx = self._pick_restaurant(
                        dinner_restaurants,
                        dinner_idx,
                        people,
                        budget_limits,
                        budget_tracker,
                    )
                    rest_name = str(restaurant["name"]) if restaurant is not None else current_pos
                    transports, travel_end = self._get_transport(
                        env, target_city, current_pos, rest_name, current_time, people)
                    if transports is not None:
                        dinner_start = max(travel_end or current_time, "17:00")
                    else:
                        transports = []
                        dinner_start = max(current_time, "17:00")
                    dinner_end = add_minutes(dinner_start, 60)
                    if restaurant is not None and time_before(dinner_end, "20:00") and self._activity_timing_allowed(
                        rest_name,
                        dinner_start,
                        timing_constraints,
                        [current_pos],
                    ):
                        dinner_idx = new_dinner_idx
                        dinner = self._make_meal_activity(
                            "dinner", restaurant, people, dinner_start, dinner_end, transports)
                        added = self._append_activity(
                            activities,
                            dinner,
                            budget_limits,
                            budget_tracker,
                            force=self._is_required_restaurant(restaurant, required_restaurants),
                        )
                        if added:
                            current_time = dinner_end
                            current_pos = rest_name

                # Evening fill after dinner (only late-open attractions qualify).
                attr_idx, current_time, current_pos, _added = self._fill_extra_attractions(
                    activities, env, target_city, good_attrs, attr_idx, current_pos, current_time,
                    people, params, constraints, budget_limits, budget_tracker, timing_constraints,
                    required_attractions, required_attraction_types,
                    extra_budget - extra_used, "21:00")
                extra_used += _added

                # Accommodation
                transports, travel_end = self._get_transport(
                    env, target_city, current_pos, hotel_name, current_time, people)
                if transports is None or current_pos == hotel_name:
                    transports = []
                    travel_end = current_time
                stay = self._make_accommodation_activity(
                    hotel, rooms_needed, travel_end, transports)
                self._append_preregistered_activity(activities, stay)
                current_pos = hotel_name

            itinerary.append({"day": day_num, "activities": activities})

        return {
            "people_number": people,
            "start_city": start_city,
            "target_city": target_city,
            "itinerary": itinerary,
        }

    def _get_intercity(
        self,
        env,
        from_city,
        to_city,
        earliest,
        preferred_mode=None,
        budget_limits=None,
        budget_tracker=None,
        pending_intercity=None,
        people=1,
        window=None,
    ):
        """Get first affordable intercity transport, falling back to cheapest available."""
        preferred = self._norm_text(preferred_mode)
        transport_order = ["airplane", "train"]
        if preferred in ["airplane", "flight", "plane"]:
            transport_order = ["airplane", "train"]
        elif preferred in ["train", "rail"]:
            transport_order = ["train", "airplane"]

        pending_cost = 0.0
        if pending_intercity is not None:
            pending_cost = self._safe_float(pending_intercity.get("Cost", 0.0), 0.0)

        best = None
        best_cost = None
        for transport_type in transport_order:
            affordable = []
            try:
                df = env.intercitytransport.select(from_city, to_city, transport_type, earliest)
                if df is not None and len(df) > 0:
                    for i in range(len(df)):
                        cand = df.iloc[i].to_dict()
                        if not self._route_timing_allowed(
                            getattr(self, "_active_timing_constraints", []),
                            [cand.get("From", ""), from_city],
                            [cand.get("To", ""), to_city],
                            str(cand.get("BeginTime", earliest)),
                            str(cand.get("EndTime", earliest)),
                        ):
                            continue
                        cost = self._safe_float(cand.get("Cost", 0.0), 0.0)
                        # Multiply by people so the budget check accounts for total cost
                        projected_intercity_total = (cost + pending_cost) * people
                        if self._affordable_main_cost("intercity_transport", projected_intercity_total, budget_limits, budget_tracker):
                            if window is None:
                                return cand
                            affordable.append(cand)
                        if best is None or best_cost is None or cost < best_cost:
                            best = cand
                            best_cost = cost
            except Exception:
                pass
            # Window modes maximize in-destination time among affordable options while
            # preserving transport-type priority (the preferred mode is tried first).
            if window and affordable:
                if window == "late":
                    return max(affordable, key=lambda c: time_to_minutes(str(c.get("BeginTime", "00:00"))))
                if window == "early_arrival":
                    def _arrival_min(c):
                        begin = time_to_minutes(str(c.get("BeginTime", "00:00")))
                        end = time_to_minutes(str(c.get("EndTime", "23:59")))
                        return end + (1440 if end < begin else 0)
                    return min(affordable, key=_arrival_min)
        return best

    def _pick_attraction(self, good_attrs, attr_idx, start_time, end_time):
        """Pick the next attraction that is open during [start_time, end_time].
        Required attractions (in self._required_attrs_remaining) are tried first.
        Returns (attr, new_attr_idx) or (None, attr_idx) if none found."""
        scheduled = getattr(self, '_scheduled_attr_names', set())
        required_types = getattr(self, '_required_attr_types_remaining', [])
        # First: try any still-pending required attraction
        remaining = getattr(self, '_required_attrs_remaining', [])
        if required_types:
            for i, attr in enumerate(remaining):
                if not is_open_during(attr, start_time, end_time):
                    continue
                attr_type = str(attr.get("type", ""))
                if any(self._match_type(attr_type, req_t) for req_t in required_types):
                    remaining.pop(i)
                    scheduled.add(self._norm_text(str(attr["name"])))
                    self._consume_required_attr_types(attr)
                    return attr, attr_idx
        for i, attr in enumerate(remaining):
            if is_open_during(attr, start_time, end_time):
                remaining.pop(i)
                scheduled.add(self._norm_text(str(attr["name"])))
                self._consume_required_attr_types(attr)
                return attr, attr_idx  # don't advance attr_idx (optional pool unchanged)
        # Fallback: normal forward scan through optional pool, skip already scheduled
        idx = attr_idx
        while idx < len(good_attrs):
            attr = good_attrs[idx]
            if self._norm_text(str(attr["name"])) not in scheduled and is_open_during(attr, start_time, end_time):
                scheduled.add(self._norm_text(str(attr["name"])))
                self._consume_required_attr_types(attr)
                return attr, idx + 1
            idx += 1
        return None, attr_idx

    def _consume_required_attr_types(self, attr):
        remaining = getattr(self, "_required_attr_types_remaining", None)
        if not remaining:
            return
        attr_type = str(attr.get("type", ""))
        still_missing = []
        for req_t in remaining:
            if not self._match_type(attr_type, req_t):
                still_missing.append(req_t)
        self._required_attr_types_remaining = still_missing

    def _fill_extra_attractions(self, activities, env, target_city, good_attrs, attr_idx,
                                current_pos, current_time, people, params, constraints,
                                budget_limits, budget_tracker, timing_constraints,
                                required_attractions, required_attraction_types,
                                target_count, until_time, return_guard=None, latest_end=None):
        """Greedily append open attractions until `target_count` are added or `current_time`
        reaches `until_time` (or the pool/feasibility runs out). Fills idle daytime slots to lift
        DAV. Each add already respects opening hours, per-activity timing and budget; FPR cannot
        regress because _solve keeps only accepted plans and the eval merge adopts a plan only when
        its full weighted score beats the stored best. Returns (attr_idx, current_time, current_pos, added)."""
        added = 0
        while (added < target_count and attr_idx < len(good_attrs)
               and time_before(current_time, until_time)):
            est_start = add_minutes(current_time, 20)
            est_end = add_minutes(est_start, self._slot_visit_len(params, constraints))
            attr, attr_idx = self._pick_attraction(good_attrs, attr_idx, est_start, est_end)
            if attr is None:
                break
            attr_name = str(attr["name"])
            transports, travel_end = self._get_transport(
                env, target_city, current_pos, attr_name, current_time, people)
            if transports is not None:
                attr_start = travel_end
            else:
                transports = []
                attr_start = current_time
            attr_end = add_minutes(attr_start, self._visit_len(attr, params, constraints))
            if latest_end is not None and not time_before(attr_end, latest_end):
                break
            if not (is_open_during(attr, attr_start, attr_end) and self._activity_timing_allowed(
                    attr_name, attr_start, timing_constraints, [current_pos])):
                break
            if return_guard is not None and not return_guard(attr_name, attr_end):
                break
            attr_act = self._make_attraction_activity(attr, people, attr_start, attr_end, transports)
            if not self._append_activity(
                    activities, attr_act, budget_limits, budget_tracker,
                    force=self._is_required_attraction(attr, required_attractions, required_attraction_types)):
                break
            current_time = attr_end
            current_pos = attr_name
            added += 1
        return attr_idx, current_time, current_pos, added

    def _get_transport(self, env, city, from_pos, to_pos, start_time, people):
        """Get taxi transport between two positions. Returns (transports_list, arrival_time) or (None, None)."""
        timing_constraints = getattr(self, "_active_timing_constraints", [])
        depart_floor = self._timing_departure_floor(timing_constraints, [from_pos])
        if depart_floor is not None and time_to_minutes(start_time) < depart_floor:
            start_time = minutes_to_time(depart_floor)
        if from_pos == to_pos:
            return [], start_time
        excluded = set(
            self._norm_text(m)
            for m in (self._transport_constraints.get("excluded_inner_transport", []) or [])
        )
        conditional = self._transport_constraints.get("conditional_transport", None)
        mode_order = ["metro", "walk", "taxi"]
        # Search may pin the inner-city mode; explicit choice overrides the budget/conditional heuristics
        # but still respects excluded modes and the taxi car-count guard below.
        forced_inner = self._norm_text(getattr(self, "_forced_inner_mode", None) or "")
        if forced_inner:
            mode_order = [forced_inner]

        # If inner_transport budget is constrained, prefer cheaper modes (metro > walk > taxi)
        inner_budget_limit = getattr(self, "_budget_limits", {}).get("inner_transport", -1)
        if inner_budget_limit >= 0 and not forced_inner:
            mode_order = ["walk", "metro", "taxi"] if inner_budget_limit <= 50 else ["metro", "walk", "taxi"]
        taxi_cars_equals = self._transport_constraints.get("taxi_cars_equals", None)
        if taxi_cars_equals is not None:
            try:
                required_cars = int(taxi_cars_equals)
                projected_cars = max(1, int(math.ceil(float(people) / 4.0)))
                if projected_cars != required_cars:
                    mode_order = [m for m in mode_order if m != "taxi"]
            except Exception:
                pass

        if isinstance(conditional, dict) and not forced_inner:
            preferred = self._norm_text(conditional.get("mode", "taxi"))
            threshold_km = conditional.get("threshold_km", None)
            if preferred in ["taxi", "metro", "walk"]:
                if threshold_km is not None:
                    # Probe with taxi to get actual route distance, then decide
                    try:
                        probe = env.transportation.goto(city, from_pos, to_pos, start_time, "taxi")
                        if isinstance(probe, list) and len(probe) > 0:
                            total_dist_km = sum(seg.get("distance", 0) for seg in probe) / 1000.0
                            if total_dist_km > threshold_km:
                                mode_order = [preferred] + [m for m in mode_order if m != preferred]
                            # else: distance is below threshold — leave default order
                    except Exception:
                        pass  # probe failed, leave default order
                else:
                    # No threshold: unconditionally prefer the mode
                    mode_order = [preferred] + [m for m in mode_order if m != preferred]

        mode_order = [m for m in mode_order if self._norm_text(m) not in excluded]
        if len(mode_order) == 0:
            return None, None

        try:
            for mode in mode_order:
                result = env.transportation.goto(city, from_pos, to_pos, start_time, mode)
                if isinstance(result, list) and len(result) > 0:
                    transports = self._format_transport_segments(result, people)
                    arrival_time = transports[-1]["end_time"]
                    return transports, arrival_time
        except Exception:
            pass
        return None, None

    def _best_transport_via_get_transport(self, city, from_pos, to_pos, start_time, people):
        """Shortest-time valid inner-city route using the same `_get_transport` constraints.

        Tries walk first so tight inner-city budgets still have a chance to stay feasible, then
        evaluates the other grounded modes and keeps the fastest valid route. Restores the caller's
        forced-mode exploration state before returning.
        """
        saved_forced_mode = getattr(self, "_forced_inner_mode", None)
        best_transports = None
        best_arrival = None
        best_minutes = None
        try:
            for mode in ("walk", "taxi", "metro"):
                self._forced_inner_mode = mode
                try:
                    transports, arrival = self._get_transport(
                        self.env, city, from_pos, to_pos, start_time, people)
                except Exception:
                    continue
                if transports is None or arrival is None:
                    continue
                total_minutes = 0
                for leg in transports or []:
                    try:
                        total_minutes += (
                            time_to_minutes(str(leg["end_time"]))
                            - time_to_minutes(str(leg["start_time"]))
                        )
                    except Exception:
                        total_minutes = None
                        break
                if total_minutes is None:
                    continue
                if best_minutes is None or total_minutes < best_minutes:
                    best_transports = transports
                    best_arrival = arrival
                    best_minutes = total_minutes
        finally:
            self._forced_inner_mode = saved_forced_mode
        return best_transports, best_arrival

    def _format_transport_segments(self, result, people):
        """Convert ``env.transportation.goto``'s raw segment list into the plan-facing
        ``transports`` shape (shared by ``_get_transport`` and ``_get_transport_resilient``)."""
        transports = []
        for seg in result:
            t = {
                "start": seg["start"],
                "end": seg["end"],
                "mode": seg["mode"],
                "start_time": seg["start_time"],
                "end_time": seg["end_time"],
                "distance": seg["distance"],
            }
            if seg["mode"] == "taxi":
                cars = max(1, int(math.ceil(float(people) / 4.0)))
                t["price"] = seg["cost"]
                t["cost"] = seg["cost"] * cars
                t["cars"] = cars
            elif seg["mode"] == "metro":
                t["price"] = seg["cost"]
                t["cost"] = seg["cost"] * people
                t["tickets"] = people
            else:  # walk
                t["price"] = 0
                t["cost"] = 0
            transports.append(t)
        return transports

    def _get_transport_resilient(self, env, city, from_pos, to_pos, start_time, people):
        """Like ``_get_transport``, but tries every allowed inner-city mode independently, so one
        mode raising (an observed ``env.transportation.goto`` edge case on some metro routes)
        does not abort the remaining modes. ``_get_transport`` wraps its *whole* mode loop in one
        try/except, so today a single raising mode silently fails the entire lookup even when a
        later mode would have succeeded -- the roadmap-step-4 root cause behind some "Invalid
        Transport information across positions" cases, where the greedy build's own
        ``_get_transport`` call failed this way and the caller fell back to an empty leg.

        Used only by the opt-in transport-gap repair pass, so the widely-called
        ``_get_transport`` (and its restart-exploration semantics -- forced mode, budget-ordered
        preference, conditional threshold) stays untouched everywhere else. This variant ignores
        those exploration knobs entirely (repair wants the best chance at *any* grounded route,
        not a particular exploration bias); real exclusions (``excluded_inner_transport``, the
        taxi car-count guard) still apply."""
        timing_constraints = getattr(self, "_active_timing_constraints", [])
        depart_floor = self._timing_departure_floor(timing_constraints, [from_pos])
        if depart_floor is not None and time_to_minutes(start_time) < depart_floor:
            start_time = minutes_to_time(depart_floor)
        if from_pos == to_pos:
            return [], start_time
        excluded = set(
            self._norm_text(m)
            for m in (self._transport_constraints.get("excluded_inner_transport", []) or [])
        )
        taxi_cars_equals = self._transport_constraints.get("taxi_cars_equals", None)
        for mode in ("metro", "walk", "taxi"):
            if self._norm_text(mode) in excluded:
                continue
            if mode == "taxi" and taxi_cars_equals is not None:
                try:
                    required_cars = int(taxi_cars_equals)
                    projected_cars = max(1, int(math.ceil(float(people) / 4.0)))
                    if projected_cars != required_cars:
                        continue
                except Exception:
                    pass
            try:
                result = env.transportation.goto(city, from_pos, to_pos, start_time, mode)
            except Exception:
                continue
            if isinstance(result, list) and len(result) > 0:
                transports = self._format_transport_segments(result, people)
                return transports, transports[-1]["end_time"]
        return None, None

    def _make_intercity_activity(self, transport, people, transports=None):
        """Create an intercity transport activity dict."""
        if transports is None:
            transports = []
        activity = {
            "type": "airplane" if "FlightID" in transport else "train",
            "start_time": transport["BeginTime"],
            "end_time": transport["EndTime"],
            "start": transport["From"],
            "end": transport["To"],
            "price": transport["Cost"],
            "cost": transport["Cost"] * people,
            "tickets": people,
            "transports": transports,
        }
        if "FlightID" in transport:
            activity["FlightID"] = transport["FlightID"]
        else:
            activity["TrainID"] = transport["TrainID"]
        return activity

    def _make_attraction_activity(self, attr, people, start_time, end_time, transports=None):
        """Create an attraction activity dict."""
        if transports is None:
            transports = []
        return {
            "type": "attraction",
            "position": str(attr["name"]),
            "start_time": start_time,
            "end_time": end_time,
            "price": float(attr["price"]),
            "cost": float(attr["price"]) * people,
            "tickets": people,
            "transports": transports,
        }

    def _make_meal_activity(self, meal_type, restaurant, people, start_time, end_time, transports=None):
        """Create a meal (breakfast/lunch/dinner) activity dict."""
        if transports is None:
            transports = []
        return {
            "type": meal_type,
            "position": str(restaurant["name"]),
            "start_time": start_time,
            "end_time": end_time,
            "price": float(restaurant["price"]),
            "cost": float(restaurant["price"]) * people,
            "tickets": people,
            "transports": transports,
        }

    def _make_hotel_breakfast(self, hotel_name, start_time, end_time):
        """Create a breakfast-at-hotel activity (free)."""
        return {
            "type": "breakfast",
            "position": hotel_name,
            "start_time": start_time,
            "end_time": end_time,
            "price": 0,
            "cost": 0,
            "tickets": 0,
            "transports": [],
        }

    def _make_accommodation_activity(self, hotel, rooms, check_in_time, transports=None):
        """Create an accommodation activity dict."""
        if transports is None:
            transports = []
        return {
            "type": "accommodation",
            "position": str(hotel["name"]),
            "start_time": check_in_time,
            "end_time": "24:00",
            "price": float(hotel["price"]),
            "cost": float(hotel["price"]) * rooms,
            "rooms": rooms,
            "room_type": int(hotel["numbed"]),
            "tickets": rooms,
            "transports": transports,
        }