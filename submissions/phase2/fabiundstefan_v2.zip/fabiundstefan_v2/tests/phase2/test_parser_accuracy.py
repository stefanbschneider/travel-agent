"""Parser-accuracy regression tests (Phase A): deterministic no-oracle fixes.

A1: derive taxi_cars_equals from people_number.
A2: restaurant negation guard + bogus cuisine cleanup.
A3: budget category disambiguation + familiar line-scoped caps.

These lock in the concrete parser bugs found in the val-split analysis.
"""

from __future__ import annotations

import math

import pytest

import parse_constraints as pc
from chinatravel.agent.tpc_agent.solver_constraints import solver_constraint_variants
from chinatravel.agent.phase2 import normalize
from chinatravel.agent.phase2.orchestrator import Flags


def _q(nl, people=2, days=2):
    return {
        "nature_language": nl,
        "people_number": people,
        "days": days,
        "start_city": "Shanghai",
        "target_city": "Nanjing",
        "uid": "t",
    }


# --- A1: taxi_cars_equals derivation ---------------------------------------

@pytest.mark.parametrize("people,expected", [(1, 1), (2, 1), (3, 1), (4, 1), (5, 2), (8, 2), (9, 3)])
def test_taxi_cars_equals_derived_from_people(people, expected):
    raw = pc.parse_query_no_oracle(_q("A simple trip.", people=people))
    assert raw.get("taxi_cars_equals") == expected == math.ceil(people / 4)


def test_taxi_cars_equals_survives_disjunction_expansion():
    # A genuinely disjunctive, recoverable query; every expanded branch keeps the global taxi count.
    nl = ("We are 5 people for a trip and must satisfy at least one of the following:\n"
          "1. Want to visit Cultural Landscape\n"
          "2. Do not want to visit Confucius Temple")
    q = _q(nl, people=5)
    ir = normalize.parse_to_ir(q, flags=Flags(disjunction=True))
    variants = normalize.ir_to_solver_variants(ir, q, flags=Flags(disjunction=True))
    assert len(variants) >= 2, "query should expand into >=2 branches"
    for v in variants:
        assert v.get("taxi_cars_equals") == 2, v


# --- A2: restaurant negation guard -----------------------------------------

def test_negated_restaurant_is_excluded_not_required():
    raw = pc.parse_query_no_oracle(
        _q("Requirement: we do not want to try the following restaurant: West Dyke Thick Steak.")
    )
    assert not raw.get("required_restaurants"), raw.get("required_restaurants")
    assert raw.get("excluded_restaurants") == ["West Dyke Thick Steak"]
    # no bogus cuisine leakage
    assert raw.get("cuisine_preference") in (None, [], ""), raw.get("cuisine_preference")


def test_positive_restaurant_still_required():
    raw = pc.parse_query_no_oracle(
        _q("We want to dine at the following restaurant: Grandma's Home.")
    )
    assert raw.get("required_restaurants") == ["Grandma's Home"]
    assert not raw.get("excluded_restaurants")


def test_negated_restaurant_type_is_excluded_cuisine():
    raw = pc.parse_query_no_oracle(
        _q("Requirement: do not want to try restaurants of the type Snacks.")
    )
    # must NOT produce a garbage required_restaurants entry
    assert not raw.get("required_restaurants"), raw.get("required_restaurants")
    assert raw.get("excluded_cuisine_types") == ["Snacks"], raw


def test_negated_plural_restaurants_are_excluded():
    raw = pc.parse_query_no_oracle(
        _q("Requirement: do not want to try the following restaurants: Rest A and Rest B.")
    )
    assert not raw.get("required_restaurants"), raw.get("required_restaurants")
    assert raw.get("excluded_restaurants") == ["Rest A", "Rest B"], raw


def test_negated_the_restaurant_singular_is_excluded():
    raw = pc.parse_query_no_oracle(
        _q("Must: do not want to try the restaurant: Cloud View Hotel Diner.")
    )
    assert not raw.get("required_restaurants"), raw.get("required_restaurants")
    assert raw.get("excluded_restaurants") == ["Cloud View Hotel Diner"], raw


# --- Restaurant “following type” parsing -----------------------------------------------------


def test_restaurant_of_the_following_type_is_not_a_required_restaurant_name():
    # Regression: the "of (the) type(s)" guard didn't account for "of the FOLLOWING type", so
    # this leaked through as a bogus required_restaurants entry (val-split top spurious family).
    raw = pc.parse_query_no_oracle(
        _q("We hope to try restaurants of the following type: Shanghai cuisine.")
    )
    assert not raw.get("required_restaurants"), raw.get("required_restaurants")


def test_restaurant_of_the_following_type_is_cuisine_preference():
    raw = pc.parse_query_no_oracle(
        _q("We hope to try restaurants of the following type: Shanghai cuisine.")
    )
    assert raw.get("cuisine_preference") == "Shanghai cuisine", raw


def test_negated_restaurant_of_the_following_type_is_excluded_not_preferred():
    # The new "restaurants of (the) (following) type(s)" cuisine_preference pattern must respect
    # negation (the trigger sits ~15 chars before "restaurants", outside a naive adjacent check).
    raw = pc.parse_query_no_oracle(
        _q("Do not want to try restaurants of the type Sichuan cuisine.")
    )
    assert raw.get("cuisine_preference") in (None, [], ""), raw.get("cuisine_preference")
    assert raw.get("excluded_cuisine_types") == ["Sichuan cuisine"], raw


# --- A3: budget category disambiguation ------------------------------------

def test_cross_city_budget_does_not_leak_into_inner_transport():
    raw = pc.parse_query_no_oracle(
        _q("Requirement: the cross-city transportation budget is 2300.0.")
    )
    b = raw.get("budgets") or {}
    assert b.get("intercity_transport") == 2300.0, b
    assert "inner_transport" not in b, b


def test_intercity_budget_wording_does_not_leak():
    raw = pc.parse_query_no_oracle(
        _q("Requirement: the intercity transportation budget is 2700.0.")
    )
    b = raw.get("budgets") or {}
    assert b.get("intercity_transport") == 2700.0, b
    assert "inner_transport" not in b, b


def test_genuine_inner_transport_budget_still_parsed():
    raw = pc.parse_query_no_oracle(
        _q("Requirement: the intra-city transportation budget is 150.0.")
    )
    b = raw.get("budgets") or {}
    assert b.get("inner_transport") == 150.0, b


def test_familiar_keep_within_budget_templates_map_all_buckets():
    raw = pc.parse_query_no_oracle(
        _q(
            "Requirements:\n"
            "1. Keep the accommodation cost within 342.\n"
            "2. Keep transportation within the destination city within 74.\n"
            "3. Keep the total activity and in-city transportation cost within 6436.\n"
            "4. Keep the dining cost within 1161.\n"
            "5. Keep the attraction ticket cost within 55."
        )
    )
    assert raw.get("budgets") == {
        "accommodation": 342.0,
        "inner_transport": 74.0,
        "total": 6436.0,
        "dining": 1161.0,
        "sightseeing": 55.0,
    }


# --- 1c: negation guard extended to hotels ---------------------------------

def test_negated_hotels_are_excluded_not_required():
    # Real val query 20250320230800586344 shape: "Do not wish to stay at the
    # following hotels: X and Y" previously also emitted a spurious required_hotels.
    raw = pc.parse_query_no_oracle(
        _q("Do not wish to stay at the following hotels: Yucheng Hotel (Wuhan) "
           "and All Seasons Hotel (Wuhan).")
    )
    assert not raw.get("required_hotels"), raw.get("required_hotels")
    assert raw.get("excluded_hotels") == [
        "Yucheng Hotel (Wuhan)",
        "All Seasons Hotel (Wuhan)",
    ], raw.get("excluded_hotels")


def test_negated_hotels_short_form_excluded():
    raw = pc.parse_query_no_oracle(
        _q("Do not want to stay at Modern Classic Hotel and Holiday Inn Express Dongmen.")
    )
    assert not raw.get("required_hotels"), raw.get("required_hotels")
    assert raw.get("excluded_hotels") == [
        "Modern Classic Hotel",
        "Holiday Inn Express Dongmen",
    ], raw.get("excluded_hotels")


def test_positive_hotel_still_required():
    raw = pc.parse_query_no_oracle(
        _q("We want to stay at one of the following hotels: Huayueju Serviced Apartment.")
    )
    # The negation guard must not suppress a positive hotel requirement: the clean
    # hotel name is still present (a pre-existing "one of the following hotels:" prefix
    # over-extraction is out of scope here and harmless -- the verifier matches by `any`).
    req = raw.get("required_hotels") or []
    assert "Huayueju Serviced Apartment" in req, req
    assert not raw.get("excluded_hotels"), raw.get("excluded_hotels")


# --- 1c: negation guard extended to attractions ----------------------------

def test_negated_attraction_types_do_not_leak_into_required():
    # Real val query 20250321111720443608: a positive "visit X" clause followed by
    # a negated "do not want to visit any Museum/... or university campus" clause.
    raw = pc.parse_query_no_oracle(
        _q("We want to visit Xixi Paradise Commercial Street and do not want to "
           "visit any Museum/Memorial Hall or university campus.")
    )
    # positive name survives ...
    assert raw.get("required_attractions") == ["Xixi Paradise Commercial Street"], raw
    # ... but the negated types must NOT be required
    req_types = raw.get("required_attraction_types") or []
    assert "Museum/Memorial Hall" not in req_types, raw
    assert "university campus" not in req_types, raw
    # they belong to the excluded set instead
    excl_types = raw.get("excluded_attraction_types") or []
    assert "Museum/Memorial Hall" in excl_types, raw
    assert "university campus" in excl_types, raw


def test_negated_attraction_name_not_required():
    raw = pc.parse_query_no_oracle(
        _q("We do not want to visit West Yellow Temple and Hall of Benevolent Longevity.")
    )
    assert not raw.get("required_attractions"), raw.get("required_attractions")


def test_positive_attraction_still_required():
    raw = pc.parse_query_no_oracle(
        _q("We want to visit Xixi Paradise Commercial Street.")
    )
    assert raw.get("required_attractions") == ["Xixi Paradise Commercial Street"], raw


# --- 1d: POI names in a time-window line must not leak into required_attraction_types --------
#
# familiar-100 real uids (parser_vs_oracle spurious-required_attraction_types bucket): the
# numbered-line "Visit X between A and B" template (activity_time_windows' territory) was also
# scanned by the required_attraction_types fallback, and a POI name containing a type word --
# "Golden Eagle Art Museum", "Baihua Tan Park", "Cloudrise Art Museum" -- spuriously produced a
# required_attraction_types entry with no such oracle constraint.

@pytest.mark.parametrize("line,leaked_type", [
    ("1. Visit Golden Eagle Art Museum between 14:44 and 16:34.", "Art Museum"),
    ("1. Visit Baihua Tan Park between 09:31 and 11:16.", "park"),
    ("1. Visit Cloudrise Art Museum between 15:33 and 17:33.", "Art Museum"),
])
def test_time_window_poi_name_does_not_leak_into_required_attraction_type(line, leaked_type):
    raw = pc.parse_query_no_oracle(_q(f"Requirements:\n{line}"))
    req_types = raw.get("required_attraction_types") or []
    assert leaked_type not in req_types, raw


# --- 5a: poi_distance_hotel schema parity (real val uids) ------------------
#
# The no-oracle NL path already extracts "accommodation within X km of Y" correctly via
# parse_hotel_nearby, but only stored it as the singular `hotel_nearby` dict -- the oracle (and
# the shared solver-dict schema) also expects a list-shaped `poi_distance_hotel` family, which the
# oracle-mode DSL converter (solver_constraints.py::_parse_hotel_distance) already mirrors. Real
# val uid 20250323092547439734 (oracle: [{"reference": "North Bund Riverside Green Space",
# "distance_km": 8.851522495588497}]) was 100% missing on this family before the fix.

def test_hotel_nearby_also_populates_poi_distance_hotel_list():
    raw = pc.parse_query_no_oracle(
        _q("Accommodation must be within 8.86 km of North Bund Riverside Green Space.")
    )
    assert raw.get("hotel_nearby") == {
        "reference": "North Bund Riverside Green Space", "distance_km": 8.86,
    }
    assert raw.get("poi_distance_hotel") == [
        {"reference": "North Bund Riverside Green Space", "distance_km": 8.86},
    ]


def test_hotel_nearby_strips_leading_the_from_reference():
    # Real val uid 20250323092305147660 phrasing: "... within 2.11 km of the Great Hall of the
    # People." Oracle reference is "Great Hall of the People" (no leading "the").
    raw = pc.parse_query_no_oracle(
        _q("We want accommodation within 2.11 km of the Great Hall of the People.")
    )
    assert raw["hotel_nearby"]["reference"] == "Great Hall of the People"
    assert raw["poi_distance_hotel"][0]["reference"] == "Great Hall of the People"


def test_hotel_nearby_variant_matches_solver_schema_family():
    query = _q("We hope the accommodation is within 9.65 kilometers of Futian District Sports Park.")
    raw = pc.parse_query_no_oracle(query)
    variants = solver_constraint_variants(query, raw, use_oracle=False)
    assert variants[0].get("poi_distance_hotel") == [
        {"reference": "Futian District Sports Park", "distance_km": 9.65},
    ]


# --- 5b: "hotel with X" amenity phrasing -> required_hotel_all_types -------
#
# The oracle never has a `hotel_amenity` family; "hotel with a swimming pool" / "hotel with Free
# parking" / "hotel with an Executive Lounge" are all encoded as required_hotel_all_types (e.g.
# ['Swimming pool'], ['Free parking'], ['Executive Lounge']) -- literally the same string, just the
# wrong family. `hotel_amenity` no longer exists as an output family at all: it was spurious-only
# against the oracle (32/32 val queries) and could reject oracle-acceptable plans.

@pytest.mark.parametrize("phrase,expected", [
    ("we prefer to stay at a hotel that offers free parking.", "Free parking"),
    ("we do not want to stay in hotels with a Sunbathing area.", "Sunbathing area"),
    ("want to stay in a hotel with an Executive Lounge.", "Executive Lounge"),
    ("we want to stay in a hotel with a Family Room.", "Family Room"),
    ("we want to stay at a hotel with a swimming pool.", "Swimming pool"),
    ("wish to stay in a hotel with Free parking.", "Free parking"),
])
def test_hotel_with_amenity_becomes_required_hotel_all_type(phrase, expected):
    raw = pc.parse_query_no_oracle(_q(f"We are 2 people traveling for 3 days. {phrase}"))
    assert expected in (raw.get("required_hotel_all_types") or []), raw
    assert "hotel_amenity" not in raw


def test_hotel_amenity_family_no_longer_produced():
    assert not hasattr(pc, "parse_hotel_amenity")


def test_parsed_verifier_no_longer_enforces_hotel_amenity():
    import inspect
    from chinatravel.agent.tpc_agent import parsed_verifier
    assert "hotel_amenity" not in inspect.getsource(parsed_verifier)


# --- 5c: excluded_cuisine_types word-order gap + cleanup bugs --------------

def test_reversed_word_order_type_of_restaurant_singular():
    # Real val phrasing: "type of restaurant" (singular), not "restaurant of type".
    raw = pc.parse_query_no_oracle(
        _q("2. Do not want to try the following type of restaurant: Hot pot")
    )
    assert raw.get("excluded_cuisine_types") == ["Hot pot"], raw


def test_reversed_word_order_types_of_restaurants_plural_multi():
    raw = pc.parse_query_no_oracle(
        _q("We do not want to try the following types of restaurants: Middle Eastern cuisine "
           "and Northwestern Chinese cuisine.")
    )
    assert raw.get("excluded_cuisine_types") == [
        "Middle Eastern cuisine", "Northwestern Chinese cuisine",
    ], raw


def test_restaurants_serving_x_phrasing():
    raw = pc.parse_query_no_oracle(
        _q("2. Do not want to try restaurants serving fusion cuisine.")
    )
    assert raw.get("excluded_cuisine_types") == ["fusion cuisine"], raw


def test_cuisine_suffix_kept_in_x_cuisine_restaurants_phrasing():
    # Previously dropped the word "cuisine" itself: captured "fusion" instead of "fusion cuisine".
    raw = pc.parse_query_no_oracle(
        _q("2. Do not want to try fusion cuisine restaurants.")
    )
    assert raw.get("excluded_cuisine_types") == ["fusion cuisine"], raw


def test_oxford_comma_and_before_last_item_not_kept():
    raw = pc.parse_query_no_oracle(
        _q("Do not want to try restaurants of types Bar/Pub, Other, and Halal cuisine.")
    )
    assert raw.get("excluded_cuisine_types") == ["Bar/Pub", "Other", "Halal cuisine"], raw


# --- 5d: oracle room_type numeric-code label fix (2 -> "twin", not "double") ---
#
# A full scan of every hard_logic_py in chinatravel/data/en/TPC_IJCAI_2026_phase1_EN/ found only
# codes 1 and 2 ever appear (74x code 1, 35x code 2, zero code 3), and every NL query whose oracle
# uses code 2 says "twin" ("twin beds room", "a twin room") -- never "double bed". Real val uids
# 20250322201024175211 and 20250322213548089207 both have "room_type(activity)!=2" in
# hard_logic_py with "twin" phrasing in the NL.

def _oracle_query(hard_logic_snippet, nl="A trip."):
    return {
        "uid": "t",
        "nature_language": nl,
        "people_number": 2,
        "days": 2,
        "start_city": "Shanghai",
        "target_city": "Nanjing",
        "hard_logic_py": [
            "result=True\nfor activity in allactivities(plan):\n"
            f"  if activity_type(activity)=='accommodation' and {hard_logic_snippet}: result=False"
        ],
    }


def test_oracle_room_type_code_2_maps_to_twin_not_double():
    query = _oracle_query("room_type(activity)!=2")
    raw = pc.parse_query(query)
    assert raw.get("room_type") == "twin", raw
    variants = solver_constraint_variants(query, raw, use_oracle=True)
    assert variants[0].get("room_type") == "twin", variants[0]


def test_oracle_room_type_code_1_still_maps_to_single():
    query = _oracle_query("room_type(activity)!=1")
    raw = pc.parse_query(query)
    assert raw.get("room_type") == "single", raw
    variants = solver_constraint_variants(query, raw, use_oracle=True)
    assert variants[0].get("room_type") == "single", variants[0]


def test_embedded_quotes_stripped():
    raw = pc.parse_query_no_oracle(
        _q('We do not wish to try restaurants of the types "Other Chinese Cuisine" and '
           '"Jiangsu-Zhejiang cuisine."')
    )
    assert raw.get("excluded_cuisine_types") == [
        "Other Chinese Cuisine", "Jiangsu-Zhejiang cuisine",
    ], raw


# --- Intercity-mode negation complement and coverage cases -----------------------------------

def test_negated_outbound_train_with_the_resolves_to_airplane():
    # uid 20250322204425912419: "We do not want to take the train to the destination, and we do
    # not want to take the train for the return trip." Oracle: outbound != train (-> airplane),
    # return != airplane (-> train). Previously the outbound negative regex required "take a/an
    # train" (no "the"), so it silently missed this phrasing (missing, not wrong-value).
    raw = pc.parse_query_no_oracle(_q(
        "We do not want to take the train to the destination, and we do not want to "
        "take the train for the return trip."
    ))
    assert raw.get("intercity_mode") == {"outbound": "airplane", "return": "airplane"}, raw


def test_negated_outbound_train_no_the_resolves_to_airplane():
    # uid 20250324210212304930: "do not want to take a train to the destination" -- previously a
    # positive pattern ("take a train to the destination") matched this substring first (ignoring
    # the negation prefix) and set outbound=train, the exact opposite of what the sentence says.
    raw = pc.parse_query_no_oracle(_q(
        "do not want to take a train to the destination, do not want to fly back, and want to "
        "stay in a single-bed room."
    ))
    assert raw.get("intercity_mode") == {"outbound": "airplane", "return": "train"}, raw


def test_positive_take_train_to_destination_and_back_unaffected():
    # uid 20250321032641509206: "take the train to the destination and take the train back" is
    # genuinely positive (no negation) -- must still resolve to train/train, not be swept up by
    # the negation-first ordering.
    raw = pc.parse_query_no_oracle(_q(
        "The requirement is to take the train to the destination and take the train back."
    ))
    assert raw.get("intercity_mode") == {"outbound": "train", "return": "train"}, raw


def test_negated_fly_back_resolves_return_to_train():
    raw = pc.parse_query_no_oracle(_q("We do not want to fly back for the return trip."))
    assert raw.get("intercity_mode", {}).get("return") == "train", raw


def test_multi_mode_exclusion_list_captures_all_modes():
    # uid 20250322035350348919: "we do not want to use walking or taxi as means of transportation
    # within the city" -- previously only "walk" was captured, "taxi" was dropped.
    raw = pc.parse_query_no_oracle(_q(
        "We do not want to use walking or taxi as means of transportation within the city."
    ))
    excluded = raw.get("excluded_inner_transport") or []
    assert set(excluded) == {"walk", "taxi"}, raw


# --- P24: oracle-side `intercity_transport_set` equality (2026-08-07) ------------------------
#
# The HF free-prose generator's *only* shape for this requirement is set equality --
# `intercity_transport_set=set(); ...; result=({'train'}==intercity_transport_set)` -- pinning
# every intercity leg to one mode. `_parse_intercity` (solver_constraints.py) previously
# recognized only the go/back accessor shape (`intercity_transport_go`/`_back`), used by the
# templated registers. Missing the set-equality shape meant the oracle-side solver-dict dropped a
# real requirement, so a correct NL extraction on the parsed side scored as a false "spurious"
# `intercity_mode` family instead of "matched" -- a measurement bug, not extraction over-reach.
# Measured: 100% of a sampled `intercity_mode`-spurious set on hf_easy/medium/human/preference_base50
# had this exact oracle clause (docs/tpc_phase2_roadmap.md#p24--stop-inventing-satisfiable-but-unrequested-constraints).

def test_oracle_intercity_transport_set_equality_train():
    query = {
        "uid": "t", "nature_language": "A trip.", "people_number": 2, "days": 2,
        "start_city": "Shanghai", "target_city": "Nanjing",
        "hard_logic_py": [
            "intercity_transport_set=set()\nfor activity in allactivities(plan):\n"
            "  if activity_type(activity) in ['train', 'airplane']: "
            "intercity_transport_set.add(intercity_transport_type(activity))\n"
            "result=({'train'}==intercity_transport_set)"
        ],
    }
    raw = pc.parse_query(query)
    variants = solver_constraint_variants(query, raw, use_oracle=True)
    assert variants[0].get("intercity_mode") == {"outbound": "train", "return": "train"}, variants[0]


def test_oracle_intercity_transport_set_equality_airplane():
    query = {
        "uid": "t", "nature_language": "A trip.", "people_number": 2, "days": 2,
        "start_city": "Shanghai", "target_city": "Nanjing",
        "hard_logic_py": [
            "intercity_transport_set=set()\nfor activity in allactivities(plan):\n"
            "  if activity_type(activity) in ['train', 'airplane']: "
            "intercity_transport_set.add(intercity_transport_type(activity))\n"
            "result=({'airplane'}==intercity_transport_set)"
        ],
    }
    raw = pc.parse_query(query)
    variants = solver_constraint_variants(query, raw, use_oracle=True)
    assert variants[0].get("intercity_mode") == {"outbound": "airplane", "return": "airplane"}, variants[0]


def test_intercity_go_back_accessor_shape_not_clobbered_by_set_equality_fallback():
    # Both shapes in one clause (shouldn't happen in real data -- no sampled query mixes them --
    # but the go/back accessor pattern is more specific, e.g. it can pin each leg independently,
    # so within a single ``_parse_intercity`` call it must not be clobbered by the coarser
    # set-equality fallback; the fallback uses ``setdefault`` for exactly this reason.
    from chinatravel.agent.tpc_agent.solver_constraints import _parse_intercity

    logic = (
        "result=(intercity_transport_go=='train')\n"
        "intercity_transport_set=set()\nfor activity in allactivities(plan):\n"
        "  if activity_type(activity) in ['train', 'airplane']: "
        "intercity_transport_set.add(intercity_transport_type(activity))\n"
        "result2=({'airplane'}==intercity_transport_set)"
    )
    result: dict = {}
    _parse_intercity(logic, result)
    assert result.get("intercity_mode", {}).get("outbound") == "train", result


# --- OR-arm bare-imperative and arm-local budget recovery ------------------------------------


def test_bare_imperative_visit_extracts_attraction_name():
    # uid 20250321152015286634 arm 1: "Visit Shenzhen Art Museum (East Lake Branch)" -- a bare
    # imperative with no "want to"/"must" framing (typical OR-arm bullet text). Oracle wants the
    # specific attraction name, not the "Art Museum" type substring.
    assert pc.parse_required_attractions("Visit Shenzhen Art Museum (East Lake Branch)") == [
        "Shenzhen Art Museum (East Lake Branch)"
    ]


# --- P24: stop inventing satisfiable but unrequested constraints (2026-08-07) -----------------
#
# required_attractions' "want to visit X" pattern has no delimiter between "visit <city>" and a
# trailing budget/day-count clause when no comma precedes it, so on the dominant free-prose shape
# "I want to visit <target city> for <N> days ... with a budget of ... RMB" it swallows the whole
# trip-framing tail as one "attraction name". Measured: every sampled spurious instance on
# hf_easy/medium/human/preference_base50 had no matching oracle attraction_name_set clause at all
# (docs/tpc_phase2_roadmap.md#p24--stop-inventing-satisfiable-but-unrequested-constraints).

def test_visit_city_with_trip_metadata_tail_is_not_an_attraction():
    assert pc.parse_required_attractions(
        "I want to visit Nanjing for a day by myself with a budget of 1800 RMB."
    ) is None


def test_visit_city_for_n_days_with_budget_is_not_an_attraction():
    assert pc.parse_required_attractions(
        "Three of us are planning to visit Nanjing for three days with a budget of 4000 RMB."
    ) is None


def test_visit_city_for_a_few_days_variant_is_not_an_attraction():
    # "for a few days" -- filler words between "for" and "day(s)", not just a bare number/article.
    assert pc.parse_required_attractions(
        "My girlfriend and I want to visit Guangzhou for a few days to see the rivers and relax."
    ) is None


def test_generic_sentiment_phrase_is_not_an_attraction():
    # No proper noun at all -- "attractions suitable for children" / "some cool places" /
    # "places with beautiful scenery" style captures, filtered by requiring a capitalized token.
    assert pc.parse_required_attractions(
        "We mainly want to visit attractions suitable for children."
    ) is None


def test_real_attraction_name_still_extracted_unaffected_by_p24_guards():
    assert pc.parse_required_attractions("We want to visit Iron Statue Temple Water Street.") == [
        "Iron Statue Temple Water Street"
    ]


def test_trailing_real_attraction_after_trip_framing_part_survives_split():
    # The greedy capture still spans "visit <city> for N days and would like to go to <POI>" as
    # one match; the P24 guards run per split-part (not on the whole chunk) so the genuine second
    # half is not discarded along with the trip-framing first half.
    names = pc.parse_required_attractions(
        "The three of us want to visit Chongqing for 2 days and would like to go to the "
        "Great Hall of the People. Please provide us with a travel plan."
    )
    assert names and any("Great Hall of the People" in n for n in names), names


def test_trailing_restaurant_reference_not_captured_as_attraction():
    # The same split can land a restaurant/cuisine clause in the second part -- that belongs to
    # required_restaurants/cuisine_preference (their own anchored patterns), not
    # required_attractions.
    assert pc.parse_required_attractions(
        "Four of us want to visit Nanjing for 3 days and would like to try some Northeastern "
        "Chinese cuisine. Please provide us with a travel plan."
    ) is None


def test_quantified_room_phrase_is_not_a_hotel_name():
    assert pc.parse_required_hotels(
        "The three of us want to visit Guangzhou for 3 days and stay in two twin-bed rooms."
    ) is None
    assert pc.parse_required_hotels(
        "Four of us want to visit Shenzhen for two days and stay in two rooms."
    ) is None


def test_room_with_bed_description_is_not_a_hotel_name():
    assert pc.parse_required_hotels(
        "Two of us want to visit Beijing for 3 days and stay in a room with a double bed."
    ) is None
    assert pc.parse_required_hotels(
        "I want to take my child to Suzhou for 3 days and stay in a big bed room."
    ) is None


def test_real_hotel_name_still_extracted_unaffected_by_p24_guards():
    assert pc.parse_required_hotels(
        "We wish to stay at the Floral Hotel Hangzhou Zhuyin Garden Homestay."
    ) == ["the Floral Hotel Hangzhou Zhuyin Garden Homestay"]


def test_bare_imperative_try_restaurants_extracts_name():
    # uid 20250321152015286634 arm 2: "Try one of these restaurants: gaga (Joy Hub City Store)".
    assert pc.parse_required_restaurants(
        "Try one of these restaurants: gaga (Joy Hub City Store)"
    ) == ["gaga (Joy Hub City Store)"]


def test_arm_local_intra_city_travel_budget_wording():
    # uid 20250323010100845247 arm 1: "Intra-city travel budget of 50.0" -- the intra-city budget
    # regex previously required "transportation", missing the "travel" synonym.
    budgets = pc.parse_budget("Intra-city travel budget of 50.0")
    assert budgets.get("inner_transport") == 50.0, budgets


def test_arm_local_total_trip_budget_wording():
    # uid 20250323010100845247 arm 2: "Total trip budget of 9600.0" -- the total-budget regex
    # previously only allowed an optional "travel" word, missing "trip".
    budgets = pc.parse_budget("Total trip budget of 9600.0")
    assert budgets.get("total") == 9600.0, budgets


def test_or_arm_bare_imperative_and_budget_uids_produce_two_nonempty_arms():
    from chinatravel.agent.phase2 import normalize as N

    q1 = _q(
        "Please meet at least one of the following requirements:\n"
        "1. Visit Shenzhen Art Museum (East Lake Branch)\n"
        "2. Try one of these restaurants: gaga (Joy Hub City Store)",
        people=3, days=4,
    )
    arms = N._detect_or_groups(q1)
    assert len(arms) == 2
    assert all(arms), arms  # both non-empty
    assert arms[0].get("required_attractions") == ["Shenzhen Art Museum (East Lake Branch)"]
    assert arms[1].get("required_restaurants") == ["gaga (Joy Hub City Store)"]

    q2 = _q(
        "with either of the following requirements:\n"
        "1. Intra-city travel budget of 50.0\n"
        "2. Total trip budget of 9600.0",
        people=1, days=5,
    )
    arms2 = N._detect_or_groups(q2)
    assert len(arms2) == 2
    assert all(arms2), arms2
    assert arms2[0].get("budgets") == {"inner_transport": 50.0}
    assert arms2[1].get("budgets") == {"total": 9600.0}
