# fabiundstefan -- TPC @ IJCAI 2026, Phase 2 submission v2

Self-contained harness for the ChinaTravel Travel Planning Challenge, Phase 2.
Built from commit `1c8267cdad0a0b4629f65c4e2b9b056ec5f37956` on `submission/v2-candidate`.

## Install (setup, not part of the timed run)

Python 3.12. From this directory:

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install -r requirements-submission.txt
```

`uv` works the same way, if preferred:

```bash
uv venv --python 3.12 .venv
uv pip install --python .venv/bin/python -r requirements-submission.txt
```

That is the whole installation: 8 packages from PyPI, no extra index, no system
packages, no GPU stack, no model download. The travel database ships inside this archive at
`chinatravel/environment/database_en/`, so there is nothing to fetch.

## Run

```bash
.venv/bin/python agent_env/scripts/solve_script_with_harness.py --method <method> --split <split>
```

That single command is the whole system. Both arguments are read from the command line and
neither is hard-coded anywhere in the package: `--split` selects the split to load, `--method`
names the output directory. It:

- loads the split, strips every oracle verifier field (`hard_logic*`) before the agent path sees
  the query, and solves each query with the deterministic `TPCAgent` **in-process**;
- makes **zero LLM calls** and **zero network calls**, and spawns no subprocess -- the LLM-backed
  flags are off by default and no external CLI is invoked;
- keeps the whole run inside a 5-hour wall-clock envelope by giving each
  query the smaller of its per-query budget and its fair share of the time remaining, so a slow
  query cannot starve the rest of the split;
- writes each plan to **`results/<method>/<uid>.json`**, and per-query telemetry plus a split
  summary under `agent_env/runs/<method>/`.

Omitting `--method` falls back to `phase2_e2e_<split>`; omitting `--split` falls back to `easy`.
Neither fallback is used when the arguments above are passed.

Optional overrides (not needed for evaluation): `--budget-sec` (per-query cap),
`--total-budget-sec` (whole-run envelope; `0` disables), `--limit`, `--resume`,
`--harness opencode|codex` (an external-CLI baseline, never the default).

## Layout

| Path | What |
| --- | --- |
| `agent_env/scripts/solve_script_with_harness.py` | the entry point above |
| `agent_env/config.toml` | run configuration (no credentials); command-line flags override it |
| `agent_env/` | the no-oracle environment wrapper and its tools |
| `chinatravel/agent/phase2/` | stage orchestration, budgets, fallback |
| `chinatravel/agent/tpc_agent/` | the deterministic planner and CP-SAT tier |
| `chinatravel/environment/` | world facts (POIs, transport, prices) and `WorldEnv` |
| `chinatravel/evaluation/`, `chinatravel/symbol_verification/` | the official evaluator, unmodified |
| `docs/`, `README.md` | method, evaluation methodology, and competition reference |
| `tests/` | unit tests (`python -m pytest`) |

Evaluator parity point: upstream `LAMDA-NeSy/ChinaTravel` `main` at `c89cfca`.
